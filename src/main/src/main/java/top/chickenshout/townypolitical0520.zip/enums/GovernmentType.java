package top.chickenshout.townypolitical.enums;

import java.util.Arrays;
import java.util.Optional;

/**
 * 国家政体枚举
 * 包含了所有支持的政体类型及其基本特性。
 */
public enum GovernmentType {
    ABSOLUTE_MONARCHY("君主专制", "君主专制", true, false, false, false), // 君主专制
    CONSTITUTIONAL_MONARCHY("君主立宪制", "君主立宪", false, true, false, true), // 君主立宪制
    PARLIAMENTARY_REPUBLIC("议会制共和制", "议会共和", false, true, false, true), // 议会制共和制
    SEMI_PRESIDENTIAL_REPUBLIC("半总统制共和制", "半总统制", false, true, true, true), // 半总统制共和制
    PRESIDENTIAL_REPUBLIC("总统制共和制", "总统制", false, false, true, true); // 总统制共和制

    private final String displayName; // 用于显示的中文名称
    private String description = "";
    private final String shortName; // 用于配置或命令的简称
    private final boolean isAbsoluteMonarchy; // 是否为君主专制
    private final boolean hasParliament; // 是否拥有议会系统
    private final boolean hasDirectPresidentialElection; // 是否有独立的总统直选
    private final boolean allowsParties; // 是否允许政党活动（君主专制下政党意义不大，但仍可存在）

    GovernmentType(String displayName, String shortName, boolean isAbsoluteMonarchy, boolean hasParliament, boolean hasDirectPresidentialElection, boolean allowsParties) {
        this.displayName = displayName;
        this.description = description;
        this.shortName = shortName;
        this.isAbsoluteMonarchy = isAbsoluteMonarchy;
        this.hasParliament = hasParliament;
        this.hasDirectPresidentialElection = hasDirectPresidentialElection;
        this.allowsParties = allowsParties;
    }

    public String getDescription() { return description; } // 新增 getter

    /**
     * 获取政体的显示名称 (中文)。
     * @return 显示名称
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * 获取政体的简称 (用于配置或命令)。
     * @return 简称
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * 判断此政体是否为君主专制。
     * @return 如果是君主专制则返回 true，否则返回 false
     */
    public boolean isAbsoluteMonarchy() {
        return isAbsoluteMonarchy;
    }

    /**
     * 判断此政体是否拥有议会系统。
     * @return 如果拥有议会系统则返回 true，否则返回 false
     */
    public boolean hasParliament() {
        return hasParliament;
    }

    /**
     * 判断此政体是否有独立的总统直选。
     * @return 如果有总统直选则返回 true，否则返回 false
     */
    public boolean hasDirectPresidentialElection() {
        return hasDirectPresidentialElection;
    }

    /**
     * 判断此政体是否允许政党积极参与政治（主要影响选举和议会构成）。
     * 在君主专制下，政党可能存在，但不会通过选举掌握实权。
     * @return 是否允许政党活动
     */
    public boolean allowsParties() {
        return allowsParties;
    }

    /**
     * 根据显示名称查找政体类型。
     * @param displayName 显示名称
     * @return 对应的 GovernmentType Optional，如果找不到则为空
     */
    public static Optional<GovernmentType> fromDisplayName(String displayName) {
        return Arrays.stream(values())
                .filter(type -> type.getDisplayName().equalsIgnoreCase(displayName))
                .findFirst();
    }

    /**
     * 根据简称查找政体类型。
     * @param shortName 简称
     * @return 对应的 GovernmentType Optional，如果找不到则为空
     */
    public static Optional<GovernmentType> fromShortName(String shortName) {
        return Arrays.stream(values())
                .filter(type -> type.getShortName().equalsIgnoreCase(shortName))
                .findFirst();
    }

    /**
     * 根据名称（可以是显示名称或简称）查找政体类型。
     * @param name 名称
     * @return 对应的 GovernmentType Optional，如果找不到则为空
     */
    public static Optional<GovernmentType> fromString(String name) {
        Optional<GovernmentType> byDisplayName = fromDisplayName(name);
        if (byDisplayName.isPresent()) {
            return byDisplayName;
        }
        return fromShortName(name);
    }

}
