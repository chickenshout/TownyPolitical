// 文件名: Bill.java
// 结构位置: top/chickenshout/townypolitical/data/Bill.java
/*
package top.chickenshout.townypolitical.data;

import java.util.*;

public class Bill {
    public enum BillStatus { PENDING, VOTING, PASSED, FAILED, REPEALED, ARCHIVED }
    public enum VoteType { YES, NO, ABSTAIN }

    private final UUID billId;
    private final UUID nationUUID; // 所属国家
    private final UUID proposerUUID; // 提案人玩家UUID
    private final UUID proposingPartyUUID; // 提案政党UUID (可选)
    private String title;
    private String content;
    private BillStatus status;
    public long proposalTimestamp;
    public long votingStartTimestamp;
    public long votingEndTimestamp;

    // 存储投票记录 <VoterPlayerUUID, VoteType>
    public final Map<UUID, VoteType> votes;

    public Bill(UUID billId, UUID nationUUID, UUID proposerUUID, UUID proposingPartyUUID, String title, String content) {
        this.billId = billId; // 使用传入的ID
        this.nationUUID = nationUUID;
        this.proposerUUID = proposerUUID;
        this.proposingPartyUUID = proposingPartyUUID;
        this.title = title;
        this.content = content;
        this.status = BillStatus.PENDING; // 初始状态为待议
        this.proposalTimestamp = System.currentTimeMillis();
        this.votes = new HashMap<>();
    }

    // --- Getters ---
    public UUID getBillId() { return billId; }
    public UUID getNationUUID() { return nationUUID; }
    public UUID getProposerUUID() { return proposerUUID; }
    public Optional<UUID> getProposingPartyUUID() { return Optional.ofNullable(proposingPartyUUID); }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public BillStatus getStatus() { return status; }
    public long getProposalTimestamp() { return proposalTimestamp; }
    public long getVotingStartTimestamp() { return votingStartTimestamp; }
    public long getVotingEndTimestamp() { return votingEndTimestamp; }
    public Map<UUID, VoteType> getVotes() { return new HashMap<>(votes); } // 返回副本

    // --- Setters ---
    public void setTitle(String title) { this.title = title; }
    public void setContent(String content) { this.content = content; }
    public void setStatus(BillStatus status) { this.status = status; }
    public void setVotingStartTimestamp(long votingStartTimestamp) { this.votingStartTimestamp = votingStartTimestamp; }
    public void setVotingEndTimestamp(long votingEndTimestamp) { this.votingEndTimestamp = votingEndTimestamp; }

    public boolean addVote(UUID voterUUID, VoteType voteType) {
        if (status != BillStatus.VOTING) return false; // 只能在投票阶段投票
        if (votes.containsKey(voterUUID)) return false; // 已投票
        votes.put(voterUUID, voteType);
        return true;
    }

    public long getYesVotes() {
        return votes.values().stream().filter(v -> v == VoteType.YES).count();
    }
    public long getNoVotes() {
        return votes.values().stream().filter(v -> v == VoteType.NO).count();
    }
    public long getAbstainVotes() {
        return votes.values().stream().filter(v -> v == VoteType.ABSTAIN).count();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Bill bill = (Bill) o;
        return billId.equals(bill.billId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(billId);
    }
}
*/
