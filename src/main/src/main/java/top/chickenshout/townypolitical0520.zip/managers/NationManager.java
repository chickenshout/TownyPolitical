package top.chickenshout.townypolitical.managers;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.data.NationPolitics;
import top.chickenshout.townypolitical.economy.EconomyService;
import top.chickenshout.townypolitical.enums.ElectionType;
import top.chickenshout.townypolitical.enums.GovernmentType;
import top.chickenshout.townypolitical.utils.MessageManager;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;
//import top.chickenshout.townypolitical.data.Bill; // 新增


public class NationManager {
    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final EconomyService economyService;

    // 存储国家政治数据 <NationUUID, NationPolitics>
    private final Map<UUID, NationPolitics> nationPoliticsMap;
    private final File nationsDataFolder;
    private static final String NATION_POLITICS_FILE_EXTENSION = ".yml";


    /**
     * 获取或创建一个国家的政治数据对象。
     * 如果该国家尚未有政治数据，则会创建一个新的，政体默认为议会制共和制。
     *
     * @param nationUUID Towny国家的UUID
     * @return NationPolitics 对象，如果nationUUID为null则返回null
     */
    public NationPolitics getNationPolitics(UUID nationUUID) {
        if (nationUUID == null) return null;
        return nationPoliticsMap.computeIfAbsent(nationUUID, uuid -> {
            NationPolitics newNationPolitics = new NationPolitics(uuid); // 默认议会制共和
            saveNationPolitics(newNationPolitics); // 创建即保存
            plugin.getLogger().info("Created default politics data for nation: " + uuid);
            return newNationPolitics;
        });
    }

    /**
     * 获取或创建一个国家的政治数据对象。
     *
     * @param nation Towny Nation 对象
     * @return NationPolitics 对象，如果nation为null则返回null
     */
    public NationPolitics getNationPolitics(Nation nation) {
        if (nation == null) return null;
        return getNationPolitics(nation.getUUID());
    }

    /**
     * 更改国家的政体。
     *
     * @param nation      要更改政体的国家
     * @param newGovType  新的政体类型
     * @param initiator   执行此操作的玩家 (通常是国家领袖)
     * @return 如果成功更改则返回true，否则返回false。
     */
    public boolean setGovernmentType(Nation nation, GovernmentType newGovType, OfflinePlayer initiator) {
        if (nation == null || newGovType == null || initiator == null) {
            plugin.getLogger().warning("setGovernmentType called with null parameters.");
            return false;
        }

        NationPolitics politics = getNationPolitics(nation); // 获取或创建
        Resident townyResident = TownyAPI.getInstance().getResident(initiator.getUniqueId());

        // 1. 权限检查: 只有国家领袖可以更改
        if (townyResident == null || !nation.isKing(townyResident)) {
            if (initiator.isOnline()) {
                messageManager.sendMessage(initiator.getPlayer(), "nation-set-government-fail-not-leader");
            }
            return false;
        }

        // 2. 检查是否已经是该政体
        if (politics.getGovernmentType() == newGovType) {
            if (initiator.isOnline()) {
                messageManager.sendMessage(initiator.getPlayer(), "nation-set-government-fail-same",
                        "nation_name", nation.getName(),
                        "government_type", newGovType.getDisplayName());
            }
            return false;
        }

        // 3. 经济成本检查与扣费
        // 成本可以基于政体本身或是一个固定值，这里用固定值举例，可以在config.yml中细化
        double cost = plugin.getConfig().getDouble("nation.government_change_cost." + newGovType.name().toLowerCase(),
                plugin.getConfig().getDouble("nation.government_change_cost.default", 2500.0));

        if (newGovType == GovernmentType.ABSOLUTE_MONARCHY) {
            cost = plugin.getConfig().getDouble("nation.government_change_cost.absolute_monarchy", 10000.0); // 君主专制更贵
        }

        if (economyService.isEnabled() && cost > 0) {
            // 国家操作费用通常从国家银行扣除
            if (!nation.getAccount().canPayFromHoldings(cost)) {
                if (initiator.isOnline()) {
                    messageManager.sendMessage(initiator.getPlayer(), "error-nation-not-enough-money",
                            "amount", economyService.format(cost),
                            "currency", ""); // Towny handles currency symbol with its formatter
                }
                return false;
            }
            try {
                nation.getAccount().withdraw(cost, "Changed government type");
            } catch (Exception e) { // Towny's economy might throw various exceptions
                plugin.getLogger().log(Level.SEVERE, "Failed to withdraw funds from nation bank for government change: " + nation.getName(), e);
                if (initiator.isOnline()) {
                    messageManager.sendMessage(initiator.getPlayer(), "error-economy-transaction-failed", "action", "更改政体");
                }
                return false;
            }
        }

        // 4. 更新政体并保存
        GovernmentType oldGovType = politics.getGovernmentType();
        politics.setGovernmentType(newGovType);
        saveNationPolitics(politics);

        // 5. 发送消息和广播
        if (initiator.isOnline()) {
            messageManager.sendMessage(initiator.getPlayer(), "nation-set-government-success",
                    "nation_name", nation.getName(),
                    "government_type", newGovType.getDisplayName());
            if (cost > 0 && economyService.isEnabled()) {
                // Towny已经有自己的银行交易消息，这里可以补充
                messageManager.sendMessage(initiator.getPlayer(), "nation-set-government-cost-paid",
                        "amount", economyService.format(cost));
            }
        }

        // 全服广播，特别是君主专制
        if (newGovType == GovernmentType.ABSOLUTE_MONARCHY) {
            String broadcastMessage = messageManager.getMessage("nation-set-government-absolute-monarchy-warning",
                    "nation_name", nation.getName());
            Bukkit.broadcastMessage(broadcastMessage);
            // 此处可以触发“君主专制提升国家操作金钱花费”的逻辑
            // 这可能需要一个事件监听器或者在相关操作（如建城镇、宣战）时检查政体并调整花费
            plugin.getLogger().info("Nation " + nation.getName() + " changed to ABSOLUTE_MONARCHY. Financial penalties should now apply.");
        } else {
            // 可选：为其他政体改变也进行较温和的广播或国家内通知
            for (Resident resident : nation.getResidents()) {
                if (resident.isOnline()) {
                    Player player = Bukkit.getPlayer(resident.getUUID());
                    if (player != null) {
                        messageManager.sendMessage(player, "nation-government-changed-notification",
                                "nation_name", nation.getName(),
                                "old_type", oldGovType.getDisplayName(),
                                "new_type", newGovType.getDisplayName());
                    }
                }
            }
        }

        // TODO: 根据新政体，可能需要重置/调整议会、选举等状态
        // 例如，从有议会的政体变为君主专制，议会应解散或失效
        // This would involve calling methods on ElectionManager or ParliamentManager once they exist.
        // e.g., plugin.getElectionManager().onGovernmentChange(nation, oldGovType, newGovType);

        return true;
    }


    /**
     * 获取所有已知的国家政治数据。
     * @return NationPolitics对象的不可修改集合。
     */
    public Collection<NationPolitics> getAllNationPolitics() {
        return Collections.unmodifiableCollection(nationPoliticsMap.values());
    }

    // --- 数据持久化 ---
    

    public void saveAllNationPoliticsData() {
        plugin.getLogger().info("Saving politics data for all " + nationPoliticsMap.size() + " nations...");
        for (NationPolitics politics : nationPoliticsMap.values()) {
            saveNationPolitics(politics);
        }
        plugin.getLogger().info("All nation politics data saved.");
    }

    /**
     * 当一个Towny国家被创建时调用此方法 (通过事件监听器)。
     * @param nation 新创建的Towny国家
     */
    public void onNationCreate(Nation nation) {
        if (nation == null) return;
        plugin.getLogger().info("Towny nation created: " + nation.getName() + ". Initializing political data...");
        getNationPolitics(nation.getUUID()); // 会自动创建并保存默认的政治数据
    }

    public void onNationDelete(String nation) {
        if (nation == null) return;
        plugin.getLogger().info("Towny nation deleted: " + nation);
    }

    /**
     * 检查特定国家是否为君主专制，并应用相应的金钱花费乘数。
     * 这是一个示例性的辅助方法，实际花费调整逻辑可能更复杂，并分散在各处。
     *
     * @param nation Towny 国家对象
     * @param baseCost 基础花费
     * @return 调整后的花费
     */
    public double applyGovernmentCostModifier(Nation nation, double baseCost) {
        if (nation == null) return baseCost;
        NationPolitics politics = getNationPolitics(nation.getUUID()); // 确保数据存在
        if (politics.getGovernmentType() == GovernmentType.ABSOLUTE_MONARCHY) {
            double multiplier = plugin.getConfig().getDouble("nation.absolute_monarchy_cost_multiplier", 1.5); // 从配置中获取乘数
            return baseCost * multiplier;
        }
        return baseCost;
    }

    public void saveNationPolitics(NationPolitics politics) {
        if (politics == null) return;
        File nationFile = new File(nationsDataFolder, politics.getNationUUID().toString() + NATION_POLITICS_FILE_EXTENSION);
        YamlConfiguration nationConfig = new YamlConfiguration();

        nationConfig.set("nationUUID", politics.getNationUUID().toString());
        nationConfig.set("governmentType", politics.getGovernmentType().name());

        // 保存选举完成时间
        ConfigurationSection timesSection = nationConfig.createSection("lastElectionCompletionTimes");
        if (politics.getTitularMonarchUUID().isPresent()) {
            nationConfig.set("titularMonarchUUID", politics.getTitularMonarchUUID().get().toString());
        } else {
            nationConfig.set("titularMonarchUUID", null); // 确保存储null如果不存在
        }
        for (Map.Entry<ElectionType, Long> entry : politics.lastElectionCompletionTimes.entrySet()) { // 直接访问字段或通过getter
            timesSection.set(entry.getKey().name(), entry.getValue());
        }
        // 或者如果 politics.lastElectionCompletionTimes 是 private 的，你需要一个 getter:
        // politics.getAllLastElectionCompletionTimes().forEach((type, time) -> timesSection.set(type.name(), time));

        if (politics.getPrimeMinisterUUID().isPresent()) {
            nationConfig.set("primeMinisterUUID", politics.getPrimeMinisterUUID().get().toString());
        } else {
            nationConfig.set("primeMinisterUUID", null);
        }

        try {
            nationConfig.save(nationFile);
        } catch (IOException e) {
            // ... (log)
        }
    }

    public void loadNationPoliticsData() {
        // ... (清空 map, 获取文件列表) ...
        File[] nationFiles = new File[0];
        for (File nationFile : nationFiles) {
            try {
                YamlConfiguration nationConfig = YamlConfiguration.loadConfiguration(nationFile);
                UUID nationUUID = UUID.fromString(nationConfig.getString("nationUUID"));
                GovernmentType governmentType = GovernmentType.valueOf(nationConfig.getString("governmentType", GovernmentType.PARLIAMENTARY_REPUBLIC.name()));

                NationPolitics politics = new NationPolitics(nationUUID, governmentType);

                if (nationConfig.contains("primeMinisterUUID") && nationConfig.getString("primeMinisterUUID") != null && !nationConfig.getString("primeMinisterUUID").isEmpty()) {
                    try {
                        politics.setPrimeMinisterUUID(UUID.fromString(nationConfig.getString("primeMinisterUUID")));
                    } catch (IllegalArgumentException e) { /* log */ }
                }

                // 加载选举完成时间
                if (nationConfig.isConfigurationSection("lastElectionCompletionTimes")) {
                    ConfigurationSection timesSection = nationConfig.getConfigurationSection("lastElectionCompletionTimes");
                    for (String typeStr : timesSection.getKeys(false)) {
                        try {
                            ElectionType electionType = ElectionType.valueOf(typeStr);
                            long timestamp = timesSection.getLong(typeStr);
                            if (electionType == ElectionType.PARLIAMENTARY || electionType == ElectionType.PRESIDENTIAL) {
                                politics.setLastElectionCompletionTime(electionType, timestamp);
                            }
                        } catch (IllegalArgumentException e) {
                            plugin.getLogger().warning("Invalid ElectionType '" + typeStr + "' in lastElectionCompletionTimes for nation " + nationUUID);
                        }
                    }
                }
                nationPoliticsMap.put(nationUUID, politics);
            } catch (Exception e) {
                // ... (log)
            }
        }



        // ... (同步Towny国家) ...
    }

    public NationManager(TownyPolitical plugin) {
        // ... (初始化其他) ...
        loadNationPoliticsData(); // 已有

        // loadNationBillsData(); // 新增加载法案数据
        this.plugin = null;
        messageManager = null;
        economyService = null;
        nationPoliticsMap = Map.of();
        nationsDataFolder = null;
    }

    public void shutdown() {
        }
    /*
    // --- 法案管理方法 (初步) ---
    public boolean proposeBill(Nation nation, Player proposer, Party proposingParty, String title, String content) {
        if (nation == null || proposer == null || title == null || title.trim().isEmpty() || content == null || content.trim().isEmpty()) {
            return false;
        }
        UUID newBillId = UUID.randomUUID(); // Manager 生成 ID
        UUID partyUUID = null;
        Bill newBill = new Bill(newBillId, nation.getUUID(), proposer.getUniqueId(), partyUUID, title.trim(), content.trim());
        // TODO: 权限检查 (例如，是否为议员，或特定政党成员才有权提案)
        // TODO: 提案花费 (从配置读取，从提案者或政党扣款)
        // double proposalCost = plugin.getConfig().getDouble("parliament.bills.proposal_cost", 100.0);
        // if (economyService.isEnabled() && proposalCost > 0) { ... }

        nationBills.computeIfAbsent(nation.getUUID(), k -> new ArrayList<>()).add(newBill);
        saveNationBills(nation.getUUID()); // 保存该国所有法案
        messageManager.sendMessage(proposer, "bill-propose-success", "title", newBill.getTitle(), "nation", nation.getName());
        // TODO: 通知国家议员或相关人员有新法案待审议
        return true;
    }

    public List<Bill> getBillsForNation(UUID nationUUID) {
        return new ArrayList<>(nationBills.getOrDefault(nationUUID, Collections.emptyList())); // 返回副本
    }

    public Optional<Bill> getBillById(UUID nationUUID, UUID billId) {
        return getBillsForNation(nationUUID).stream().filter(b -> b.getBillId().equals(billId)).findFirst();
    }


    public boolean startBillVoting(Bill bill, long votingDurationSeconds) {
        if (bill == null || bill.getStatus() != Bill.BillStatus.PENDING) return false;
        // TODO: 权限检查
        bill.setStatus(Bill.BillStatus.VOTING);
        bill.setVotingStartTimestamp(System.currentTimeMillis());
        bill.setVotingEndTimestamp(System.currentTimeMillis() + votingDurationSeconds * 1000L);
        saveNationBills(bill.getNationUUID());
        // TODO: 通知议员投票开始
        // TODO: 安排任务在投票结束后处理结果 (类似于选举)
        new BukkitRunnable() {
            @Override
            public void run() {
                finishBillVoting(bill);
            }
        }.runTaskLater(plugin, votingDurationSeconds * 20L);
        return true;
    }


    public void finishBillVoting(Bill bill) {
        if (bill == null || bill.getStatus() != Bill.BillStatus.VOTING) return;
        // TODO: 检查投票时间是否真的结束
        // if (System.currentTimeMillis() < bill.getVotingEndTimestamp()) return; // 未到时间

        // TODO: 结果判定逻辑 (例如简单多数，或需要特定比例)
        long yesVotes = bill.getYesVotes();
        long noVotes = bill.getNoVotes();
        double passThreshold = plugin.getConfig().getDouble("parliament.bills.pass_threshold", 0.51); // 默认大于50%

        if (yesVotes + noVotes == 0) { // 无人投票（不计弃权）
            bill.setStatus(Bill.BillStatus.FAILED);
            // messageManager.sendMessageToNation(bill.getNationUUID(), "bill-vote-failed-no-votes", "title", bill.getTitle());
        } else {
            double yesProportion = (double) yesVotes / (yesVotes + noVotes);
            if (yesProportion >= passThreshold) {
                bill.setStatus(Bill.BillStatus.PASSED);
                // messageManager.sendMessageToNation(bill.getNationUUID(), "bill-vote-passed", "title", bill.getTitle());
                // TODO: 法案通过后的效果应用 (最复杂的部分，需要具体设计)
            } else {
                bill.setStatus(Bill.BillStatus.FAILED);
                // messageManager.sendMessageToNation(bill.getNationUUID(), "bill-vote-failed", "title", bill.getTitle());
            }
        }
        saveNationBills(bill.getNationUUID());
    }


    // --- 法案数据持久化 ---
    private void loadNationBillsData() {
        UUID nationUUID;
        YamlConfiguration config;
        try {
            UUID billIdFromFile = UUID.fromString((String) billIdFromFile.get("billId")); // 从文件读取ID
            // ... 其他属性 ...
            Bill bill = new Bill(billIdFromFile, nationUUID, proposerUUID, proposingPartyUUID, title, content);
            // ... 填充状态和投票 ...
            bills.add(bill);
            nationBills.clear();
            File billsFolder = new File(plugin.getDataFolder(), "nation_bills");
            if (!billsFolder.exists()) billsFolder.mkdirs();

            File[] nationBillFiles = billsFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(".yml"));
            if (nationBillFiles == null) return;

            for (File nationFile : nationBillFiles) {
                try {
                    nationUUID = UUID.fromString(nationFile.getName().replace(".yml", ""));
                    config = YamlConfiguration.loadConfiguration(nationFile);
                    List<Bill> bills = new ArrayList<>();
                    if (config.isList("bills")) {
                        List<Map<?, ?>> billMaps = config.getMapList("bills");
                        for (Map<?, ?> billMap : billMaps) {
                            try {
                                UUID billId = UUID.fromString((String) billMap.get("billId"));
                                UUID proposerUUID = UUID.fromString((String) billMap.get("proposerUUID"));
                                UUID proposingPartyUUID = billMap.containsKey("proposingPartyUUID") ? UUID.fromString((String) billMap.get("proposingPartyUUID")) : null;
                                String title = (String) billMap.get("title");
                                String content = (String) billMap.get("content");

                                Bill bill = new Bill(billId, nationUUID, proposerUUID, proposingPartyUUID, title, content);
                                // Reflection or constructor to set billId (Bill's ID is final & random)
                                // For now, assume Bill can have its ID set or has a constructor for loading
                                // This is a common issue with final UUIDs in constructors.
                                // A better Bill constructor: public Bill(UUID billId, UUID nationUUID, ...)
                                // ReflectionUtils.setFinalField(bill, "billId", billId); // Not ideal

                                bill.setStatus(Bill.BillStatus.valueOf((String) billMap.get("status")));
                                bill.proposalTimestamp = (long) billMap.get("proposalTimestamp"); // Direct access for loading
                                bill.votingStartTimestamp = (long) billMap.get("votingStartTimestamp");
                                bill.votingEndTimestamp = (long) billMap.get("votingEndTimestamp");

                                if (billMap.containsKey("votes")) {
                                    Map<String, String> votesMap = (Map<String, String>) billMap.get("votes");
                                    for (Map.Entry<String, String> voteEntry : votesMap.entrySet()) {
                                        bill.votes.put(UUID.fromString(voteEntry.getKey()), Bill.VoteType.valueOf(voteEntry.getValue()));
                                    }
                                }
                                bills.add(bill);
                            } catch (Exception e) {
                                plugin.getLogger().log(Level.WARNING, "Skipping corrupted bill entry in " + nationFile.getName(), e);
                            }
                        }
                    }
                    nationBills.put(nationUUID, bills);
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Failed to load bills for nation from file: " + nationFile.getName(), e);
                }
            }
            plugin.getLogger().info("Loaded bills for " + nationBills.size() + " nations.");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    private void saveNationBills(UUID nationUUID){
        List<Bill> bills = nationBills.get(nationUUID);
        if (bills == null) return; // No bills to save for this nation

        File billsFolder = new File(plugin.getDataFolder(), "nation_bills");
        if (!billsFolder.exists()) billsFolder.mkdirs();
        File nationFile = new File(billsFolder, nationUUID.toString() + ".yml");

        List<Map<String, Object>> billMaps = new ArrayList<>();
        for (Bill bill : bills) {
            Map<String, Object> billMap = new HashMap<>();
            billMap.put("billId", bill.getBillId().toString());
            billMap.put("proposerUUID", bill.getProposerUUID().toString());
            if (bill.getProposingPartyUUID().isPresent()) {
                billMap.put("proposingPartyUUID", bill.getProposingPartyUUID().get().toString());
            }
            billMap.put("title", bill.getTitle());
            billMap.put("content", bill.getContent());
            billMap.put("status", bill.getStatus().name());
            billMap.put("proposalTimestamp", bill.getProposalTimestamp());
            billMap.put("votingStartTimestamp", bill.getVotingStartTimestamp());
            billMap.put("votingEndTimestamp", bill.getVotingEndTimestamp());

            Map<String, String> votesMap = new HashMap<>();
            bill.getVotes().forEach((voter, type) -> votesMap.put(voter.toString(), type.name()));
            billMap.put("votes", votesMap);
            billMaps.add(billMap);
        }
        config.set("bills", billMaps);

        try {
            config.save(nationFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save bills for nation: " + nationUUID, e);
        }
    }
    */
}