// 文件名: Candidate.java
// 结构位置: top/chickenshout/townypolitical/elections/Candidate.java
package top.chickenshout.townypolitical.elections;

import top.chickenshout.townypolitical.data.Party; // 用于关联政党

import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 代表选举中的一位候选人。
 */
public class Candidate {
    private final UUID playerUUID; // 候选人的玩家UUID
    private final UUID partyUUID;  // 候选人所属的政党UUID (可选，独立候选人可能没有)
    private transient String playerNameCache; // 候选人名称缓存
    private transient String partyNameCache;  // 政党名称缓存
    private final AtomicInteger votes;      // 获得的票数，使用AtomicInteger保证线程安全

    /**
     * 构造一个候选人。
     * @param playerUUID 候选人的玩家UUID
     * @param partyUUID 候选人所属政党的UUID，如果为独立候选人则为null
     */
    public Candidate(UUID playerUUID, UUID partyUUID) {
        if (playerUUID == null) {
            throw new IllegalArgumentException("Player UUID for candidate cannot be null.");
        }
        this.playerUUID = playerUUID;
        this.partyUUID = partyUUID; // 可以为 null
        this.votes = new AtomicInteger(0);
    }

    public UUID getPlayerUUID() {
        return playerUUID;
    }

    public UUID getPartyUUID() {
        return partyUUID;
    }

    public int getVotes() {
        return votes.get();
    }

    public void addVote() {
        this.votes.incrementAndGet();
    }

    /**
     * （慎用）直接设置票数，主要用于从存储加载。
     * @param count 票数
     */
    public void setVotes(int count) {
        this.votes.set(count);
    }

    public String getPlayerNameCache() {
        return playerNameCache;
    }

    public void setPlayerNameCache(String playerNameCache) {
        this.playerNameCache = playerNameCache;
    }

    public String getPartyNameCache() {
        return partyNameCache;
    }

    public void setPartyNameCache(String partyNameCache) {
        this.partyNameCache = partyNameCache;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Candidate candidate = (Candidate) o;
        // 一个选举中，一个玩家只能是一个候选人
        return playerUUID.equals(candidate.playerUUID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(playerUUID);
    }

    @Override
    public String toString() {
        return "Candidate{" +
                "playerUUID=" + playerUUID +
                (playerNameCache != null ? ", playerName='" + playerNameCache + '\'' : "") +
                (partyUUID != null ? ", partyUUID=" + partyUUID : "") +
                (partyNameCache != null ? ", partyName='" + partyNameCache + '\'' : "") +
                ", votes=" + votes +
                '}';
    }
}