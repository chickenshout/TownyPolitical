package top.chickenshout.townypolitical.economy;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;
import top.chickenshout.townypolitical.TownyPolitical; // 假设这是你的主插件类

import java.util.UUID;
import java.util.logging.Level;

public class VaultEconomyService implements EconomyService {

    private Economy vaultEconomy = null;
    private final TownyPolitical plugin; // 引用主插件实例以进行日志记录

    public VaultEconomyService(TownyPolitical plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean initialize() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            plugin.getLogger().warning("Vault plugin not found! Economy features will be disabled.");
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            plugin.getLogger().warning("No economy plugin found (via Vault)! Economy features will be disabled.");
            return false;
        }
        vaultEconomy = rsp.getProvider();
        if (vaultEconomy != null) {
            plugin.getLogger().info("Successfully hooked into Vault economy: " + vaultEconomy.getName());
            return true;
        } else {
            plugin.getLogger().warning("Failed to hook into Vault economy provider. Economy features will be disabled.");
            return false;
        }
    }

    @Override
    public boolean isEnabled() {
        return vaultEconomy != null;
    }

    private OfflinePlayer getOfflinePlayer(UUID playerUniqueId) {
        return Bukkit.getOfflinePlayer(playerUniqueId);
    }

    @Override
    public double getBalance(UUID playerUniqueId) {
        if (!isEnabled()) return 0.0;
        return vaultEconomy.getBalance(getOfflinePlayer(playerUniqueId));
    }

    @Override
    public double getBalance(OfflinePlayer player) {
        if (!isEnabled() || player == null) return 0.0;
        return vaultEconomy.getBalance(player);
    }

    @Override
    public boolean hasEnough(UUID playerUniqueId, double amount) {
        if (!isEnabled()) return false; // 如果经济系统未启用，默认没有足够的钱进行操作
        return vaultEconomy.has(getOfflinePlayer(playerUniqueId), amount);
    }

    @Override
    public boolean hasEnough(OfflinePlayer player, double amount) {
        if (!isEnabled() || player == null) return false;
        return vaultEconomy.has(player, amount);
    }

    @Override
    public boolean withdraw(UUID playerUniqueId, double amount) {
        if (!isEnabled() || amount <= 0) return false; // 不能取负数或0
        OfflinePlayer player = getOfflinePlayer(playerUniqueId);
        if (!createPlayerAccount(player)) { // 确保账户存在
            plugin.getLogger().warning("Failed to ensure account exists for " + player.getName() + " during withdrawal.");
            return false;
        }
        EconomyResponse response = vaultEconomy.withdrawPlayer(player, amount);
        if (!response.transactionSuccess()) {
            plugin.getLogger().fine("Vault withdrawal failed for " + player.getName() + " (" + amount + "): " + response.errorMessage);
        }
        return response.transactionSuccess();
    }

    @Override
    public boolean withdraw(OfflinePlayer player, double amount) {
        if (!isEnabled() || player == null || amount <= 0) return false;
        if (!createPlayerAccount(player)) {
            plugin.getLogger().warning("Failed to ensure account exists for " + player.getName() + " during withdrawal.");
            return false;
        }
        EconomyResponse response = vaultEconomy.withdrawPlayer(player, amount);
        if (!response.transactionSuccess()) {
            plugin.getLogger().fine("Vault withdrawal failed for " + player.getName() + " (" + amount + "): " + response.errorMessage);
        }
        return response.transactionSuccess();
    }

    @Override
    public boolean deposit(UUID playerUniqueId, double amount) {
        if (!isEnabled() || amount <= 0) return false; // 不能存负数或0
        OfflinePlayer player = getOfflinePlayer(playerUniqueId);
        if (!createPlayerAccount(player)) {
            plugin.getLogger().warning("Failed to ensure account exists for " + player.getName() + " during deposit.");
            return false;
        }
        EconomyResponse response = vaultEconomy.depositPlayer(player, amount);
        if (!response.transactionSuccess()) {
            plugin.getLogger().fine("Vault deposit failed for " + player.getName() + " (" + amount + "): " + response.errorMessage);
        }
        return response.transactionSuccess();
    }

    @Override
    public boolean deposit(OfflinePlayer player, double amount) {
        if (!isEnabled() || player == null || amount <= 0) return false;
        if (!createPlayerAccount(player)) {
            plugin.getLogger().warning("Failed to ensure account exists for " + player.getName() + " during deposit.");
            return false;
        }
        EconomyResponse response = vaultEconomy.depositPlayer(player, amount);
        if (!response.transactionSuccess()) {
            plugin.getLogger().fine("Vault deposit failed for " + player.getName() + " (" + amount + "): " + response.errorMessage);
        }
        return response.transactionSuccess();
    }

    @Override
    public String getCurrencyNameSingular() {
        if (!isEnabled()) return "货币"; // 默认值
        return vaultEconomy.currencyNameSingular() != null && !vaultEconomy.currencyNameSingular().isEmpty() ? vaultEconomy.currencyNameSingular() : "货币";
    }

    @Override
    public String getCurrencyNamePlural() {
        if (!isEnabled()) return "货币"; // 默认值
        return vaultEconomy.currencyNamePlural() != null && !vaultEconomy.currencyNamePlural().isEmpty() ? vaultEconomy.currencyNamePlural() : "货币";
    }

    @Override
    public String format(double amount) {
        if (!isEnabled()) return String.valueOf(amount); // 默认格式
        try {
            return vaultEconomy.format(amount);
        } catch (Exception e) { // 一些经济插件的format可能有bug
            plugin.getLogger().log(Level.WARNING, "Error formatting currency from Vault economy provider: " + vaultEconomy.getName(), e);
            return String.format("%.2f %s", amount, getCurrencyNamePlural()); // 备用格式化
        }
    }

    @Override
    public boolean createPlayerAccount(UUID playerUniqueId) {
        if (!isEnabled()) return false;
        return createPlayerAccount(getOfflinePlayer(playerUniqueId));
    }

    @Override
    public boolean createPlayerAccount(OfflinePlayer player) {
        if (!isEnabled() || player == null) return false;
        if (vaultEconomy.hasAccount(player)) {
            return true;
        }
        boolean response = vaultEconomy.createPlayerAccount(String.valueOf(player));
        if (!response && !vaultEconomy.hasAccount(player)) { //再次检查，因为某些插件的createPlayerAccount可能返回false但账户实际已创建
            plugin.getLogger().warning("Failed to create Vault account for " + player.getName() + ": " + response);
            return false;
        }
        return true;
    }

    @Override
    public String getProviderName() {
        if (vaultEconomy != null) {
            return "Vault (via " + vaultEconomy.getName() + ")";
        }
        return "Vault (Not initialized or no provider)";
    }
    // 不要添加 public Economy getVaultEconomy() {} 这样的方法
}