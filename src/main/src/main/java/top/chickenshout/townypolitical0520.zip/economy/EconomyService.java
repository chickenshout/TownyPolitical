package top.chickenshout.townypolitical.economy;

import org.bukkit.OfflinePlayer;

import java.util.UUID;

/**
 * 经济服务接口。
 * 定义了插件与经济系统交互所需的方法。
 * 具体的实现将由例如 VaultEconomyService 提供。
 */
public interface EconomyService {

    /**
     * 初始化经济服务。
     * @return 如果成功初始化并连接到经济插件，则返回 true，否则返回 false。
     */
    boolean initialize();

    /**
     * 检查经济服务是否已成功初始化并可用。
     * @return 如果可用则返回 true。
     */
    boolean isEnabled();

    /**
     * 获取玩家的余额。
     * @param playerUniqueId 玩家的UUID
     * @return 玩家的余额；如果玩家账户不存在或发生错误，可能返回0或负数，具体取决于经济插件实现。
     */
    double getBalance(UUID playerUniqueId);

    /**
     * 获取玩家的余额。
     * @param player OfflinePlayer 对象
     * @return 玩家的余额。
     */
    double getBalance(OfflinePlayer player);

    /**
     * 检查玩家是否有足够的金钱。
     * @param playerUniqueId 玩家的UUID
     * @param amount 需要检查的金额
     * @return 如果玩家有足够的金钱，则返回 true。
     */
    boolean hasEnough(UUID playerUniqueId, double amount);

    /**
     * 检查玩家是否有足够的金钱。
     * @param player OfflinePlayer 对象
     * @param amount 需要检查的金额
     * @return 如果玩家有足够的金钱，则返回 true。
     */
    boolean hasEnough(OfflinePlayer player, double amount);

    /**
     * 从玩家账户中取款。
     * @param playerUniqueId 玩家的UUID
     * @param amount 要取款的金额
     * @return 如果交易成功，则返回 true。
     */
    boolean withdraw(UUID playerUniqueId, double amount);

    /**
     * 从玩家账户中取款。
     * @param player OfflinePlayer 对象
     * @param amount 要取款的金额
     * @return 如果交易成功，则返回 true。
     */
    boolean withdraw(OfflinePlayer player, double amount);

    /**
     * 向玩家账户存款。
     * @param playerUniqueId 玩家的UUID
     * @param amount 要存款的金额
     * @return 如果交易成功，则返回 true。
     */
    boolean deposit(UUID playerUniqueId, double amount);

    /**
     * 向玩家账户存款。
     * @param player OfflinePlayer 对象
     * @param amount 要存款的金额
     * @return 如果交易成功，则返回 true。
     */
    boolean deposit(OfflinePlayer player, double amount);

    /**
     * 获取货币名称 (单数形式)。
     * @return 货币名称，例如 "Dollar"。
     */
    String getCurrencyNameSingular();

    /**
     * 获取货币名称 (复数形式)。
     * @return 货币名称，例如 "Dollars"。
     */
    String getCurrencyNamePlural();

    /**
     * 格式化货币金额。
     * @param amount 要格式化的金额
     * @return 格式化后的字符串，例如 "$1,234.56"。
     */
    String format(double amount);

    /**
     * 尝试创建一个玩家账户（如果经济插件支持并且账户不存在）。
     * 某些经济插件会自动创建账户，此方法可能只是返回true。
     * @param playerUniqueId 玩家的UUID
     * @return 如果账户已存在或成功创建，则返回true。
     */
    boolean createPlayerAccount(UUID playerUniqueId);

    /**
     * 尝试创建一个玩家账户（如果经济插件支持并且账户不存在）。
     * @param player OfflinePlayer 对象
     * @return 如果账户已存在或成功创建，则返回true。
     */
    boolean createPlayerAccount(OfflinePlayer player);

    /**
     * 获取当前经济服务提供者的名称。
     * 例如 "Essentials Economy", "TheNewEconomy", "Vault (via Essentials Economy)"
     * @return 经济提供者的名称，如果未初始化或无法确定则返回默认字符串。
     */
    String getProviderName();
}