// 文件名: Election.java
// 结构位置: top/chickenshout/townypolitical/elections/Election.java
package top.chickenshout.townypolitical.elections;

import top.chickenshout.townypolitical.enums.ElectionStatus;
import top.chickenshout.townypolitical.enums.ElectionType;
import top.chickenshout.townypolitical.enums.GovernmentType;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * 代表一次具体的选举活动。
 */
public class Election {
    private final UUID electionId;         // 选举的唯一ID
    private final UUID contextId;          // 选举的上下文ID (例如 NationUUID 或 PartyUUID)
    private final ElectionType type;       // 选举类型 (议会, 总统, 党内领袖)
    private GovernmentType nationGovernmentTypeCache; // 国家选举时，缓存当时的国家政体

    private ElectionStatus status;
    private long startTime;                // 选举开始时间 (登记或投票开始)
    private long endTime;                  // 选举结束时间 (投票结束)
    private long registrationEndTime;      // 候选人登记截止时间 (如果适用)

    private final Map<UUID, Candidate> candidates; // <PlayerUUID, Candidate>
    private final Set<UUID> voters;              // 记录已投票的玩家UUID，防止重复投票

    // 结果相关
    private UUID winnerPlayerUUID;        // 总统选举的获胜者
    private UUID winnerPartyUUID;         // 议会选举中的多数党 (或者，如果直接选总理，则是总理的政党)
    private Map<UUID, Integer> partySeatDistribution; // <PartyUUID, SeatsCount> 议会席位分布

    public Election(UUID contextId, ElectionType type) {
        this.electionId = UUID.randomUUID();
        this.contextId = contextId;
        this.type = type;
        this.status = ElectionStatus.NONE; // 通常由Manager设置为REGISTRATION或VOTING
        this.candidates = new ConcurrentHashMap<>();
        this.voters = Collections.synchronizedSet(new HashSet<>()); // 保证基本线程安全
        this.partySeatDistribution = new ConcurrentHashMap<>();
    }

    // --- Getters ---
    public UUID getElectionId() {
        return electionId;
    }

    public UUID getContextId() {
        return contextId;
    }

    public ElectionType getType() {
        return type;
    }

    public GovernmentType getNationGovernmentTypeCache() {
        return nationGovernmentTypeCache;
    }

    public ElectionStatus getStatus() {
        return status;
    }

    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public long getRegistrationEndTime() {
        return registrationEndTime;
    }

    public Collection<Candidate> getCandidates() {
        return Collections.unmodifiableCollection(candidates.values());
    }

    public Optional<Candidate> getCandidate(UUID playerUUID) {
        return Optional.ofNullable(candidates.get(playerUUID));
    }

    public Set<UUID> getVoters() {
        return Collections.unmodifiableSet(voters);
    }

    public UUID getWinnerPlayerUUID() {
        return winnerPlayerUUID;
    }

    public UUID getWinnerPartyUUID() {
        return winnerPartyUUID;
    }

    public Map<UUID, Integer> getPartySeatDistribution() {
        return Collections.unmodifiableMap(partySeatDistribution);
    }

    // --- Setters & Mutators ---
    public void setNationGovernmentTypeCache(GovernmentType nationGovernmentTypeCache) {
        this.nationGovernmentTypeCache = nationGovernmentTypeCache;
    }

    public void setStatus(ElectionStatus status) {
        this.status = status;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public void setRegistrationEndTime(long registrationEndTime) {
        this.registrationEndTime = registrationEndTime;
    }

    public boolean addCandidate(Candidate candidate) {
        if (candidate == null || candidates.containsKey(candidate.getPlayerUUID())) {
            return false;
        }
        // 可以在此检查候选人资格，但通常由Manager在调用前检查
        candidates.put(candidate.getPlayerUUID(), candidate);
        return true;
    }

    public boolean removeCandidate(UUID playerUUID) {
        return candidates.remove(playerUUID) != null;
    }

    /**
     * 记录一次投票。
     * @param voterUUID 投票者UUID
     * @param candidateUUID 候选人UUID
     * @return 如果投票成功记录返回true，如果已投票或候选人不存在则返回false。
     */
    public boolean recordVote(UUID voterUUID, UUID candidateUUID) {
        if (voterUUID == null || candidateUUID == null) return false;
        if (voters.contains(voterUUID)) {
            return false; // 已经投过票
        }
        Candidate candidate = candidates.get(candidateUUID);
        if (candidate == null) {
            return false; // 候选人不存在
        }
        candidate.addVote();
        voters.add(voterUUID);
        return true;
    }

    public void setWinnerPlayerUUID(UUID winnerPlayerUUID) {
        this.winnerPlayerUUID = winnerPlayerUUID;
    }

    public void setWinnerPartyUUID(UUID winnerPartyUUID) {
        this.winnerPartyUUID = winnerPartyUUID;
    }

    public void setPartySeatDistribution(Map<UUID, Integer> partySeatDistribution) {
        this.partySeatDistribution.clear();
        if (partySeatDistribution != null) {
            this.partySeatDistribution.putAll(partySeatDistribution);
        }
    }

    public void clearVotesAndVoters() {
        this.voters.clear();
        this.candidates.values().forEach(c -> c.setVotes(0)); // 重置所有候选人票数
    }

    // --- Logic Helpers ---

    /**
     * 检查候选人登记是否仍在进行中。
     * @return 如果在登记期内返回true。
     */
    public boolean isRegistrationOpen() {
        return status == ElectionStatus.REGISTRATION && System.currentTimeMillis() < registrationEndTime;
    }

    /**
     * 检查投票是否仍在进行中。
     * @return 如果在投票期内返回true。
     */
    public boolean isVotingOpen() {
        return status == ElectionStatus.VOTING && System.currentTimeMillis() < endTime;
    }

    /**
     * 获取得票最多的候选人列表（可能存在平票）。
     * @return 得票最多的候选人列表。
     */
    public List<Candidate> getLeadingCandidates() {
        if (candidates.isEmpty()) {
            return Collections.emptyList();
        }
        int maxVotes = -1;
        for (Candidate c : candidates.values()) {
            if (c.getVotes() > maxVotes) {
                maxVotes = c.getVotes();
            }
        }
        final int finalMaxVotes = maxVotes;
        if (finalMaxVotes == -1) return Collections.emptyList(); // No votes cast or no candidates

        return candidates.values().stream()
                .filter(c -> c.getVotes() == finalMaxVotes)
                .collect(Collectors.toList());
    }

    /**
     * 构造一个新的选举实例。
     * @param electionId 此选举的唯一ID (由Manager分配)
     * @param contextId 选举上下文ID (NationUUID或PartyUUID)
     * @param type 选举类型
     */
    public Election(UUID electionId, UUID contextId, ElectionType type) {
        if (electionId == null || contextId == null || type == null) {
            throw new IllegalArgumentException("Election ID, Context ID, and Type cannot be null.");
        }
        this.electionId = electionId; // 使用传入的ID
        this.contextId = contextId;
        this.type = type;
        this.status = ElectionStatus.NONE;
        this.candidates = new ConcurrentHashMap<>();
        this.voters = Collections.synchronizedSet(new HashSet<>());
        this.partySeatDistribution = new ConcurrentHashMap<>();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Election election = (Election) o;
        return electionId.equals(election.electionId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(electionId);
    }

    @Override
    public String toString() {
        return "Election{" +
                "electionId=" + electionId +
                ", contextId=" + contextId +
                ", type=" + type +
                ", status=" + status +
                ", candidates=" + candidates.size() +
                ", voters=" + voters.size() +
                '}';
    }
}