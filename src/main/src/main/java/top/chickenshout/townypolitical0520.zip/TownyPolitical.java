// 文件名: TownyPolitical.java
// 结构位置: top/chickenshout/townypolitical/TownyPolitical.java
package top.chickenshout.townypolitical;

import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginDescriptionFile;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.java.JavaPluginLoader;

import top.chickenshout.townypolitical.commands.PoliticalCommands; // 稍后创建
import top.chickenshout.townypolitical.commands.PoliticalTabCompleter; // 稍后创建
import top.chickenshout.townypolitical.economy.EconomyService;
import top.chickenshout.townypolitical.economy.VaultEconomyService;
import top.chickenshout.townypolitical.listeners.PlayerEventListener; // 稍后创建
import top.chickenshout.townypolitical.listeners.TownyHookListener;
import top.chickenshout.townypolitical.managers.ElectionManager;
import top.chickenshout.townypolitical.managers.NationManager;
import top.chickenshout.townypolitical.managers.PartyManager;
// import top.chickenshout.townypolitical.managers.ParliamentManager; // 稍后创建
import top.chickenshout.townypolitical.utils.MessageManager;

import java.io.File; // 用于测试构造函数
import java.util.logging.Level;

public class TownyPolitical extends JavaPlugin {

    private static TownyPolitical instance;

    // Managers and Services
    private MessageManager messageManager;
    private EconomyService economyService;
    private PartyManager partyManager;
    private NationManager nationManager;
    private ElectionManager electionManager;
    // private ParliamentManager parliamentManager;

    // Listeners
    private TownyHookListener townyHookListener;
    private PlayerEventListener playerEventListener;

    // --- 测试用的构造函数 (用于单元测试，正常服务器加载时不会使用这个) ---
    // Bukkit 在加载插件时会使用无参构造函数，然后调用 onLoad, onEnable
    // 为了模拟这个过程以便进行无服务器环境的测试，有时会用到这种技巧，但要小心使用
    public TownyPolitical() {
        super();
    }

    protected TownyPolitical(JavaPluginLoader loader, PluginDescriptionFile description, File dataFolder, File file) {
        super(loader, description, dataFolder, file);
    }
    // --- 测试用的构造函数结束 ---


    @Override
    public void onLoad() {
        instance = this; //尽早设置 instance
        // 可以在这里进行一些非常早期的初始化，比如检查依赖是否存在，但不建议进行重度操作
        getLogger().info(this.getDescription().getName() + " is loading...");
    }

    @Override
    public void onEnable() {
        // 确保 instance 已设置 (通常 onLoad 会先执行)
        if (instance == null) {
            instance = this;
        }

        long startTime = System.currentTimeMillis();
        getLogger().info("==================================================");
        getLogger().info("Enabling " + this.getDescription().getName() + " version " + this.getDescription().getVersion());

        // 1. 加载/保存默认配置
        getLogger().info("Loading configuration...");
        saveDefaultConfig(); // 从 JAR 中复制 config.yml (如果不存在)
        getConfig().options().copyDefaults(true); // 将 JAR 中 config.yml 的默认值复制到用户的 config.yml 中 (如果用户文件缺少某些键)
        // reloadConfig(); // 如果需要立即应用内存中的更改或从磁盘强制重新加载（通常 saveDefaultConfig 后不需要立即 reload）

        // 2. 初始化消息管理器
        getLogger().info("Initializing Message Manager...");
        this.messageManager = new MessageManager(this);
        if (this.messageManager == null) { // 基本不可能为null，除非构造失败且未抛异常
            getLogger().severe("Message Manager failed to initialize! Plugin cannot enable.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        messageManager.reloadMessages(); // 确保加载最新的 messages.yml

        // 3. 初始化经济服务
        getLogger().info("Initializing Economy Service...");
        this.economyService = new VaultEconomyService(this);
        if (!this.economyService.initialize()) {
            getLogger().warning("Economy service (Vault) could not be initialized or no economy plugin found. Economic features will be limited or disabled.");
            // 根据插件的重要程度，可以选择在这里禁用插件，或者让其在无经济支持下降级运行
            // getLogger().severe("Critical economy features are unavailable. Disabling plugin.");
            // getServer().getPluginManager().disablePlugin(this);
            // return;
        } else {
            this.economyService = new VaultEconomyService(this);
            if (!this.economyService.initialize()) {
                getLogger().warning("Economy service (Vault) could not be initialized or no economy plugin found. Economic features will be limited or disabled.");
            } else {
                // 使用新的 getProviderName() 方法
                getLogger().info("Economy Service initialized successfully with: " + this.economyService.getProviderName() + ".");
            }
        }
        // In onEnable() of TownyPolitical.java
        getLogger().info("Loading configuration...");
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        // reloadConfig(); // 一般不需要紧接着saveDefaultConfig和copyDefaults之后调用
        // 4. 初始化核心管理器 (顺序可能重要，例如 ElectionManager 可能依赖 Party/Nation Manager)
        getLogger().info("Initializing Party Manager...");
        this.partyManager = new PartyManager(this);

        getLogger().info("Initializing Nation Manager...");
        this.nationManager = new NationManager(this);

        getLogger().info("Initializing Election Manager...");
        this.electionManager = new ElectionManager(this);

        // getLogger().info("Initializing Parliament Manager...");
        // this.parliamentManager = new ParliamentManager(this);

        // 5. 注册事件监听器
        getLogger().info("Registering event listeners...");
        if (getServer().getPluginManager().getPlugin("Towny") != null) {
            this.townyHookListener = new TownyHookListener(this);
            getLogger().info("TownyHookListener registered.");
        } else {
            getLogger().severe("Towny plugin not found! TownyPolitical cannot function without Towny. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        this.playerEventListener = new PlayerEventListener(this); // 稍后创建
        getLogger().info("PlayerEventListener registered (placeholder).");


        // 6. 注册命令执行器和Tab补全器
        getLogger().info("Registering commands...");
        PoliticalCommands politicalCommands = new PoliticalCommands(this);
        PoliticalTabCompleter politicalTabCompleter = new PoliticalTabCompleter(this);
        if (this.getCommand("townypolitical") != null) {
            this.getCommand("townypolitical").setExecutor(politicalCommands);
            this.getCommand("townypolitical").setTabCompleter(politicalTabCompleter);
            getLogger().info("'/townypolitical' command registered.");
        } else {
            getLogger().severe("Failed to register '/townypolitical' command! Check plugin.yml.");
        }
        // 你可能会有更多别名或子命令的顶级入口，例如 /party, /election 等，都在 plugin.yml 定义
        // 示例: /tparty (tp party 的别名)
        if (this.getCommand("tparty") != null) {
            this.getCommand("tparty").setExecutor(politicalCommands); // 可以复用同一个执行器，内部判断
            this.getCommand("tparty").setTabCompleter(politicalTabCompleter);
            getLogger().info("'/tparty' alias command registered.");
        }


        long endTime = System.currentTimeMillis();
        getLogger().info(this.getDescription().getName() + " has been enabled successfully! (Took " + (endTime - startTime) + "ms)");
        getLogger().info("==================================================");
    }

    @Override
    public void onDisable() {
        long startTime = System.currentTimeMillis();
        getLogger().info("==================================================");
        getLogger().info("Disabling " + this.getDescription().getName() + "...");

        // 1. 关闭/保存数据 (顺序与启用时相反或按依赖关系)
        if (electionManager != null) {
            getLogger().info("Shutting down Election Manager...");
            electionManager.shutdown();
        }
        if (partyManager != null) {
            getLogger().info("Shutting down Party Manager...");
            partyManager.shutdown();
        }
        if (nationManager != null) {
            getLogger().info("Shutting down Nation Manager...");
            nationManager.shutdown();
        }
        // if (parliamentManager != null) {
        //     getLogger().info("Shutting down Parliament Manager...");
        //     parliamentManager.shutdown();
        // }

        // 2. 取消注册监听器 (Bukkit 会自动处理，但显式处理更清晰，尽管非必需)
        // HandlerList.unregisterAll(this); // 如果有 Listener 实现类直接是主类的话

        // 3. 清理资源
        this.messageManager = null;
        this.economyService = null;
        this.partyManager = null;
        this.nationManager = null;
        this.electionManager = null;
        // this.parliamentManager = null;
        this.townyHookListener = null;
        this.playerEventListener = null;

        instance = null; // 最后清除静态实例

        long endTime = System.currentTimeMillis();
        getLogger().info(this.getDescription().getName() + " has been disabled. (Took " + (endTime - startTime) + "ms)");
        getLogger().info("==================================================");
    }

    // --- 静态 Getters for easy access to managers and services ---
    // 这些 getter 方法使得插件的其他部分可以方便地访问核心组件

    /**
     * 获取插件的唯一实例。
     * @return TownyPolitical 实例
     * @throws IllegalStateException 如果插件尚未加载或已被禁用
     */
    public static TownyPolitical getInstance() {
        if (instance == null) {
            // 尝试从Bukkit获取，如果它已经被加载了但我们的instance变量由于某种原因丢失了
            try {
                TownyPolitical plugin = JavaPlugin.getPlugin(TownyPolitical.class);
                if (plugin != null) {
                    instance = plugin;
                    return instance;
                }
            } catch (IllegalStateException e) {
                // 当插件未加载时，JavaPlugin.getPlugin会抛出此异常
                throw new IllegalStateException("TownyPolitical plugin is not loaded or has been disabled.");
            }
            throw new IllegalStateException("TownyPolitical plugin instance is null. It might not be enabled yet or has been disabled.");
        }
        return instance;
    }

    public MessageManager getMessageManager() {
        if (messageManager == null) throw new IllegalStateException("MessageManager is not initialized (TownyPolitical might be disabled).");
        return messageManager;
    }

    public EconomyService getEconomyService() {
        if (economyService == null) throw new IllegalStateException("EconomyService is not initialized (TownyPolitical might be disabled).");
        // 可选：增加对 economyService.isEnabled() 的检查并发出警告，但不在此处抛异常，让调用方处理
        if (!economyService.isEnabled()) {
            getLogger().finer("EconomyService is being accessed but is not fully enabled (e.g., no Vault or economy plugin).");
        }
        return economyService;
    }

    public PartyManager getPartyManager() {
        if (partyManager == null) throw new IllegalStateException("PartyManager is not initialized (TownyPolitical might be disabled).");
        return partyManager;
    }

    public NationManager getNationManager() {
        if (nationManager == null) throw new IllegalStateException("NationManager is not initialized (TownyPolitical might be disabled).");
        return nationManager;
    }

    public ElectionManager getElectionManager() {
        if (electionManager == null) throw new IllegalStateException("ElectionManager is not initialized (TownyPolitical might be disabled).");
        return electionManager;
    }

    /*
    public ParliamentManager getParliamentManager() {
        if (parliamentManager == null) throw new IllegalStateException("ParliamentManager is not initialized (TownyPolitical might be disabled).");
        return parliamentManager;
    }
    */

    /**
     * 插件重载逻辑。
     * 注意：Bukkit 的 /reload 命令可能会导致内存泄漏和意外行为，不推荐在生产环境频繁使用。
     * 一个好的插件重载应该能正确地重新加载配置、重新初始化状态，但这很难完美实现。
     */
    public boolean reloadPlugin() {
        getLogger().info("Reloading " + this.getDescription().getName() + "...");
        try {
            // 1. 保存所有数据 (如果管理器支持)
            if (partyManager != null) partyManager.shutdown();
            if (nationManager != null) nationManager.shutdown();
            if (electionManager != null) electionManager.shutdown();
            // if (parliamentManager != null) parliamentManager.shutdown();

            // 2. 重新加载配置
            super.reloadConfig(); // Bukkit's method for config.yml
            if (messageManager != null) messageManager.reloadMessages();

            // 3. 重新初始化服务和管理器 (可能需要先注销旧的监听器和任务)
            // 这是一个复杂的过程，简单的做法是禁用再启用插件的核心逻辑部分，
            // 或者更细致地重新初始化每个组件。

            // 示例：重新初始化经济服务
            if (this.economyService instanceof VaultEconomyService) {
                getLogger().info("Re-initializing Economy Service...");
                // VaultEconomyService的initialize()可能需要调整为可重入的，或者创建一个新的实例
                if (!this.economyService.initialize()) {
                    getLogger().warning("Economy service failed to re-initialize during reload.");
                }
            }
            // 重新加载管理器的数据和调度 (这部分很复杂，可能需要管理器有自己的reload方法)
            if (partyManager != null) partyManager.loadParties(); // 示例
            if (nationManager != null) nationManager.loadNationPoliticsData(); // 示例
            if (electionManager != null) {
                // electionManager.shutdown(); // 取消旧任务
                // electionManager.loadActiveElections(); // 重新加载
                // electionManager.scheduleNextElectionsForAllValidContexts(); // 重新调度
                // 简单的做法是，如果 ElectionManager 构造函数会做这些，可以考虑重新 new 一个，但要注意旧实例的清理
                getLogger().info("ElectionManager reload logic needs to be carefully implemented.");
            }


            getLogger().info(this.getDescription().getName() + " reloaded successfully.");
            return true;
        } catch (Exception e) {
            getLogger().log(Level.SEVERE, "Error reloading " + this.getDescription().getName(), e);
            return false;
        }
    }
}