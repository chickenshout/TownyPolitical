// 文件名: PlayerEventListener.java
// 结构位置: top/chickenshout/townypolitical/listeners/PlayerEventListener.java
package top.chickenshout.townypolitical.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.managers.PartyManager;
// import top.chickenshout.townypolitical.managers.ElectionManager; // 如果需要

public class PlayerEventListener implements Listener {

    private final TownyPolitical plugin;
    private final PartyManager partyManager;
    // private final ElectionManager electionManager;

    public PlayerEventListener(TownyPolitical plugin) {
        this.plugin = plugin;
        this.partyManager = plugin.getPartyManager();
        // this.electionManager = plugin.getElectionManager();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("PlayerEventListener registered.");
    }

    /**
     * 当玩家加入服务器时触发。
     * @param event PlayerJoinEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR) // MONITOR 确保在其他插件处理完后执行
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getLogger().finer("Player " + player.getName() + " joined the server.");

        // 通知 PartyManager 玩家上线，可以用于更新缓存或执行特定逻辑
        if (partyManager != null) {
            partyManager.onPlayerJoinServer(player);
        }

        // 未来：
        // - 如果有未完成的投票且该玩家有资格，可以发送提醒消息。
        // - 更新玩家相关的GUI缓存等。
    }

    /**
     * 当玩家离开服务器时触发。
     * @param event PlayerQuitEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        plugin.getLogger().finer("Player " + player.getName() + " left the server.");

        // 通知 PartyManager 玩家下线
        if (partyManager != null) {
            partyManager.onPlayerQuitServer(player);
        }

        // 未来：
        // - 清理与该玩家会话相关的缓存。
    }

    // 你可以根据需要在此处添加更多玩家事件的监听器，例如：
    // - PlayerChatEvent (用于政党聊天、法案讨论等)
    // - PlayerCommandPreprocessEvent (用于可能的命令拦截或别名处理，但通常有更好的方式)
    // - PlayerDeathEvent (如果政治地位影响复活惩罚等 - 超出当前范围)
}