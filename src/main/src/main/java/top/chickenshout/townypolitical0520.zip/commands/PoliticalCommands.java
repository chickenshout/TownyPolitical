package top.chickenshout.townypolitical.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;
import top.chickenshout.townypolitical.TownyPolitical;
//import top.chickenshout.townypolitical.commands.handlers.BillCommandsHandler;
import top.chickenshout.townypolitical.commands.handlers.ElectionCommandsHandler;
import top.chickenshout.townypolitical.commands.handlers.NationCommandsHandler;
import top.chickenshout.townypolitical.commands.handlers.PartyCommandsHandler;
import top.chickenshout.townypolitical.utils.MessageManager;

public class PoliticalCommands implements CommandExecutor {

    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final PartyCommandsHandler partyCommandsHandler;
    private final NationCommandsHandler nationCommandsHandler;
    private final ElectionCommandsHandler electionCommandsHandler;

    public PoliticalCommands(TownyPolitical plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.partyCommandsHandler = new PartyCommandsHandler(plugin);
        this.nationCommandsHandler = new NationCommandsHandler(plugin);
        this.electionCommandsHandler = new ElectionCommandsHandler(plugin);
        //this.billCommandsHandler = new BillCommandsHandler(plugin); // 新增
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        String commandName = command.getName().toLowerCase(); // 获取 plugin.yml 中定义的命令名

        if (args.length == 0) {
            // /tp 或 /tparty (无参数)
            if (commandName.equals("townypolitical")) {
                sendHelpMessage(sender, label);
            } else if (commandName.equals("tparty")) {
                // /tparty 相当于 /tp party
                return partyCommandsHandler.handleCommand(sender, label, new String[]{"party"});
            }
            return true;
        }

        // 处理 /townypolitical <group> ...
        if (commandName.equals("townypolitical")) {
            String subCommandGroup = args[0].toLowerCase();
            switch (subCommandGroup) {
                case "party": case "p":
                    return partyCommandsHandler.handleCommand(sender, label, args); // args 包含 "party"
                case "nation": case "n":
                    return nationCommandsHandler.handleCommand(sender, label, args); // args 包含 "nation"
                case "election": case "e":
                    return electionCommandsHandler.handleCommand(sender, label, args); // args 包含 "election"
                case "reload":
                    if (sender.hasPermission("townypolitical.command.reload")) {
                        if (plugin.reloadPlugin()) {
                            messageManager.sendMessage(sender, "plugin-reloaded-success");
                        } else {
                            messageManager.sendMessage(sender, "plugin-reloaded-fail");
                        }
                    } else {
                        messageManager.sendMessage(sender, "error-no-permission");
                    }
                    return true;
                case "help": case "?":
                    sendHelpMessage(sender, label);
                    return true;
                case "info": case "version":
                    sendPluginInfo(sender);
                    return true;
                default:
                    messageManager.sendMessage(sender, "error-unknown-command", "label", label, "command", args[0]);
                    return true;
            }
        }
        // 处理 /tparty <subcommand> ... (例如 /tparty create <name>)
        else if (commandName.equals("tparty")) {
            // 将 "party" 作为第一个参数插入，然后传递给 partyCommandsHandler
            String[] partyArgs = new String[args.length + 1];
            partyArgs[0] = "party"; // 预置 "party"
            System.arraycopy(args, 0, partyArgs, 1, args.length);
            return partyCommandsHandler.handleCommand(sender, label, partyArgs);
        }

        return false; // 理论上不应该执行到这里，因为 plugin.yml 定义了命令
    }

    private void sendHelpMessage(CommandSender sender, String label) {
        String usageLabel = label.contains("party") ? label : (label + " <module>"); // 调整帮助信息中的用法提示
        messageManager.sendRawMessage(sender, "help-header", "plugin_name", plugin.getDescription().getName());
        messageManager.sendRawMessage(sender, "help-command-format", "label", usageLabel);
        messageManager.sendRawMessage(sender, "help-group-party", "label", label);
        messageManager.sendRawMessage(sender, "help-group-nation", "label", label);
        messageManager.sendRawMessage(sender, "help-group-election", "label", label);
        if (sender.hasPermission("townypolitical.command.reload")) {
            messageManager.sendRawMessage(sender, "help-command-reload", "label", label);
        }
        messageManager.sendRawMessage(sender, "help-footer");
    }

    private void sendPluginInfo(CommandSender sender){
        messageManager.sendRawMessage(sender, "plugin-info-name", "name", plugin.getDescription().getName());
        messageManager.sendRawMessage(sender, "plugin-info-version", "version", plugin.getDescription().getVersion());
        messageManager.sendRawMessage(sender, "plugin-info-author", "author", String.join(", ", plugin.getDescription().getAuthors()));
        messageManager.sendRawMessage(sender, "plugin-info-description", "description", plugin.getDescription().getDescription());
    }

    //private final BillCommandsHandler billCommandsHandler; // 新增

}
