// 文件名: NationPolitics.java
// 结构位置: top/chickenshout/townypolitical/data/NationPolitics.java
package top.chickenshout.townypolitical.data;

import top.chickenshout.townypolitical.enums.ElectionType; // 需要导入
import top.chickenshout.townypolitical.enums.GovernmentType;

import java.util.*;

public class NationPolitics {

    private UUID titularMonarchUUID = null; // 新增字段，存储虚位君主的UUID
    private UUID primeMinisterUUID = null;

    public Optional<UUID> getTitularMonarchUUID() {
        return Optional.ofNullable(titularMonarchUUID);
    }

    public void setTitularMonarchUUID(UUID titularMonarchUUID) {
        this.titularMonarchUUID = titularMonarchUUID; // 允许设为null以移除
    }



    @Override
    public String toString() {
        return "NationPolitics{" +
                "nationUUID=" + nationUUID +
                ", governmentType=" + (governmentType != null ? governmentType.getDisplayName() : "null") +
                ", lastCompletionTimes=" + lastElectionCompletionTimes +
                ", titularMonarch=" + (titularMonarchUUID != null ? titularMonarchUUID.toString().substring(0,8) : "None") +
                ", primeMinister=" + (primeMinisterUUID != null ? primeMinisterUUID.toString().substring(0,8) : "None") +
                '}';
    }

    private final UUID nationUUID;
    private GovernmentType governmentType;
    // 存储国家级选举的上次完成时间 <ElectionType, Timestamp>
    public final Map<ElectionType, Long> lastElectionCompletionTimes;

    public NationPolitics(UUID nationUUID) {
        this.titularMonarchUUID = null;
        this.primeMinisterUUID = null;
        if (nationUUID == null) {
            throw new IllegalArgumentException("Nation UUID cannot be null.");
        }
        this.nationUUID = nationUUID;
        this.governmentType = GovernmentType.PARLIAMENTARY_REPUBLIC;
        this.lastElectionCompletionTimes = new EnumMap<>(ElectionType.class);
    }

    public NationPolitics(UUID nationUUID, GovernmentType initialGovernmentType) {
        this.titularMonarchUUID = null;
        this.primeMinisterUUID = null;
        if (nationUUID == null) {
            throw new IllegalArgumentException("Nation UUID cannot be null.");
        }
        if (initialGovernmentType == null) {
            throw new IllegalArgumentException("Initial GovernmentType cannot be null.");
        }
        this.nationUUID = nationUUID;
        this.governmentType = initialGovernmentType;
        this.lastElectionCompletionTimes = new EnumMap<>(ElectionType.class);
    }

    public Optional<UUID> getPrimeMinisterUUID() {
        return Optional.ofNullable(primeMinisterUUID);
    }

    public void setPrimeMinisterUUID(UUID primeMinisterUUID) {
        this.primeMinisterUUID = primeMinisterUUID;
    }

    public UUID getNationUUID() {
        return nationUUID;
    }

    public GovernmentType getGovernmentType() {
        return governmentType;
    }

    public void setGovernmentType(GovernmentType newGovernmentType) {
        if (newGovernmentType == null) {
            throw new IllegalArgumentException("New GovernmentType cannot be null.");
        }
        this.governmentType = newGovernmentType;
    }

    /**
     * 获取特定类型国家选举的上次完成时间戳。
     * @param type 选举类型 (应为 PARLIAMENTARY 或 PRESIDENTIAL)
     * @return 上次完成的时间戳 (纪元毫秒)，如果从未完成过则返回 0L。
     */
    public long getLastElectionCompletionTime(ElectionType type) {
        if (type != ElectionType.PARLIAMENTARY && type != ElectionType.PRESIDENTIAL) {
            throw new IllegalArgumentException("Invalid election type for nation completion time: " + type);
        }
        return lastElectionCompletionTimes.getOrDefault(type, 0L);
    }

    /**
     * 设置特定类型国家选举的完成时间戳。
     * @param type 选举类型 (应为 PARLIAMENTARY 或 PRESIDENTIAL)
     * @param timestamp 完成的时间戳 (纪元毫秒)
     */
    public void setLastElectionCompletionTime(ElectionType type, long timestamp) {
        if (type != ElectionType.PARLIAMENTARY && type != ElectionType.PRESIDENTIAL) {
            throw new IllegalArgumentException("Invalid election type for nation completion time: " + type);
        }
        if (timestamp < 0) {
            throw new IllegalArgumentException("Timestamp cannot be negative.");
        }
        lastElectionCompletionTimes.put(type, timestamp);
    }

    /**
     * 清除所有选举完成时间记录 (例如政体变更导致选举周期重置时)。
     */
    public void clearAllElectionCompletionTimes() {
        lastElectionCompletionTimes.clear();
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        NationPolitics that = (NationPolitics) o;
        return nationUUID.equals(that.nationUUID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nationUUID);
    }



}