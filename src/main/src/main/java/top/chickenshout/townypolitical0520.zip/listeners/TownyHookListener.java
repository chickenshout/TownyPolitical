package top.chickenshout.townypolitical.listeners;

import com.palmergames.bukkit.towny.event.DeleteNationEvent;
import com.palmergames.bukkit.towny.event.NewNationEvent;
import com.palmergames.bukkit.towny.event.TownAddResidentEvent;
import com.palmergames.bukkit.towny.event.TownRemoveResidentEvent;
import com.palmergames.bukkit.towny.event.RenameNationEvent;
import com.palmergames.bukkit.towny.event.TownClaimEvent;
import com.palmergames.bukkit.towny.event.town.TownUnclaimEvent;
import com.palmergames.bukkit.towny.exceptions.NotRegisteredException;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import com.palmergames.bukkit.towny.object.Town;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.managers.NationManager;
import top.chickenshout.townypolitical.managers.PartyManager;
// Future imports for ElectionManager or ParliamentManager if they need to react to Towny events.

import java.util.UUID;

/**
 * 监听 Towny 插件的事件，以便与 TownyPolitical 插件的逻辑进行同步。
 */
public class TownyHookListener implements Listener {

    private final TownyPolitical plugin;
    private final NationManager nationManager;
    private final PartyManager partyManager;
    // private final ElectionManager electionManager; // 未来添加

    public TownyHookListener(TownyPolitical plugin) {
        this.plugin = plugin;
        this.nationManager = plugin.getNationManager();
        this.partyManager = plugin.getPartyManager();
        // this.electionManager = plugin.getElectionManager();
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        plugin.getLogger().info("TownyHookListener registered.");
    }

    /**
     * 当一个新的 Towny 国家被创建时触发。
     * 我们需要为这个新国家初始化政治数据。
     * @param event NewNationEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onNewNation(NewNationEvent event) {
        Nation nation = event.getNation();
        if (nation != null) {
            plugin.getLogger().finer("TownyHook: NewNationEvent for " + nation.getName());
            nationManager.onNationCreate(nation);
            // 未来可能需要为新国家初始化选举周期等
            // if (electionManager != null) electionManager.onNationCreated(nation);
        }
    }

    /**
     * 当一个 Towny 国家被删除时触发。
     * 我们需要移除这个国家相关的政治数据。
     * @param event DeleteNationEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeleteNation(DeleteNationEvent event) {
        UUID nationUUID = event.getNationUUID(); // Towny 0.97.0.0+ uses getNationUUID()
        String nationName = event.getNationName(); // For logging
        if (nationUUID != null) {
            plugin.getLogger().finer("TownyHook: DeleteNationEvent for " + nationName + " (UUID: " + nationUUID + ")");
            nationManager.onNationDelete(nationName);
            // 未来可能需要清理与该国家相关的选举、议会数据
            // if (electionManager != null) electionManager.onNationDeleted(nationUUID);
            // if (parliamentManager != null) parliamentManager.onNationDeleted(nationUUID);

            // 如果国家解散，其国民理论上不再属于该国政治体系，
            // 但政党成员身份是独立的，除非有特殊设定（例如某政党只在某国活动）
            // 这部分逻辑可以后续细化，例如，如果一个政党是某个特定国家的“执政党”头衔，国家没了，头衔也应该没。
        }
    }

    /**
     * 当一个 Towny 国家被重命名时触发。
     * 我们的插件主要通过UUID关联国家，所以通常不需要特别操作，但可以记录日志。
     * 如果有基于名称的缓存或显示，可能需要更新。
     * @param event RenameNationEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onRenameNation(RenameNationEvent event) {
        Nation nation = event.getNation();
        String oldName = event.getOldName();
        if (nation != null) {
            plugin.getLogger().finer("TownyHook: RenameNationEvent. Nation '" + oldName + "' renamed to '" + nation.getName() + "'. Our data is UUID based, no direct action needed for NationManager unless name caching is used.");
            // 如果 NationManager 中有基于名称的缓存，需要在这里更新。
            // 例如: nationManager.updateNationNameCache(nation.getUUID(), nation.getName());
        }
    }

    // --- 玩家与城镇/国家关系变动事件 ---
    // 这些事件对于选举资格、议会成员资格等可能很重要

    /**
     * 当玩家加入一个城镇时触发。
     * 如果该城镇属于某个国家，这可能会影响玩家在该国的政治权利（如投票权）。
     * @param event PlayerJoinTownEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerJoinTown(TownAddResidentEvent event) {
        Resident resident = event.getResident();
        Town town = event.getTown();
        try {
            if (town.hasNation()) {
                Nation nation = town.getNation();
                plugin.getLogger().finer("TownyHook: Player " + resident.getName() + " joined town " + town.getName() + " which is in nation " + nation.getName());
                // 未来: 检查玩家是否因此获得了在该国的投票权
                // if (electionManager != null) electionManager.onPlayerJoinNation(resident, nation);
            } else {
                plugin.getLogger().finer("TownyHook: Player " + resident.getName() + " joined town " + town.getName() + " (town has no nation).");
            }
        } catch (NotRegisteredException e) {
            // Town or Nation not found, though event implies they exist. Log and continue.
            plugin.getLogger().warning("TownyHook: Error processing PlayerJoinTownEvent: " + e.getMessage());
        }
    }

    /**
     * 当玩家离开一个城镇时触发。
     * 如果该城镇属于某个国家，这可能会剥夺玩家在该国的政治权利。
     * @param event PlayerLeaveTownEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerLeaveTown(TownRemoveResidentEvent event) {
        Resident resident = event.getResident();
        Town town = event.getTown();
        try {
            if (town.hasNation()) {
                Nation nation = town.getNation();
                plugin.getLogger().finer("TownyHook: Player " + resident.getName() + " left town " + town.getName() + " (was in nation " + nation.getName() + ")");
                // 未来: 检查玩家是否因此失去了在该国的投票权或议员资格等
                // if (electionManager != null) electionManager.onPlayerLeaveNation(resident, nation);
                // if (parliamentManager != null) parliamentManager.onPlayerLeaveNation(resident, nation);
            } else {
                plugin.getLogger().finer("TownyHook: Player " + resident.getName() + " left town " + town.getName() + " (town had no nation).");
            }
        } catch (NotRegisteredException e) {
            plugin.getLogger().warning("TownyHook: Error processing PlayerLeaveTownEvent: " + e.getMessage());
        }
    }


    // --- 领土变更事件 ---
    // 这些事件可能影响国家的实力、资源，间接影响政治格局，但对核心政治模块的直接影响较小，
    // 除非法案系统与领土挂钩。

    /**
     * 当城镇声明领土时触发。
     * @param event TownClaimEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTownClaim(TownClaimEvent event) {
        // Town town = event.getTown();
        // plugin.getLogger().finer("TownyHook: Town " + town.getName() + " claimed new land.");
        // 通常不需要直接的政治操作，除非有基于领土的特殊规则
    }

    /**
     * 当城镇放弃领土时触发。
     * @param event TownUnclaimEvent 事件对象
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTownUnclaim(TownUnclaimEvent event) {
        // Town town = event.getTown();
        // plugin.getLogger().finer("TownyHook: Town " + town.getName() + " unclaimed land.");
    }

    // 可以根据需要添加更多 Towny 事件的监听器，例如:
    // - NationAddTownEvent / NationRemoveTownEvent: 国家吞并或失去城镇
    // - TownAddResidentEvent / TownRemoveResidentEvent: 城镇居民变化（间接影响国家公民）
    // - NationAllyEvent / NationEnemyEvent: 国家外交关系变化 (可能用于未来的国际政治模块)
}