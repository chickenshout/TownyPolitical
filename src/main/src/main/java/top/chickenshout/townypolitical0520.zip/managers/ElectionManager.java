package top.chickenshout.townypolitical.managers;

import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException; // 新增
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files; // 新增
import java.nio.file.StandardCopyOption; // 新增
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.exceptions.TownyException;
import com.palmergames.bukkit.towny.object.Nation;
// import com.palmergames.bukkit.towny.object.Resident; // Not directly used in this version of EM
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
// import org.bukkit.configuration.ConfigurationSection; // For future saving/loading
// import org.bukkit.configuration.file.YamlConfiguration; // For future saving/loading
import org.bukkit.entity.Player; // For registerCandidate, castVote
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.data.NationPolitics;
import top.chickenshout.townypolitical.data.Party;
import top.chickenshout.townypolitical.data.PartyMember; // For determining PM from winning party
import top.chickenshout.townypolitical.elections.Candidate;
import top.chickenshout.townypolitical.elections.Election;
import top.chickenshout.townypolitical.enums.ElectionStatus;
import top.chickenshout.townypolitical.enums.ElectionType;
import top.chickenshout.townypolitical.enums.GovernmentType;
import top.chickenshout.townypolitical.utils.MessageManager; // Assuming this is the correct name

// import java.io.IOException; // For future saving/loading
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.stream.Collectors;

public class ElectionManager {
    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final PartyManager partyManager;
    private final NationManager nationManager;

    // 存储活跃的选举 <ContextUUID (Nation/Party), Election>
    // 当前设计：一个ContextUUID（如国家ID）一次只能有一个活跃的Election对象。
    // 如果需要国家同时进行议会和总统选举，且它们是独立的Election对象，则此Map的Key需要调整
    // (例如: Map<String, Election> where key is "ContextUUID_ElectionType")
    private final Map<UUID, Election> activeElections;
    private final Map<UUID, BukkitTask> scheduledElectionTasks; // <ContextUUID, BukkitTask>


    public Election startNationElection(UUID nationUUID, ElectionType electionType) {
        Nation nation = TownyAPI.getInstance().getNation(nationUUID);
        if (nation == null) {
            plugin.getLogger().warning("[ElectionManager] Attempted to start election for non-existent nation: " + nationUUID);
            return null;
        }

        // 当前设计，一个国家一次只能有一种主要选举在 activeElections 中。
        // 如果要允许议会和总统选举同时进行，作为独立的 Election 对象，
        // activeElections 的 key 应该是 NationUUID + "_" + ElectionType。
        // 我们这里先简化，如果已有任何类型的选举，则看是否能覆盖或报错。
        // 为了让 ElectionCommandsHandler 能分别处理，我们假设一种类型对应一个Election对象
        // 所以这里我们需要更精细的key，或者 ElectionManager 内部管理一个 List<Election> per context.

        // 修正：让 activeElections 的 key 包含类型
        String electionKey = nationUUID.toString() + "_" + electionType.name();
        if (this.activeElections.containsKey(electionKey)) { // 检查特定类型的选举是否已存在
            Election existing = this.activeElections.get(electionKey);
            if (existing.getStatus() != ElectionStatus.FINISHED && existing.getStatus() != ElectionStatus.CANCELLED) {
                messageManager.sendMessage(Bukkit.getConsoleSender(), "election-already-active-nation-type", "nation", nation.getName(), "type", electionType.getDisplayName());
                return existing;
            }
        }


        NationPolitics politics = nationManager.getNationPolitics(nation);
        GovernmentType govType = politics.getGovernmentType();

        if (electionType == ElectionType.PARLIAMENTARY && !govType.hasParliament()) return null;
        if (electionType == ElectionType.PRESIDENTIAL && !govType.hasDirectPresidentialElection()) return null;
        // Party Leader elections are handled separately or by a different method.

        Election election = new Election(nationUUID, electionType);
        election.setNationGovernmentTypeCache(govType);

        long registrationDuration = getConfiguredDuration("registration_duration_seconds", 24 * 3600L) * 1000L;
        long votingDuration = getConfiguredDuration("voting_duration_seconds", 48 * 3600L) * 1000L;

        election.setRegistrationEndTime(System.currentTimeMillis() + registrationDuration);
        election.setStartTime(System.currentTimeMillis());
        election.setEndTime(election.getRegistrationEndTime() + votingDuration);
        election.setStatus(ElectionStatus.REGISTRATION);

        this.activeElections.put(UUID.fromString(electionKey), election); // 使用带类型的key
        saveElectionState(election);

        String electionStartKey = (electionType == ElectionType.PARLIAMENTARY) ? "election-registration-start-parliament" : "election-registration-start-presidential";
        broadcastToNation(nation, electionStartKey, "nation_name", nation.getName());
        plugin.getLogger().info("[ElectionManager] " + electionType.getDisplayName() + " registration started for nation: " + nation.getName());

        new BukkitRunnable() {
            @Override
            public void run() {
                ElectionManager.this.advanceElectionToVoting(election.getElectionId());
            }
        }.runTaskLater(plugin, registrationDuration / 50L);
        return election;
    }

    public void advanceElectionToVoting(UUID electionId) {
        Election election = findElectionById(electionId); // findElectionById needs to search through the new key system
        if (election == null || election.getStatus() != ElectionStatus.REGISTRATION) return;

        if (election.getCandidates().isEmpty()) {
            messageManager.sendMessage(Bukkit.getConsoleSender(), "election-no-candidates", "election_type", election.getType().getDisplayName(), "context", getContextName(election.getContextId(), election.getType()));
            cancelElection(election, "没有候选人参与");
            return;
        }

        election.setStatus(ElectionStatus.VOTING);
        election.setStartTime(System.currentTimeMillis());
        saveElectionState(election);

        String votingStartKey = (election.getType() == ElectionType.PARLIAMENTARY) ? "election-voting-start-parliament" : "election-voting-start-presidential";
        broadcastToContext(election, votingStartKey, "context_name", getContextName(election.getContextId(), election.getType()));
        plugin.getLogger().info("[ElectionManager] " + election.getType().getDisplayName() + " V этап голосования начался для: " + getContextName(election.getContextId(), election.getType()));


        long votingDurationTicks = (election.getEndTime() - System.currentTimeMillis()) / 50L;
        if (votingDurationTicks <= 0) {
            finishElection(election.getElectionId());
            return;
        }
        new BukkitRunnable() {
            @Override
            public void run() {
                ElectionManager.this.finishElection(election.getElectionId());
            }
        }.runTaskLater(plugin, votingDurationTicks);
    }


    public void cancelElection(Election election, String reason) {
        if (election == null || election.getStatus() == ElectionStatus.FINISHED || election.getStatus() == ElectionStatus.CANCELLED) return;
        String contextName = getContextName(election.getContextId(), election.getType());
        plugin.getLogger().info("[ElectionManager] Cancelling " + election.getType().getDisplayName() + " for " + contextName + ". Reason: " + reason);
        election.setStatus(ElectionStatus.CANCELLED);
        saveElectionState(election);

        String electionKey = election.getContextId().toString() + "_" + election.getType().name();
        this.activeElections.remove(electionKey);

        broadcastToContext(election, "election-cancelled", "context_name", contextName, "election_type", election.getType().getDisplayName(), "reason", reason);
    }

    // --- Candidate & Voting Logic ---
    public boolean registerCandidate(Player player, Election election) {
        if (player == null || election == null || election.getStatus() != ElectionStatus.REGISTRATION) {
            if (player != null) messageManager.sendMessage(player, "election-candidate-register-fail-closed");
            return false;
        }
        if (!isPlayerEligibleToRun(player, election)) return false;
        if (election.getCandidate(player.getUniqueId()).isPresent()) {
            messageManager.sendMessage(player, "election-candidate-register-fail-already-registered");
            return false;
        }
        Party playerParty = partyManager.getPartyByMember(player.getUniqueId());
        UUID partyUUID = (playerParty != null) ? playerParty.getPartyId() : null;

        if (election.getType() == ElectionType.PARLIAMENTARY) {
            if (playerParty == null && !plugin.getConfig().getBoolean("elections.allow_independent_candidates.parliamentary", false)) {
                messageManager.sendMessage(player, "election-candidate-register-fail-parliament-no-party");
                return false;
            }
            if (playerParty != null && !playerParty.isLeader(player.getUniqueId()) &&
                    plugin.getConfig().getBoolean("elections.parliament.require_party_leader_approval_to_run", true)) { // Example config
                // More complex: check if party leader/admins approved this candidate
                // For now, assume if they are in party, they can represent it, or leader is registering.
                // boolean partyRunning = getConfiguredPartyParticipation(playerParty, election.getContextId());
                // if(!partyRunning) { /* ... */ }
            }
        } else if (election.getType() == ElectionType.PRESIDENTIAL) {
            if (playerParty == null && !plugin.getConfig().getBoolean("elections.allow_independent_candidates.presidential", true)) {
                messageManager.sendMessage(player, "election-candidate-register-fail-presidential-no-party");
                return false;
            }
        }

        Candidate candidate = new Candidate(player.getUniqueId(), partyUUID);
        candidate.setPlayerNameCache(player.getName());
        if (playerParty != null) candidate.setPartyNameCache(playerParty.getName());

        if (election.addCandidate(candidate)) {
            saveElectionState(election);
            messageManager.sendMessage(player, "election-candidate-register-success", "election_type", election.getType().getDisplayName(), "context_name", getContextName(election.getContextId(), election.getType()));
            return true;
        }
        return false;
    }

    public boolean castVote(Player voter, Election election, Candidate candidate) {
        if (voter == null || election == null || candidate == null) return false;
        if (election.getStatus() != ElectionStatus.VOTING) {
            messageManager.sendMessage(voter, "election-vote-fail-closed"); return false;
        }
        if (!isPlayerEligibleToVote(voter, election)) return false;
        if (election.getVoters().contains(voter.getUniqueId())) {
            messageManager.sendMessage(voter, "election-vote-fail-already-voted"); return false;
        }
        if (!election.getCandidate(candidate.getPlayerUUID()).isPresent()){
            messageManager.sendMessage(voter, "election-vote-fail-invalid-candidate"); return false;
        }
        if (election.recordVote(voter.getUniqueId(), candidate.getPlayerUUID())) {
            saveElectionState(election);
            messageManager.sendMessage(voter, "election-vote-success", "candidate_name", candidate.getPlayerNameCache() != null ? candidate.getPlayerNameCache() : "ID: "+candidate.getPlayerUUID().toString().substring(0,8));
            return true;
        }
        return false;
    }

    private boolean isPlayerEligibleToRun(Player player, Election election) { /* ... (Previous logic mostly fine) ... */
        if (election.getType() == ElectionType.PRESIDENTIAL || election.getType() == ElectionType.PARLIAMENTARY) {
            Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
            if (nation == null) return false;
            com.palmergames.bukkit.towny.object.Resident resident = TownyAPI.getInstance().getResident(player.getUniqueId()); // Use full path to avoid ambiguity
            if (resident == null || !resident.hasNation() ) {
                messageManager.sendMessage(player, "election-candidate-register-fail-not-citizen", "nation_name", nation.getName());
                return false;
            }
            try {
                if(!resident.getNation().equals(nation)){
                    messageManager.sendMessage(player, "election-candidate-register-fail-not-citizen", "nation_name", nation.getName());
                    return false;
                }
            } catch (TownyException e){
                messageManager.sendMessage(player, "election-candidate-register-fail-not-citizen", "nation_name", nation.getName());
                return false;
            }
        }
        return true;
    }
    private boolean isPlayerEligibleToVote(Player player, Election election) { /* ... (Previous logic mostly fine) ... */
        if (election.getType() == ElectionType.PRESIDENTIAL || election.getType() == ElectionType.PARLIAMENTARY) {
            Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
            if (nation == null) return false;
            com.palmergames.bukkit.towny.object.Resident resident = TownyAPI.getInstance().getResident(player.getUniqueId());
            if (resident == null || !resident.hasNation()) {
                messageManager.sendMessage(player, "election-vote-fail-not-citizen", "nation_name", nation.getName());
                return false;
            }
            try {
                if(!resident.getNation().equals(nation)){
                    messageManager.sendMessage(player, "election-vote-fail-not-citizen", "nation_name", nation.getName());
                    return false;
                }
            } catch (TownyException e){
                messageManager.sendMessage(player, "election-vote-fail-not-citizen", "nation_name", nation.getName());
                return false;
            }
        } else if (election.getType() == ElectionType.PARTY_LEADER) {
            Party party = partyManager.getParty(election.getContextId());
            if (party == null || !party.isOfficialMember(player.getUniqueId())) {
                messageManager.sendMessage(player, "election-vote-fail-not-party-member", "party_name", party != null ? party.getName() : "N/A");
                return false;
            }
        }
        return true;
    }

    private Map<UUID, Integer> calculateSeatDistributionSimpleProportion(Map<UUID, Integer> partyVotes, int totalSeats) { /* ... (Same as before) ... */
        Map<UUID, Integer> seatDistribution = new HashMap<>();
        if (partyVotes.isEmpty() || totalSeats <= 0) return seatDistribution;
        long totalVoteCount = partyVotes.values().stream().mapToLong(Integer::intValue).sum();
        if (totalVoteCount == 0) return seatDistribution;
        int seatsAllocated = 0;
        for (Map.Entry<UUID, Integer> entry : partyVotes.entrySet()) {
            double proportion = (double) entry.getValue() / totalVoteCount;
            int seats = (int) Math.floor(proportion * totalSeats);
            seatDistribution.put(entry.getKey(), seats);
            seatsAllocated += seats;
        }
        int remainingSeats = totalSeats - seatsAllocated;
        if (remainingSeats > 0) {
            Map<UUID, Double> partyRemainders = new HashMap<>();
            for (Map.Entry<UUID, Integer> entry : partyVotes.entrySet()) {
                double proportion = (double) entry.getValue() / totalVoteCount;
                partyRemainders.put(entry.getKey(), (proportion * totalSeats) - Math.floor(proportion * totalSeats));
            }
            List<Map.Entry<UUID, Double>> sortedRemainders = partyRemainders.entrySet().stream()
                    .sorted(Map.Entry.<UUID, Double>comparingByValue().reversed())
                    .collect(Collectors.toList());
            for (int i = 0; i < remainingSeats && i < sortedRemainders.size(); i++) {
                UUID partyId = sortedRemainders.get(i).getKey();
                seatDistribution.merge(partyId, 1, Integer::sum);
            }
        }
        return seatDistribution;
    }
    public void announceElectionResults(Election election) { /* ... (Same as before, ensure placeholders are correct) ... */
        String contextName = getContextName(election.getContextId(), election.getType());
        switch (election.getType()) {
            case PRESIDENTIAL:
                OfflinePlayer president = election.getWinnerPlayerUUID() != null ? Bukkit.getOfflinePlayer(election.getWinnerPlayerUUID()) : null;
                if (president != null && president.getName() != null) {
                    broadcastToContext(election, "election-results-president", "context_name", contextName, "president_name", president.getName());
                    // Set Towny King for Presidential/Semi-Presidential
                    Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
                    com.palmergames.bukkit.towny.object.Resident presResident = TownyAPI.getInstance().getResident(president.getUniqueId());
                    if (nation != null && presResident != null && nation.hasResident(presResident)) {
                        try {
                            nation.setKing(presResident);
                            messageManager.sendMessage(Bukkit.getConsoleSender(), "election-set-nation-king", "nation", nation.getName(), "king", presResident.getName());
                        } catch (Exception e) {
                            plugin.getLogger().log(Level.SEVERE, "Failed to set nation king after presidential election for " + nation.getName(), e);
                        }
                    }
                } else { broadcastToContext(election, "election-results-president-failed", "context_name", contextName); }
                break;
            case PARLIAMENTARY:
                Party winningParty = election.getWinnerPartyUUID() != null ? partyManager.getParty(election.getWinnerPartyUUID()) : null;
                String winningPartyName = winningParty != null ? winningParty.getName() : "N/A";
                String primeMinisterName = "N/A";
                if (winningParty != null) {
                    Optional<PartyMember> leaderOpt = winningParty.getLeader();
                    if(leaderOpt.isPresent()){ primeMinisterName = leaderOpt.get().getName(); }
                }
                broadcastToContext(election, "election-results-parliament", "context_name", contextName, "winning_party", winningPartyName, "prime_minister", primeMinisterName);
                break;
            case PARTY_LEADER:
                OfflinePlayer partyLeader = election.getWinnerPlayerUUID() != null ? Bukkit.getOfflinePlayer(election.getWinnerPlayerUUID()) : null;
                Party partyContext = partyManager.getParty(election.getContextId());
                if (partyLeader != null && partyLeader.getName() != null && partyContext != null) {
                    broadcastToContext(election, "party-leader-election-result", "party_name", partyContext.getName(), "new_leader", partyLeader.getName());
                }
                break;
        }
    }


    // --- Helpers & Utils ---
    private void cancelScheduledTask(UUID contextId) { /* ... (Same as before) ... */
        BukkitTask existingTask = this.scheduledElectionTasks.remove(contextId);
        if (existingTask != null) {
            try { existingTask.cancel(); } catch (Exception e) { /* ignore */ }
        }
    }

    public List<Election> getAllActiveElections() { // Added this
        return this.activeElections.values().stream()
                .filter(e -> e.getStatus() != ElectionStatus.FINISHED && e.getStatus() != ElectionStatus.CANCELLED)
                .collect(Collectors.toList());
    }
    public List<Election> getRecentlyFinishedElections(int limit) { // Added this
        // TODO: Implement proper loading from storage and sorting
        List<Election> finished = this.activeElections.values().stream()
                .filter(e -> e.getStatus() == ElectionStatus.FINISHED)
                .sorted(Comparator.comparingLong(Election::getEndTime).reversed())
                .limit(limit)
                .collect(Collectors.toList());
        // This is a temporary fix, it only looks at "activeElections" which should ideally not hold finished ones for long
        plugin.getLogger().info("[ElectionManager] getRecentlyFinishedElections() currently only checks in-memory map, not persistent storage.");
        return finished;
    }


    public String getContextName(UUID contextId, ElectionType type) { /* ... (Same as before) ... */
        if (contextId == null) return "全局";
        if (type == ElectionType.PARTY_LEADER) {
            Party party = partyManager.getParty(contextId);
            return party != null ? party.getName() : "未知政党";
        } else {
            Nation nation = TownyAPI.getInstance().getNation(contextId);
            return nation != null ? nation.getName() : "未知国家";
        }
    }
    private void broadcastToNation(Nation nation, String messageKey, Object... placeholders) { /* ... (Same as before) ... */
        if (nation == null) return;
        String message = messageManager.getMessage(messageKey, placeholders); // This already includes prefix if configured in MessageManager
        for (com.palmergames.bukkit.towny.object.Resident resident : nation.getResidents()) { // Use full path
            if (resident.isOnline()) {
                Player player = Bukkit.getPlayer(resident.getUUID());
                if (player != null) {
                    // sendMessage already prepends prefix if the message key is configured to not have one in MessageManager or if using raw message
                    // messageManager.sendMessage(player, messageKey, placeholders); // Simpler way
                    player.sendMessage(message); // Assuming message from getMessage is complete
                }
            }
        }
        plugin.getLogger().info("[Nation Broadcast: " + nation.getName() + "] " + message.replaceAll("§.", "")); // Strip color codes for console
    }
    private void broadcastToContext(Election election, String messageKey, Object... placeholders) { /* ... (Same as before) ... */
        String rawMessage = messageManager.getRawMessage(messageKey, messageKey); // Get raw message, then replace
        String prefix = plugin.getMessageManager().getPrefix(); // Get prefix explicitly

        String messageBody = rawMessage;
        if (placeholders.length % 2 == 0) {
            for (int i = 0; i < placeholders.length; i += 2) {
                if (placeholders[i] == null || placeholders[i+1] == null) continue;
                messageBody = messageBody.replace("%" + placeholders[i].toString() + "%", placeholders[i+1].toString());
            }
        }
        String finalMessage = prefix + MessageManager.translateColors(messageBody); // Manually construct with prefix

        if (election.getType() == ElectionType.PARTY_LEADER) {
            Party party = partyManager.getParty(election.getContextId());
            if (party != null) {
                for(PartyMember member : party.getAllPartyPersonnel()){
                    if(member.getRole() != top.chickenshout.townypolitical.enums.PartyRole.APPLICANT){
                        OfflinePlayer offlineP = member.getOfflinePlayer();
                        if(offlineP.isOnline() && offlineP.getPlayer() != null){
                            offlineP.getPlayer().sendMessage(finalMessage);
                        }
                    }
                }
                plugin.getLogger().info("[Party Broadcast: " + party.getName() + "] " + MessageManager.translateColors(messageBody).replaceAll("§.", ""));
            }
        } else { // National elections
            Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
            if (nation != null) {
                for (com.palmergames.bukkit.towny.object.Resident resident : nation.getResidents()) {
                    if (resident.isOnline()) {
                        Player player = Bukkit.getPlayer(resident.getUUID());
                        if (player != null) {
                            player.sendMessage(finalMessage);
                        }
                    }
                }
                plugin.getLogger().info("[Nation Broadcast: " + nation.getName() + "] " + MessageManager.translateColors(messageBody).replaceAll("§.", ""));
            }
        }
    }

    private long getConfiguredDuration(String pathSuffix, long defaultValueSeconds) { /* ... (Same as before) ... */
        return plugin.getConfig().getLong("elections." + pathSuffix, defaultValueSeconds);
    }
    private int getConfiguredTotalParliamentSeats(UUID nationUUID, GovernmentType govType) { /* ... (Same as before) ... */
        return plugin.getConfig().getInt("elections.parliament.total_seats", 100);
    }


    public void onNationDeleted(UUID nationUUID) { /* ... (Logic was mostly okay, ensure key usage is correct) ... */
        plugin.getLogger().info("Nation " + nationUUID + " deleted. Cleaning up related elections.");
        for (ElectionType type : ElectionType.values()){ // Check all types for this nation
            String electionKey = nationUUID.toString() + "_" + type.name();
            Election activeElection = this.activeElections.remove(electionKey);
            if (activeElection != null) {
                // Optionally save its state as cancelled before removing file.
                plugin.getLogger().info("Cancelled active " + type.name() + " election for deleted nation " + nationUUID);
            }
        }
        cancelScheduledTask(nationUUID);
    }
    public void onPartyDisband(Party party) { /* ... (Same as before) ... */
        UUID partyId = party.getPartyId();
        // Check all active elections
        for (UUID electionKey : new HashSet<>(this.activeElections.keySet())) { // Iterate copy
            Election election = this.activeElections.get(electionKey);
            if (election == null) continue;

            boolean changed = false;
            List<Candidate> toRemove = new ArrayList<>();
            for (Candidate candidate : election.getCandidates()) {
                if (partyId.equals(candidate.getPartyUUID())) {
                    toRemove.add(candidate);
                }
            }
            for (Candidate c : toRemove) {
                election.removeCandidate(c.getPlayerUUID());
                changed = true;
            }
            if (changed) {
                plugin.getLogger().info("Removed candidates from disbanded party " + party.getName() + " in election " + getContextName(election.getContextId(), election.getType()) + " " + election.getType().name());
                saveElectionState(election);
            }

            // If it's a party leader election for the disbanded party
            if (election.getType() == ElectionType.PARTY_LEADER && election.getContextId().equals(partyId)) {
                cancelElection(election, "政党已解散");
            }
        }
    }

    private final File activeElectionsDataFolder; // 修改: 更具体的文件夹
    private final File archivedElectionsDataFolder; // 新增: 用于归档
    private static final String ELECTION_FILE_EXTENSION = ".yml";

    public ElectionManager(TownyPolitical plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.partyManager = plugin.getPartyManager();
        this.nationManager = plugin.getNationManager();

        this.activeElections = new ConcurrentHashMap<>();
        this.scheduledElectionTasks = new ConcurrentHashMap<>();

        File baseElectionsFolder = new File(plugin.getDataFolder(), "elections");
        if (!baseElectionsFolder.exists()) baseElectionsFolder.mkdirs();

        this.activeElectionsDataFolder = new File(baseElectionsFolder, "active");
        if (!activeElectionsDataFolder.exists()) activeElectionsDataFolder.mkdirs();

        this.archivedElectionsDataFolder = new File(baseElectionsFolder, "archived");
        if (!archivedElectionsDataFolder.exists()) archivedElectionsDataFolder.mkdirs();

        loadActiveElections();
        scheduleNextElectionsForAllValidContexts();
    }

    // --- 选举调度与生命周期 (startNationElection, advanceElectionToVoting, finishElection, cancelElection) ---
    // ... (这些方法内部调用 saveElectionState() 和 archiveElection() 的地方需要确认) ...

    // 在 startNationElection 方法创建 Election 对象后：
    // Election election = new Election(nationUUID, electionType);
    // ... (设置时间和状态) ...
    // activeElections.put(election.getElectionId(), election); // 使用 electionId 作为 key
    // saveElectionState(election); // 保存初始状态

    // 在 finishElection 方法中:
    // ... (计算结果后) ...
    // election.setStatus(ElectionStatus.FINISHED);
    // saveElectionState(election); // 保存最终结果
    // archiveElection(election); // 归档选举
    // activeElections.remove(election.getElectionId()); // 从活跃列表移除

    // 在 cancelElection 方法中:
    // ...
    // election.setStatus(ElectionStatus.CANCELLED);
    // saveElectionState(election); // 保存取消状态
    // archiveElection(election); // 也可以归档取消的选举
    // activeElections.remove(election.getElectionId());


    // --- 候选人与投票逻辑 (registerCandidate, castVote) ---
    // ... (这些方法内部调用 saveElectionState() 的地方需要确认) ...
    // 在 registerCandidate 成功添加后:
    // saveElectionState(election);
    // 在 castVote 成功记录后:
    // saveElectionState(election);


    // --- 修改 activeElections 的 key ---
    // 将 private final Map<UUID, Election> activeElections;
    // 修改为:
    // private final Map<UUID, Election> activeElectionsById; // Key is ElectionID
    // 并在构造函数中初始化: this.activeElectionsById = new ConcurrentHashMap<>();
    // 所有之前通过 contextId 查找 activeElections 的地方都需要调整逻辑。
    // 例如，一个国家可以有多个活跃选举（不同类型），所以不能只用 NationUUID 作为key。
    // getActiveElection(contextUUID, type) 需要遍历 activeElectionsById.values() 来查找。
    // startNationElection 也需要调整，确保不会重复启动完全相同的选举（基于ContextId和Type）。

    // 为了简化当前步骤，我们暂时保持 activeElections 的 key 为 ContextUUID，
    // 这意味着一个国家/政党同时只能有一个由本Manager直接管理的选举。
    // 如果需要支持并行选举（例如议会和总统同时），则需要修改 activeElections 的结构。
    // 我们将在 ElectionManager 更加完善后再回顾这个问题。

    // --- Data Persistence ---
    public void loadActiveElections() {
        activeElections.clear(); // 清空内存中的旧数据
        plugin.getLogger().info("Loading active elections data...");
        if (!activeElectionsDataFolder.exists() || !activeElectionsDataFolder.isDirectory()) {
            plugin.getLogger().warning("Active elections data folder not found. No elections loaded.");
            return;
        }

        File[] electionFiles = activeElectionsDataFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(ELECTION_FILE_EXTENSION));
        if (electionFiles == null || electionFiles.length == 0) {
            plugin.getLogger().info("No active election files found.");
            return;
        }

        int loadedCount = 0;
        for (File electionFile : electionFiles) {
            try {
                YamlConfiguration config = new YamlConfiguration();
                config.load(electionFile);

                UUID electionId = UUID.fromString(config.getString("electionId"));
                UUID contextId = UUID.fromString(config.getString("contextId"));
                ElectionType type = ElectionType.valueOf(config.getString("type"));

                Election election = new Election(contextId, type); // 注意：这里的构造会生成新的electionId
                // 我们需要一个方式来设置从文件读取的electionId
                // 解决方案：为 Election 添加一个可以设置 electionId 的构造函数或方法，或直接修改其ID
                // 或者，Election 构造函数不生成ID，ID由Manager创建时指定。
                // 为简单起见，我们假设 Election 类允许修改 ID 或有特定构造：
                // public Election(UUID electionId, UUID contextId, ElectionType type) { this.electionId = electionId; ... }
                // 或者 election.setElectionIdInternal(electionId);

                // 临时的解决方法，如果Election的ID是final的：
                // 我们需要根据 contextId 和 type 来重新构建 Election 对象，然后填充数据。
                // 这就要求 ElectionManager 在创建选举时，如果 contextId+type 已存在活跃选举，则不应创建新的。
                // 目前的 activeElections 使用 contextId 作key，所以这隐含了这个约束。

                election.setStatus(ElectionStatus.valueOf(config.getString("status")));
                if (config.contains("nationGovernmentTypeCache")) {
                    election.setNationGovernmentTypeCache(GovernmentType.valueOf(config.getString("nationGovernmentTypeCache")));
                }
                election.setStartTime(config.getLong("startTime"));
                election.setEndTime(config.getLong("endTime"));
                election.setRegistrationEndTime(config.getLong("registrationEndTime"));

                if (config.isConfigurationSection("candidates")) {
                    ConfigurationSection candidatesSection = config.getConfigurationSection("candidates");
                    for (String candidateUuidStr : candidatesSection.getKeys(false)) {
                        UUID playerUUID = UUID.fromString(candidateUuidStr);
                        UUID partyUUID = config.contains("candidates." + candidateUuidStr + ".partyUUID") ?
                                UUID.fromString(config.getString("candidates." + candidateUuidStr + ".partyUUID")) : null;
                        Candidate candidate = new Candidate(playerUUID, partyUUID);
                        candidate.setVotes(config.getInt("candidates." + candidateUuidStr + ".votes"));
                        candidate.setPlayerNameCache(config.getString("candidates." + candidateUuidStr + ".playerNameCache"));
                        candidate.setPartyNameCache(config.getString("candidates." + candidateUuidStr + ".partyNameCache"));
                        election.addCandidate(candidate);
                    }
                }

                if (config.isList("voters")) {
                    config.getStringList("voters").forEach(voterUuidStr -> election.getVoters().add(UUID.fromString(voterUuidStr)));
                }

                if (config.contains("winnerPlayerUUID")) election.setWinnerPlayerUUID(UUID.fromString(config.getString("winnerPlayerUUID")));
                if (config.contains("winnerPartyUUID")) election.setWinnerPartyUUID(UUID.fromString(config.getString("winnerPartyUUID")));

                if (config.isConfigurationSection("partySeatDistribution")) {
                    Map<UUID, Integer> seatDist = new HashMap<>();
                    ConfigurationSection seatSection = config.getConfigurationSection("partySeatDistribution");
                    for (String partyUuidStr : seatSection.getKeys(false)) {
                        seatDist.put(UUID.fromString(partyUuidStr), seatSection.getInt(partyUuidStr));
                    }
                    election.setPartySeatDistribution(seatDist);
                }

                // 如果选举已经结束或取消，则归档并跳过添加到 activeElections
                if (election.getStatus() == ElectionStatus.FINISHED || election.getStatus() == ElectionStatus.CANCELLED) {
                    archiveElectionFile(electionFile, election.getElectionId().toString() + ELECTION_FILE_EXTENSION);
                    plugin.getLogger().info("Archived " + election.getType() + " (ID: " + election.getElectionId() + ") for " + getContextName(election.getContextId(), election.getType()) + " as it was already concluded.");
                    continue;
                }

                activeElections.put(contextId, election); // 使用 contextId 作为 key
                loadedCount++;
                plugin.getLogger().info("Loaded active " + type + " for " + getContextName(contextId, type));

                // 恢复选举的定时任务 (如果适用)
                resumeScheduledTasksForElection(election);

            } catch (IOException | InvalidConfigurationException | IllegalArgumentException e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load election from file: " + electionFile.getName(), e);
                // 可以考虑将损坏的文件移动到 "corrupted" 文件夹
                File corruptedFile = new File(activeElectionsDataFolder.getParentFile(), "corrupted");
                if (!corruptedFile.exists()) corruptedFile.mkdirs();
                try {
                    Files.move(electionFile.toPath(), new File(corruptedFile, electionFile.getName()).toPath(), StandardCopyOption.REPLACE_EXISTING);
                    plugin.getLogger().warning("Moved corrupted election file " + electionFile.getName() + " to 'corrupted' folder.");
                } catch (IOException moveEx) {
                    plugin.getLogger().log(Level.SEVERE, "Could not move corrupted election file " + electionFile.getName(), moveEx);
                }
            }
        }
        plugin.getLogger().info("Successfully loaded " + loadedCount + " active elections.");
    }

    public void saveElectionState(Election election) {
        if (election == null) {
            plugin.getLogger().warning("Attempted to save a null election state.");
            return;
        }
        // 使用 contextId 和 type 组合或 electionId 作为文件名
        // 为了确保唯一性，并方便通过electionId查找，使用electionId作为文件名
        File electionFile = new File(activeElectionsDataFolder, election.getElectionId().toString() + ELECTION_FILE_EXTENSION);
        YamlConfiguration config = new YamlConfiguration();

        config.set("electionId", election.getElectionId().toString());
        config.set("contextId", election.getContextId().toString());
        config.set("type", election.getType().name());
        if (election.getNationGovernmentTypeCache() != null) {
            config.set("nationGovernmentTypeCache", election.getNationGovernmentTypeCache().name());
        }
        config.set("status", election.getStatus().name());
        config.set("startTime", election.getStartTime());
        config.set("endTime", election.getEndTime());
        config.set("registrationEndTime", election.getRegistrationEndTime());

        if (!election.getCandidates().isEmpty()) {
            for (Candidate candidate : election.getCandidates()) {
                String path = "candidates." + candidate.getPlayerUUID().toString();
                config.set(path + ".votes", candidate.getVotes());
                if (candidate.getPartyUUID() != null) {
                    config.set(path + ".partyUUID", candidate.getPartyUUID().toString());
                }
                if (candidate.getPlayerNameCache() != null) {
                    config.set(path + ".playerNameCache", candidate.getPlayerNameCache());
                }
                if (candidate.getPartyNameCache() != null) {
                    config.set(path + ".partyNameCache", candidate.getPartyNameCache());
                }
            }
        }

        if (!election.getVoters().isEmpty()) {
            config.set("voters", election.getVoters().stream().map(UUID::toString).collect(Collectors.toList()));
        }

        if (election.getWinnerPlayerUUID() != null) config.set("winnerPlayerUUID", election.getWinnerPlayerUUID().toString());
        if (election.getWinnerPartyUUID() != null) config.set("winnerPartyUUID", election.getWinnerPartyUUID().toString());

        if (election.getPartySeatDistribution() != null && !election.getPartySeatDistribution().isEmpty()) {
            election.getPartySeatDistribution().forEach((partyUUID, seats) ->
                    config.set("partySeatDistribution." + partyUUID.toString(), seats));
        }

        try {
            config.save(electionFile);
            plugin.getLogger().finer("Saved election state for ID: " + election.getElectionId());
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save election state for ID: " + election.getElectionId(), e);
        }
    }

    /**
     * 归档一个选举文件 (通常在选举结束后)。
     * @param electionFile 要归档的选举文件
     * @param archiveFileName 归档后的文件名
     */
    private void archiveElectionFile(File electionFile, String archiveFileName) {
        if (electionFile == null || !electionFile.exists()) return;
        File targetArchiveFile = new File(archivedElectionsDataFolder, archiveFileName);
        try {
            Files.move(electionFile.toPath(), targetArchiveFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            plugin.getLogger().info("Archived election file: " + electionFile.getName() + " to " + targetArchiveFile.getName());
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "Could not archive election file: " + electionFile.getName(), e);
            // Fallback: just delete if move fails, to prevent reloading it as active
            // electionFile.delete();
        }
    }

    /**
     * 当一个选举结束后，将其数据归档。
     * @param election 已结束的选举对象
     */
    public void archiveElection(Election election) {
        if (election == null || (election.getStatus() != ElectionStatus.FINISHED && election.getStatus() != ElectionStatus.CANCELLED)) {
            return;
        }
        plugin.getLogger().info("Archiving " + election.getType() + " (ID: " + election.getElectionId() + ") for " + getContextName(election.getContextId(), election.getType()));
        // 确保最后状态已保存
        saveElectionState(election);
        // 从活跃文件夹移动到归档文件夹
        File activeFile = new File(activeElectionsDataFolder, election.getElectionId().toString() + ELECTION_FILE_EXTENSION);
        archiveElectionFile(activeFile, election.getElectionId().toString() + "_" + System.currentTimeMillis() + ELECTION_FILE_EXTENSION); // 加时间戳避免重名
    }

    private void resumeScheduledTasksForElection(Election election) {
        long currentTime = System.currentTimeMillis();
        if (election.getStatus() == ElectionStatus.REGISTRATION) {
            if (currentTime < election.getRegistrationEndTime()) {
                long delayTicks = (election.getRegistrationEndTime() - currentTime) / 50L;
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        advanceElectionToVoting(election.getElectionId());
                    }
                }.runTaskLater(plugin, Math.max(1, delayTicks)); // 至少延迟1 tick
                plugin.getLogger().info("Rescheduled task to advance election " + election.getElectionId() + " to voting stage.");
            } else { // 登记时间已过，直接尝试推进
                advanceElectionToVoting(election.getElectionId());
            }
        } else if (election.getStatus() == ElectionStatus.VOTING) {
            if (currentTime < election.getEndTime()) {
                long delayTicks = (election.getEndTime() - currentTime) / 50L;
                new BukkitRunnable() {
                    @Override
                    public void run() {
                        finishElection(election.getElectionId());
                    }
                }.runTaskLater(plugin, Math.max(1, delayTicks));
                plugin.getLogger().info("Rescheduled task to finish election " + election.getElectionId() + ".");
            } else { // 投票时间已过，直接尝试结束
                finishElection(election.getElectionId());
            }
        }
    }


    // 新方法: 应用选举结果到 Towny (总统/总理成为国家领袖)
    private void applyElectionResultsToTowny(Election election) {
        if (election.getStatus() != ElectionStatus.FINISHED) return;

        Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
        if (nation == null) return;

        NationPolitics politics = nationManager.getNationPolitics(nation); // 获取政治数据对象
        GovernmentType currentGovType = politics.getGovernmentType(); // 使用当前的政体，而不是选举时的缓存

        OfflinePlayer newTownyKing = null; // 将成为 Towny King 的人
        OfflinePlayer newPrimeMinister = null; // 将获得“总理”头衔的人 (可能与Towny King是同一人)
        String townyKingRoleTitle = "";     // Towny King 在本插件中的角色名 (总统/总理)

        // 清除旧的总理头衔，因为选举结果可能会改变它
        politics.setPrimeMinisterUUID(null);


        if (election.getType() == ElectionType.PRESIDENTIAL) {
            if (election.getWinnerPlayerUUID() != null) {
                OfflinePlayer presidentElect = Bukkit.getOfflinePlayer(election.getWinnerPlayerUUID());
                if (currentGovType == GovernmentType.PRESIDENTIAL_REPUBLIC || currentGovType == GovernmentType.SEMI_PRESIDENTIAL_REPUBLIC) {
                    newTownyKing = presidentElect;
                    townyKingRoleTitle = "总统";
                }
                // 在半总统制，总统也是总理的任命者（或自身兼任），所以总统选举结果优先影响Towny King
                // 并且，如果总统制，总统也是政府首脑，可认为也是“总理”角色（虽然不这么叫）
                if (currentGovType == GovernmentType.PRESIDENTIAL_REPUBLIC) {
                    newPrimeMinister = presidentElect; // 总统兼任政府首脑
                }
                // 对于半总统制，总理通常由议会选举后的多数党领袖担任，由总统任命。
                // 这里我们只处理总统选举，总理的任命由议会选举后或专门命令处理。
            }
        } else if (election.getType() == ElectionType.PARLIAMENTARY) {
            if (election.getWinnerPartyUUID() != null) {
                Party winningParty = partyManager.getParty(election.getWinnerPartyUUID());
                if (winningParty != null && winningParty.getLeader().isPresent()) {
                    OfflinePlayer majorityLeader = Bukkit.getOfflinePlayer(winningParty.getLeader().get().getPlayerId());
                    newPrimeMinister = majorityLeader; // 议会多数党领袖成为总理（头衔）

                    if (currentGovType == GovernmentType.PARLIAMENTARY_REPUBLIC || currentGovType == GovernmentType.CONSTITUTIONAL_MONARCHY) {
                        newTownyKing = majorityLeader; // 总理成为实际的Towny King
                        townyKingRoleTitle = "总理";
                    }
                    // 对于半总统制，议会选举后，如果多数党领袖与当前总统（Towny King）同党，可自动认为他是总理。
                    // 否则，需要总统通过命令任命。这里暂时不自动设置Towny King。
                    // Towny King 在半总统制下由总统选举决定。
                }
            }
        }

        // 更新 NationPolitics 中的总理UUID
        if (newPrimeMinister != null) {
            politics.setPrimeMinisterUUID(newPrimeMinister.getUniqueId());
            plugin.getLogger().info("Set " + newPrimeMinister.getName() + " as Prime Minister (titular) for " + nation.getName());
        }
        nationManager.saveNationPolitics(politics); // 保存 NationPolitics 的更新


        // 设置 Towny King
        if (newTownyKing != null && newTownyKing.getName() != null) {
            Resident newKingResident = TownyAPI.getInstance().getResident(newTownyKing.getUniqueId());
            // 确保新国王是该国公民
            if (newKingResident != null && newKingResident.hasNation() && newKingResident.getNationOrNull().equals(nation)) {
                try {
                    if (nation.hasKing() && nation.getKing().equals(newKingResident)) {
                        plugin.getLogger().info(townyKingRoleTitle + " " + newTownyKing.getName() + " is already the King of " + nation.getName() + ". No change to Towny leadership.");
                    } else {
                        String oldKingName = nation.hasKing() ? nation.getKing().getName() : "无";
                        nation.setKing(newKingResident); // 设置新的Towny King
                        TownyAPI.getInstance().getDataSource().saveNation(nation); // 持久化Towny的Nation对象
                        plugin.getLogger().info("Set " + newTownyKing.getName() + " (as " + townyKingRoleTitle + ") as the new Towny King of " + nation.getName() + ". Previous king: " + oldKingName);

                        String kingChangeMessage = messageManager.getMessage("nation-new-towny-king",
                                "nation_name", nation.getName(),
                                "king_name", newTownyKing.getName(),
                                "role_title", townyKingRoleTitle);
                        Bukkit.broadcastMessage(kingChangeMessage);
                    }
                } catch (Exception e) {
                    plugin.getLogger().log(Level.SEVERE, "Error setting Towny King for nation " + nation.getName(), e);
                }
            } else {
                plugin.getLogger().warning("Cannot set " + newTownyKing.getName() + " as Towny King of " + nation.getName() + ". Target is not a resident of this nation or does not exist in Towny.");
            }
        } else if (election.getType() == ElectionType.PARLIAMENTARY &&
                (currentGovType == GovernmentType.PARLIAMENTARY_REPUBLIC || currentGovType == GovernmentType.CONSTITUTIONAL_MONARCHY) &&
                newPrimeMinister == null) {
            // 议会制/君主立宪制，但未能产生总理（例如没有多数党或多数党没领袖）
            // 这种情况可能导致国家没有Towny King，或者需要其他机制（如管理员指定或重新选举）
            plugin.getLogger().warning("Parliamentary election for " + nation.getName() + " did not result in a new Prime Minister to become Towny King.");
            // 可以考虑是否要移除旧的Towny King，但这可能导致国家无主，需要谨慎。
            // if (nation.hasKing()) { nation.removeKing(); TownyAPI.getInstance().getDataSource().saveNation(nation); }
        }
    }

    public void scheduleNextElectionForNation(UUID nationUUID) {
        Nation nation = TownyAPI.getInstance().getNation(nationUUID);
        if (nation == null) return;

        // 取消可能存在的旧任务 (针对整个国家的，而不是特定选举类型)
        // 如果我们为不同类型的选举有不同的调度，这里需要更细致的key
        cancelScheduledTask(nationUUID); // 假设一个国家一次只调度一个“主”选举周期

        NationPolitics politics = nationManager.getNationPolitics(nation);
        GovernmentType govType = politics.getGovernmentType();

        // 决定需要调度哪种类型的选举 (或两者)
        List<ElectionType> typesToSchedule = new ArrayList<>();
        if (govType.hasParliament()) typesToSchedule.add(ElectionType.PARLIAMENTARY);
        if (govType.hasDirectPresidentialElection()) typesToSchedule.add(ElectionType.PRESIDENTIAL);

        if (typesToSchedule.isEmpty()) {
            plugin.getLogger().info("[ElectionManager] Nation " + nation.getName() + " (" + govType.getDisplayName() + ") does not require scheduled elections.");
            return;
        }

        for (ElectionType typeToSchedule : typesToSchedule) {
            // 检查此类型选举是否已在活跃进行中
            final ElectionType finalType = typeToSchedule; // For lambda
            boolean isActive = activeElections.values().stream().anyMatch(e ->
                    e.getContextId().equals(nationUUID) &&
                            e.getType() == finalType &&
                            e.getStatus() != ElectionStatus.FINISHED &&
                            e.getStatus() != ElectionStatus.CANCELLED
            );
            if (isActive) {
                plugin.getLogger().info("[ElectionManager] Nation " + nation.getName() + " already has an active " + finalType.getDisplayName() + ". Skipping schedule for this type.");
                continue;
            }

            long electionIntervalTicks = getConfiguredElectionIntervalTicks(govType, finalType);
            if (electionIntervalTicks <= 0) {
                plugin.getLogger().info("[ElectionManager] " + finalType.getDisplayName() + " interval not configured for " + nation.getName() + ". Automatic election disabled for this type.");
                continue;
            }

            long lastCompletionTime = politics.getLastElectionCompletionTime(finalType);
            long currentTime = System.currentTimeMillis();
            long nextScheduledTimeMillis;

            if (lastCompletionTime == 0L) { // 从未举行过，或数据丢失
                nextScheduledTimeMillis = currentTime + (electionIntervalTicks * 50L); // 从现在开始算第一个周期
                plugin.getLogger().info("[ElectionManager] No previous " + finalType.getDisplayName() + " completion time for " + nation.getName() + ". Scheduling first cycle.");
            } else {
                nextScheduledTimeMillis = lastCompletionTime + (electionIntervalTicks * 50L);
            }

            long delayMillis = nextScheduledTimeMillis - currentTime;
            long delayTicks;

            if (delayMillis <= 0) { // 已经到期或过期
                plugin.getLogger().info("[ElectionManager] " + finalType.getDisplayName() + " for " + nation.getName() + " is due or overdue. Starting soon (delaying 10s).");
                delayTicks = 20L * 10; // 延迟10秒启动，避免同时启动过多
            } else {
                delayTicks = delayMillis / 50L;
            }

            // 使用唯一的任务键，例如 nationUUID + typeName
            String taskKey = nationUUID.toString() + "_" + finalType.name();
            cancelScheduledTask(taskKey); // 取消这个特定类型选举的旧任务

            plugin.getLogger().info("[ElectionManager] Scheduling next " + finalType.getDisplayName() + " for nation " + nation.getName() + " in approx. " + String.format("%.2f", delayTicks / 20.0 / 60.0) + " minutes.");

            BukkitTask task = new BukkitRunnable() {
                @Override
                public void run() {
                    // 再次检查政体和国家是否存在
                    Nation currentNation = TownyAPI.getInstance().getNation(nationUUID);
                    if (currentNation == null) {
                        plugin.getLogger().warning("[ElectionManager] Scheduled " + finalType.getDisplayName() + " task ran for nation " + nationUUID + " but it no longer exists.");
                        cancelScheduledTask(taskKey);
                        return;
                    }
                    NationPolitics currentPolitics = nationManager.getNationPolitics(currentNation);
                    GovernmentType currentGovType = currentPolitics.getGovernmentType();
                    boolean shouldRunThisType = (finalType == ElectionType.PARLIAMENTARY && currentGovType.hasParliament()) ||
                            (finalType == ElectionType.PRESIDENTIAL && currentGovType.hasDirectPresidentialElection());

                    if (shouldRunThisType) {
                        plugin.getLogger().info("[ElectionManager] Starting scheduled " + finalType.getDisplayName() + " for nation: " + currentNation.getName());
                        startNationElection(currentNation.getUUID(), finalType);
                        // 重新安排下一次 (startNationElection 内部不再自动重调度，由这里统一管理周期)
                        // scheduleNextElectionForNation(nationUUID); // 这会导致无限递归调用，应该只调度一次然后等下个周期
                    } else {
                        plugin.getLogger().info("[ElectionManager] Scheduled " + finalType.getDisplayName() + " task ran for nation " + currentNation.getName() + ", but its government type " + currentGovType.getDisplayName() + " no longer requires this election type.");
                    }
                    // 无论是否启动，此特定类型的周期性任务都完成了，等待 scheduleNextElectionsForAllValidContexts 或政体变更时重新安排
                    scheduledElectionTasks.remove(taskKey); // 移除已执行的任务
                    // 重新调度下一次应该在选举结束后，或者在下一次全局扫描时
                    // 为了简化，我们让全局扫描 (scheduleNextElectionsForAllValidContexts) 来处理周期的延续
                    // 或者，在选举成功结束后，直接调用 scheduleNextElectionForNation(nationUUID) 来安排下个周期。
                    // 我倾向于在选举结束后立即安排下一次。
                    if (shouldRunThisType) { // 如果成功启动了，那么在它结束后再安排
                        // ElectionManager.finishElection -> applyElectionResultsToTowny -> (更新lastCompletionTime)
                        // 然后可以从 finishElection 的末尾调用 scheduleNextElectionForNation(nationUUID);
                        // (但要注意避免一个国家的多个选举类型互相干扰调度)
                        // 目前的设计是，每个类型的选举完成后，会独立更新其 lastCompletionTime。
                        // scheduleNextElectionForNation(nationUUID) 会为所有该国需要的选举类型重新安排。
                        // **修正**: 在 finishElection 结束后，直接调用 scheduleNextElectionForNation(nation.getUUID())
                        // 这样当议会选举结束后，它会尝试重新调度议会和总统（如果需要）。
                    }
                }
            }.runTaskLater(plugin, Math.max(1, delayTicks)); // 确保至少延迟1 tick
            scheduledElectionTasks.put(UUID.fromString(taskKey), task);
        }
    }

    // 在 onGovernmentChange 方法中，当政体改变后：
    public void onGovernmentChange(Nation nation, GovernmentType oldType, GovernmentType newType) {
        // ... (取消活跃选举的逻辑) ...
        NationPolitics politics = nationManager.getNationPolitics(nation);
        politics.clearAllElectionCompletionTimes(); // 政体变更，重置选举周期记录
        nationManager.saveNationPolitics(politics);

        // 重新安排选举周期
        String oldParliamentTaskKey = nation.getUUID().toString() + "_" + ElectionType.PARLIAMENTARY.name();
        String oldPresidentialTaskKey = nation.getUUID().toString() + "_" + ElectionType.PRESIDENTIAL.name();
        cancelScheduledTask(oldParliamentTaskKey);
        cancelScheduledTask(oldPresidentialTaskKey);

        scheduleNextElectionForNation(nation.getUUID()); // 会根据新政体安排
    }

    // getConfiguredElectionIntervalTicks 需要区分选举类型
    private long getConfiguredElectionIntervalTicks(GovernmentType govType, ElectionType electionType) {
        String path = "elections.nation_election_schedule.";
        if (electionType == ElectionType.PARLIAMENTARY && govType.hasParliament()) {
            path += "parliamentary.interval_days";
        } else if (electionType == ElectionType.PRESIDENTIAL && govType.hasDirectPresidentialElection()) {
            path += "presidential.interval_days";
        } else {
            return 0; // 此政体不支持此类型选举
        }
        double days = plugin.getConfig().getDouble(path, 0); // 默认0天，表示不自动调度
        return (long) (days * 24 * 60 * 60 * 20); // days to ticks
    }

    // cancelScheduledTask 需要接受 String key
    private void cancelScheduledTask(String taskKey) {
        BukkitTask existingTask = scheduledElectionTasks.remove(taskKey);
        if (existingTask != null) {
            try {
                existingTask.cancel();
            } catch (Exception e) { /* ignore */ }
        }
    }

    // 在 ElectionManager 的 shutdown 方法中：
    public void shutdown() {
        for (UUID taskKey : new HashSet<>(scheduledElectionTasks.keySet())) {
            cancelScheduledTask(taskKey);
        }
        // ... (保存选举状态) ...
    }

    private void determineElectionResults(Election election) {
        GovernmentType govType = election.getNationGovernmentTypeCache(); // 在国家选举时才有意义
        List<Candidate> candidates = new ArrayList<>(election.getCandidates()); // 获取副本进行操作
        candidates.sort(Comparator.comparingInt(Candidate::getVotes).reversed()); // 按票数降序

        if (candidates.isEmpty() && election.getType() != ElectionType.PARLIAMENTARY) { // 议会选举可能没有个人候选人，而是投党
            election.setWinnerPlayerUUID(null);
            if (election.getType() == ElectionType.PARLIAMENTARY) {
                election.setWinnerPartyUUID(null);
                election.setPartySeatDistribution(new HashMap<>());
            }
            plugin.getLogger().info("No candidates in " + election.getType() + " election: " + election.getElectionId());
            // 在 applyElectionResultsToTowny 之前调用，以确保 NationPolitics 更新
            updateLastCompletionTime(election);
            applyElectionResultsToTowny(election);
            return;
        }

        switch (election.getType()) {
            case PRESIDENTIAL:
            case PARTY_LEADER: // 党魁选举逻辑与总统选举类似
                handleSingleWinnerElection(election, candidates);
                break;

            case PARLIAMENTARY:
                // 议会选举的核心是席位分配和确定执政党/总理
                // 假设投票是针对候选人的，候选人属于某个政党
                Map<UUID, Integer> partyTotalVotes = new HashMap<>();
                Map<UUID, List<Candidate>> candidatesByParty = new HashMap<>();

                for (Candidate c : candidates) {
                    if (c.getPartyUUID() != null) {
                        partyTotalVotes.merge(c.getPartyUUID(), c.getVotes(), Integer::sum);
                        candidatesByParty.computeIfAbsent(c.getPartyUUID(), k -> new ArrayList<>()).add(c);
                    } else {
                        // 处理独立候选人（如果允许他们参与议会并可能获得席位）
                        // 简单起见，当前假设议会候选人必须有政党
                        plugin.getLogger().finer("Parliamentary candidate " + c.getPlayerNameCache() + " has no party, votes not counted for party totals.");
                    }
                }
                // 如果议会选举是直接投给政党，而不是候选人，则需要另一种计票方式

                if (partyTotalVotes.isEmpty()) {
                    plugin.getLogger().info("No parties received votes in parliamentary election: " + election.getElectionId());
                    election.setWinnerPartyUUID(null);
                    election.setPartySeatDistribution(new HashMap<>());
                } else {
                    int totalParliamentSeats = getConfiguredTotalParliamentSeats(election.getContextId(), govType);
                    double representationThresholdPercent = plugin.getConfig().getDouble("elections.parliament.representation_threshold_percent", 0.0);

                    // 过滤掉未达到得票率门槛的政党
                    long totalVotesCastInElection = partyTotalVotes.values().stream().mapToLong(Integer::intValue).sum();
                    Map<UUID, Integer> eligiblePartyVotes = partyTotalVotes.entrySet().stream()
                            .filter(entry -> {
                                if (totalVotesCastInElection == 0) return false; // 避免除零
                                double percentage = (double) entry.getValue() * 100.0 / totalVotesCastInElection;
                                return percentage >= representationThresholdPercent;
                            })
                            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

                    if(eligiblePartyVotes.isEmpty() && !partyTotalVotes.isEmpty()){
                        plugin.getLogger().info("No parties met the representation threshold of " + representationThresholdPercent + "% in parliamentary election: " + election.getElectionId());
                        election.setWinnerPartyUUID(null);
                        election.setPartySeatDistribution(new HashMap<>());
                    } else {
                        Map<UUID, Integer> seatDistribution = calculateSeatsLargestRemainderHare(eligiblePartyVotes, totalParliamentSeats);
                        election.setPartySeatDistribution(seatDistribution);

                        // 确定多数党
                        UUID majorityPartyUUID = seatDistribution.entrySet().stream()
                                .max(Map.Entry.comparingByValue())
                                .map(Map.Entry::getKey)
                                .orElse(null); // 如果没有党派获得席位，则为null

                        election.setWinnerPartyUUID(majorityPartyUUID);
                        if (majorityPartyUUID != null) {
                            plugin.getLogger().info("Majority party in " + getContextName(election.getContextId(), election.getType()) + " is " + partyManager.getParty(majorityPartyUUID).getName() + " with " + seatDistribution.get(majorityPartyUUID) + " seats.");
                        } else {
                            plugin.getLogger().info("No majority party determined in " + getContextName(election.getContextId(), election.getType()) + " parliamentary election.");
                        }
                    }
                }
                break;
        }
        // 必须在 applyElectionResultsToTowny 之前调用，以确保NationPolitics中的时间戳被更新
        updateLastCompletionTime(election);
        applyElectionResultsToTowny(election); // 应用结果到Towny（如设置国王）
    }

    private void handleSingleWinnerElection(Election election, List<Candidate> sortedCandidates) {
        if (sortedCandidates.isEmpty()) {
            election.setWinnerPlayerUUID(null);
            plugin.getLogger().info("No candidates in single-winner election: " + election.getElectionId());
            return;
        }

        List<Candidate> leadingCandidates = election.getLeadingCandidates(); // 使用Election类中的方法获取所有最高票者

        if (leadingCandidates.size() == 1) {
            election.setWinnerPlayerUUID(leadingCandidates.get(0).getPlayerUUID());
        } else if (leadingCandidates.size() > 1) { // 平票
            plugin.getLogger().info("Tie detected in " + election.getType() + " election " + election.getElectionId() + " between: " +
                    leadingCandidates.stream().map(c -> c.getPlayerNameCache() != null ? c.getPlayerNameCache() : c.getPlayerUUID().toString()).collect(Collectors.joining(", ")));

            String tieBreakingMethod = plugin.getConfig().getString("elections.tie_breaking_method", "RANDOM").toUpperCase();
            switch (tieBreakingMethod) {
                case "RE_ELECTION":
                    // TODO: 触发决选。这需要创建一个新的Election对象，
                    // 候选人是leadingCandidates，并通知玩家。
                    plugin.getLogger().warning("RE_ELECTION tie-breaking not yet implemented. Defaulting to RANDOM for election " + election.getElectionId());
                    election.setWinnerPlayerUUID(leadingCandidates.get(new Random().nextInt(leadingCandidates.size())).getPlayerUUID());
                    break;
                case "ADMIN_DECIDES":
                    // TODO: 通知在线管理员，并等待管理员通过命令指定获胜者。
                    // 在此期间，选举状态可能需要变为 "PENDING_ADMIN_DECISION"。
                    plugin.getLogger().warning("ADMIN_DECIDES tie-breaking not yet implemented. Defaulting to RANDOM for election " + election.getElectionId());
                    broadcastToAdmins("election-tie-admin-decision-needed",
                            "election_id", election.getElectionId().toString(),
                            "type", election.getType().getDisplayName(),
                            "context", getContextName(election.getContextId(),election.getType()),
                            "candidates", leadingCandidates.stream().map(c -> c.getPlayerNameCache() != null ? c.getPlayerNameCache() : c.getPlayerUUID().toString()).collect(Collectors.joining(", "))
                    );
                    // 暂时随机选一个，避免选举卡住
                    election.setWinnerPlayerUUID(leadingCandidates.get(new Random().nextInt(leadingCandidates.size())).getPlayerUUID());
                    break;
                case "RANDOM":
                default:
                    election.setWinnerPlayerUUID(leadingCandidates.get(new Random().nextInt(leadingCandidates.size())).getPlayerUUID());
                    plugin.getLogger().info("Randomly selected " + Bukkit.getOfflinePlayer(election.getWinnerPlayerUUID()).getName() + " as winner due to tie.");
                    break;
            }
        } else { // leadingCandidates 为空，理论上不应发生，因为 sortedCandidates 不为空
            election.setWinnerPlayerUUID(null);
        }
    }

    /**
     * 使用最大余额法 (黑尔数额) 分配议会席位。
     * @param partyVotes 各政党获得的票数 Map<PartyUUID, Votes>
     * @param totalSeats 要分配的总席位数
     * @return 各政党获得的席位数 Map<PartyUUID, Seats>
     */
    private Map<UUID, Integer> calculateSeatsLargestRemainderHare(Map<UUID, Integer> partyVotes, int totalSeats) {
        Map<UUID, Integer> seatDistribution = new HashMap<>();
        if (partyVotes.isEmpty() || totalSeats <= 0) return seatDistribution;

        long totalVoteCount = partyVotes.values().stream().mapToLong(Integer::intValue).sum();
        if (totalVoteCount == 0) return seatDistribution; // 没有有效投票

        // 计算黑尔数额 (Hare Quota)
        double quota = (double) totalVoteCount / totalSeats;
        if (quota == 0) { // 如果总票数为0但有政党（不太可能，除非过滤后为空），或者总席位数为0
            plugin.getLogger().warning("Quota is zero in seat calculation. Total votes: " + totalVoteCount + ", Total seats: " + totalSeats);
            return seatDistribution; //无法分配
        }


        Map<UUID, Double> partyRemainders = new HashMap<>();
        int seatsAutomaticallyAllocated = 0;

        // 第一轮：分配整数商的席位
        for (Map.Entry<UUID, Integer> entry : partyVotes.entrySet()) {
            UUID partyId = entry.getKey();
            int votes = entry.getValue();
            int seats = (int) (votes / quota);
            seatDistribution.put(partyId, seats);
            partyRemainders.put(partyId, votes % quota); // 或者 votes - (seats * quota)
            seatsAutomaticallyAllocated += seats;
        }

        // 第二轮：根据最大余额分配剩余席位
        int remainingSeats = totalSeats - seatsAutomaticallyAllocated;
        if (remainingSeats > 0) {
            // 将余额从大到小排序
            List<Map.Entry<UUID, Double>> sortedRemainders = partyRemainders.entrySet().stream()
                    .sorted(Map.Entry.<UUID, Double>comparingByValue().reversed()
                            // 如果余额相同，可以增加一个次要排序规则，例如按总票数（或随机）
                            .thenComparing((e1, e2) -> {
                                if (e1.getValue().equals(e2.getValue())) { // 余额相同
                                    return partyVotes.get(e2.getKey()).compareTo(partyVotes.get(e1.getKey())); // 票多者优先
                                }
                                return 0; // 正常比较
                            }))
                    .collect(Collectors.toList());

            for (int i = 0; i < remainingSeats && i < sortedRemainders.size(); i++) {
                UUID partyIdToGetSeat = sortedRemainders.get(i).getKey();
                seatDistribution.merge(partyIdToGetSeat, 1, Integer::sum);
            }
        }
        return seatDistribution;
    }

    // 新增：更新上次选举完成时间的方法
    private void updateLastCompletionTime(Election election) {
        if (election.getStatus() != ElectionStatus.FINISHED && election.getStatus() != ElectionStatus.CANCELLED) return;

        if (election.getType() == ElectionType.PARLIAMENTARY || election.getType() == ElectionType.PRESIDENTIAL) {
            Nation nation = TownyAPI.getInstance().getNation(election.getContextId());
            if (nation != null) {
                NationPolitics politics = nationManager.getNationPolitics(nation);
                // 只有成功完成的选举才更新完成时间，取消的不更新，以便尽快重新调度
                if (election.getStatus() == ElectionStatus.FINISHED) {
                    politics.setLastElectionCompletionTime(election.getType(), System.currentTimeMillis());
                    nationManager.saveNationPolitics(politics);
                    plugin.getLogger().info("Recorded " + election.getType() + " completion time for nation " + nation.getName());
                }
            }
        } else if (election.getType() == ElectionType.PARTY_LEADER) {
            // 对于政党领袖选举，也可以记录完成时间，如果政党数据结构支持的话
            // Party party = partyManager.getParty(election.getContextId());
            // if (party != null && election.getStatus() == ElectionStatus.FINISHED) {
            //     party.setLastLeaderElectionTime(System.currentTimeMillis());
            //     partyManager.saveParty(party);
            // }
        }
    }

    private void broadcastToAdmins(String messageKey, Object... placeholders) {
        String message = messageManager.getMessage(messageKey, placeholders);
        plugin.getServer().getOnlinePlayers().stream()
                .filter(p -> p.hasPermission("townypolitical.admin.notifications")) // 需要新权限
                .forEach(p -> p.sendMessage(plugin.getMessageManager().getPrefix() + message));
        plugin.getLogger().info("[Admin Notification] " + message); // 也记录到控制台
    }

    public void scheduleNextElectionsForAllValidContexts() {
        if (TownyAPI.getInstance() == null) {
            plugin.getLogger().warning("[ElectionManager] TownyAPI not available during scheduleNextElectionsForAllValidContexts. Skipping.");
            return;
        }
        plugin.getLogger().info("[ElectionManager] Performing initial scan and scheduling for all nations...");
        for (Nation nation : TownyAPI.getInstance().getNations()) {
            scheduleNextElectionForNation(nation.getUUID()); // 为每个国家评估并安排其所有需要的选举类型
        }
        // 政党领袖选举的调度也可以在这里进行（如果启用了自动周期）
        if (plugin.getConfig().getLong("party.leader_election.auto_schedule_interval_days", 0) > 0) {
            for (Party party : partyManager.getAllParties()) {
                scheduleNextPartyLeaderElection(party.getPartyId());
            }
        }
    }


    // finishElection 方法
    public void finishElection(UUID electionId) {
        Election election = findElectionById(electionId); // findElectionById 需要能从 activeElectionsById 找到
        if (election == null || election.getStatus() != ElectionStatus.VOTING) {
            plugin.getLogger().finer("[ElectionManager] finishElection called for non-existent or non-voting election: " + electionId);
            return; // 选举不存在或状态不正确
        }

        plugin.getLogger().info("[ElectionManager] Finishing " + election.getType().getDisplayName() + " (ID: " + election.getElectionId() + ") for: " + getContextName(election.getContextId(), election.getType()));
        election.setStatus(ElectionStatus.COUNTING); // 进入计票状态
        // (可选) 保存一次计票中状态，如果计票过程可能很长或中断
        // saveElectionState(election);

        determineElectionResults(election); // 这会计算结果，更新winner字段, 更新lastCompletionTime, 并调用applyElectionResultsToTowny

        election.setStatus(ElectionStatus.FINISHED); // 最终状态
        saveElectionState(election); // 保存包含最终结果和状态的选举数据
        announceElectionResults(election); // 向玩家宣布结果

        // 结果公示期后归档
        long displayDurationSeconds = plugin.getConfig().getLong("elections.results_display_duration_seconds", 43200);
        if (displayDurationSeconds > 0) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    archiveElection(election);
                    activeElections.remove(election.getElectionId()); // 从活跃列表移除
                }
            }.runTaskLater(plugin, displayDurationSeconds * 20L);
        } else {
            archiveElection(election);
            activeElections.remove(election.getElectionId()); // 从活跃列表移除
        }


        // 安排下一次选举 (对于国家级周期性选举)
        if (election.getType() == ElectionType.PARLIAMENTARY || election.getType() == ElectionType.PRESIDENTIAL) {
            UUID nationUUID = election.getContextId();
            Nation nationContext = TownyAPI.getInstance().getNation(nationUUID);
            if (nationContext != null) {
                plugin.getLogger().info("[ElectionManager] Scheduling next election cycle for nation " + nationContext.getName() + " after completion of " + election.getType().getDisplayName());
                scheduleNextElectionForNation(nationUUID); // 这会为该国所有需要的类型重新评估和调度
            }
        } else if (election.getType() == ElectionType.PARTY_LEADER) {
            Party partyContext = partyManager.getParty(election.getContextId());
            if (partyContext != null && plugin.getConfig().getLong("party.leader_election.auto_schedule_interval_days", 0) > 0) {
                plugin.getLogger().info("[ElectionManager] Scheduling next leader election for party " + partyContext.getName());
                scheduleNextPartyLeaderElection(partyContext.getPartyId());
            }
        }
    }

    // scheduleNextPartyLeaderElection (新方法)
    public void scheduleNextPartyLeaderElection(UUID partyId) {
        Party party = partyManager.getParty(partyId);
        if (party == null) return;

        long intervalDays = plugin.getConfig().getLong("party.leader_election.auto_schedule_interval_days", 0);
        if (intervalDays <= 0) return; // 禁用自动调度

        // 检查是否已有活跃的党内领袖选举
        boolean isActive = activeElections.values().stream().anyMatch(e ->
                e.getContextId().equals(partyId) &&
                        e.getType() == ElectionType.PARTY_LEADER &&
                        e.getStatus() != ElectionStatus.FINISHED &&
                        e.getStatus() != ElectionStatus.CANCELLED
        );
        if (isActive) {
            plugin.getLogger().info("[ElectionManager] Party " + party.getName() + " already has an active leader election. Skipping schedule.");
            return;
        }

        // 检查成员数量是否达到触发自动选举的阈值
        int minMembers = plugin.getConfig().getInt("party.leader_election.min_members_to_auto_elect", 5);
        if (party.getOfficialMemberIds().size() < minMembers) {
            plugin.getLogger().info("[ElectionManager] Party " + party.getName() + " has less than " + minMembers + " members. Automatic leader election skipped.");
            return;
        }


        long intervalTicks = intervalDays * 24 * 60 * 60 * 20;
        // 政党也需要一个地方存储上次领袖选举完成时间，我们暂时假设 Party 对象有这个字段 (或 ElectionManager 内部管理)
        // long lastCompletionTime = party.getLastLeaderElectionCompletionTime(); // 假设
        long lastCompletionTime = 0L; // 简化：如果 Party 对象没有这个，每次都从现在开始算
        // TODO: 为 Party 对象添加 lastLeaderElectionTime 字段及持久化

        long currentTime = System.currentTimeMillis();
        long nextScheduledTimeMillis = (lastCompletionTime == 0L) ? (currentTime + intervalTicks * 50L) : (lastCompletionTime + intervalTicks * 50L);
        long delayMillis = nextScheduledTimeMillis - currentTime;
        long delayTicks = (delayMillis <= 0) ? (20L * 15) : (delayMillis / 50L); // 过期则15秒后

        String taskKey = partyId.toString() + "_" + ElectionType.PARTY_LEADER.name();
        cancelScheduledTask(taskKey);

        plugin.getLogger().info("[ElectionManager] Scheduling next leader election for party " + party.getName() + " in approx. " + String.format("%.2f", delayTicks / 20.0 / 60.0) + " minutes.");

        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                Party currentParty = partyManager.getParty(partyId);
                if (currentParty == null || currentParty.getOfficialMemberIds().size() < minMembers) {
                    cancelScheduledTask(taskKey);
                    return;
                }
                plugin.getLogger().info("[ElectionManager] Starting scheduled leader election for party: " + currentParty.getName());
                startPartyLeaderElection(currentParty.getPartyId()); // 新方法
                // 重新调度会在 finishElection 中处理
                scheduledElectionTasks.remove(taskKey);
            }
        }.runTaskLater(plugin, Math.max(1, delayTicks));
        scheduledElectionTasks.put(UUID.fromString(taskKey), task);
    }

    // startPartyLeaderElection (新方法)
    public Election startPartyLeaderElection(UUID partyId) {
        Party party = partyManager.getParty(partyId);
        if (party == null) {
            plugin.getLogger().warning("[ElectionManager] Attempted to start leader election for non-existent party: " + partyId);
            return null;
        }

        boolean isActive = activeElections.values().stream().anyMatch(e ->
                e.getContextId().equals(partyId) &&
                        e.getType() == ElectionType.PARTY_LEADER &&
                        e.getStatus() != ElectionStatus.FINISHED &&
                        e.getStatus() != ElectionStatus.CANCELLED
        );
        if (isActive) {
            messageManager.sendMessage(Bukkit.getConsoleSender(), "election-already-active-party", "party", party.getName());
            return activeElections.values().stream().filter(e -> e.getContextId().equals(partyId) && e.getType() == ElectionType.PARTY_LEADER).findFirst().orElse(null);
        }

        UUID electionId = UUID.randomUUID();
        Election election = new Election(electionId, partyId, ElectionType.PARTY_LEADER);

        long registrationDuration = plugin.getConfig().getLong("party.leader_election.registration_duration_seconds", 43200) * 1000L;
        long votingDuration = plugin.getConfig().getLong("party.leader_election.voting_duration_seconds", 86400) * 1000L;

        election.setRegistrationEndTime(System.currentTimeMillis() + registrationDuration);
        election.setStartTime(System.currentTimeMillis());
        election.setEndTime(election.getRegistrationEndTime() + votingDuration);
        election.setStatus(ElectionStatus.REGISTRATION);

        activeElections.put(electionId, election);
        saveElectionState(election);

        broadcastToPartyMembers(party, "election-registration-start-party-leader", "party_name", party.getName());
        plugin.getLogger().info("[ElectionManager] Party Leader election registration started for party: " + party.getName());

        new BukkitRunnable() {
            @Override
            public void run() {
                advanceElectionToVoting(election.getElectionId());
            }
        }.runTaskLater(plugin, registrationDuration / 50L);

        return election;
    }

    // broadcastToPartyMembers 辅助方法
    private void broadcastToPartyMembers(Party party, String messageKey, Object... placeholders) {
        if (party == null) return;
        String message = messageManager.getMessage(messageKey, placeholders);
        for (PartyMember member : party.getOfficialMemberIds().stream().map(uuid -> party.getMember(uuid).orElse(null)).filter(Objects::nonNull).collect(Collectors.toList())) {
            OfflinePlayer offlineP = member.getOfflinePlayer();
            if (offlineP.isOnline() && offlineP.getPlayer() != null) {
                offlineP.getPlayer().sendMessage(plugin.getMessageManager().getPrefix() + message);
            }
        }
        plugin.getLogger().info("[Party Broadcast: " + party.getName() + "] " + message);
    }


    // applyElectionResultsToTowny 需要确保在设置King之前，旧的King（如果是通过本插件设置的）的特殊状态（如果有的话）被清除
    // 目前我们的设计是直接覆盖 Towny 的 King，Towny 本身会处理旧 King 的移除。

    // findElectionById 方法，应该从 activeElectionsById 查找
    private Election findElectionById(UUID electionId) {
        return activeElections.get(electionId); // 直接从ID映射中获取
    }

    // getActiveElection(contextUUID, type) 仍然需要遍历，或者我们改变activeElections的结构
    public Election getActiveElection(UUID contextUUID, ElectionType type) {
        return activeElections.values().stream()
                .filter(e -> e.getContextId().equals(contextUUID) &&
                        e.getType() == type &&
                        e.getStatus() != ElectionStatus.FINISHED &&
                        e.getStatus() != ElectionStatus.CANCELLED)
                .findFirst().orElse(null);
    }

    // getAllActiveElectionsForContext(contextUUID)
    public List<Election> getAllActiveElectionsForContext(UUID contextUUID) {
        return activeElections.values().stream()
                .filter(e -> e.getContextId().equals(contextUUID) &&
                        e.getStatus() != ElectionStatus.FINISHED &&
                        e.getStatus() != ElectionStatus.CANCELLED)
                .collect(Collectors.toList());
    }

    public Optional<Election> getLatestFinishedElection(UUID contextUUID, ElectionType type) {
        // 首先从当前活跃（可能在公示期）的选举中查找
        Optional<Election> foundInMemory = activeElections.values().stream()
                .filter(e -> e.getContextId().equals(contextUUID) &&
                        e.getType() == type &&
                        e.getStatus() == ElectionStatus.FINISHED)
                .max(Comparator.comparingLong(Election::getEndTime)); // 按结束时间取最新的

        if (foundInMemory.isPresent()) {
            return foundInMemory;
        }
        plugin.getLogger().finer("No finished election found in active memory for context " + contextUUID + ", type " + type + ". Archive search not yet implemented.");
        return Optional.empty();
    }
}