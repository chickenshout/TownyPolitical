package top.chickenshout.townypolitical.managers;
import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.configuration.file.YamlConfiguration;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.data.Party;
import top.chickenshout.townypolitical.data.PartyMember;
import top.chickenshout.townypolitical.economy.EconomyService;
import top.chickenshout.townypolitical.enums.PartyRole;
import top.chickenshout.townypolitical.utils.MessageManager;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class PartyManager {
    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final EconomyService economyService;

    private final Map<UUID, Party> partiesById; // <PartyUUID, Party>
    private final Map<String, UUID> partyNameToId; // <LowercasePartyName, PartyUUID> for quick name lookup
    private final Map<UUID, UUID> playerToPartyId; // <PlayerUUID, PartyUUID> for quick player party lookup

    private final File partiesDataFolder;
    private static final String PARTY_FILE_EXTENSION = ".yml";
    private static final Pattern VALID_PARTY_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_\\u4e00-\\u9fa5]{3,16}$"); // 允许字母、数字、下划线、中文，3-16字符

    public PartyManager(TownyPolitical plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.economyService = plugin.getEconomyService();

        this.partiesById = new ConcurrentHashMap<>();
        this.partyNameToId = new ConcurrentHashMap<>();
        this.playerToPartyId = new ConcurrentHashMap<>();

        this.partiesDataFolder = new File(plugin.getDataFolder(), "parties");
        if (!partiesDataFolder.exists()) {
            partiesDataFolder.mkdirs();
        }
        loadParties();
    }

    // --- Party Creation and Deletion ---

    public boolean createParty(Player founder, String name) {
        if (founder == null || name == null) return false;
        name = name.trim();

        // 1. Check if player is already in a party
        if (getPartyByMember(founder.getUniqueId()) != null) {
            messageManager.sendMessage(founder, "party-create-fail-already-in-party");
            return false;
        }

        // 2. Validate party name
        if (!isValidPartyName(name)) {
            messageManager.sendMessage(founder, "party-name-invalid", "name", name, "min_length", plugin.getConfig().getInt("party.name.min_length", 3), "max_length", plugin.getConfig().getInt("party.name.max_length", 16));
            return false;
        }
        if (isPartyNameTaken(name)) {
            messageManager.sendMessage(founder, "party-name-taken", "name", name);
            return false;
        }

        // 3. Check cost and charge player
        double creationCost = plugin.getConfig().getDouble("party.creation_cost", 1000.0);
        if (economyService.isEnabled() && creationCost > 0) {
            if (!economyService.hasEnough(founder.getUniqueId(), creationCost)) {
                messageManager.sendMessage(founder, "error-not-enough-money", "amount", economyService.format(creationCost), "currency", "");
                return false;
            }
            if (!economyService.withdraw(founder.getUniqueId(), creationCost)) {
                messageManager.sendMessage(founder, "error-economy-transaction-failed", "action", "创建政党");
                return false; // Economy transaction failed
            }
        }

        // 4. Create and register party
        UUID partyId = UUID.randomUUID();
        Party party = new Party(partyId, name, founder.getUniqueId());

        partiesById.put(partyId, party);
        partyNameToId.put(name.toLowerCase(), partyId);
        playerToPartyId.put(founder.getUniqueId(), partyId); // Founder is now in this party

        saveParty(party); // Save to disk
        messageManager.sendMessage(founder, "party-created", "party_name", party.getName());
        if (creationCost > 0 && economyService.isEnabled()) {
            messageManager.sendMessage(founder, "party-creation-cost-paid", "amount", economyService.format(creationCost));
        }
        return true;
    }

    public boolean disbandParty(Party party, Player initiator) {
        if (party == null || initiator == null) return false;

        // 1. Permission check: Only leader can disband
        if (!party.isLeader(initiator.getUniqueId())) {
            messageManager.sendMessage(initiator, "party-disband-fail-not-leader");
            return false;
        }

        // TODO: Add confirmation step if desired via config

        String partyName = party.getName(); // Get name before it's gone

        // 2. Notify members (optional, could be an event)
        for (PartyMember member : party.getAllPartyPersonnel()) {
            OfflinePlayer p = member.getOfflinePlayer();
            if (p.isOnline() && p.getPlayer() != null) {
                messageManager.sendMessage(p.getPlayer(), "party-disband-notification", "party_name", partyName);
            }
            playerToPartyId.remove(member.getPlayerId()); // Remove all members from lookup
        }

        // 3. Remove from manager's tracking
        partiesById.remove(party.getPartyId());
        partyNameToId.remove(partyName.toLowerCase());
        // playerToPartyId already handled above for all members

        // 4. Delete data file
        deletePartyData(party);

        messageManager.sendMessage(initiator, "party-disband-success", "party_name", partyName);
        // Broadcast to server?
        // Bukkit.broadcastMessage(messageManager.getMessage("party-disband-broadcast", "party_name", partyName, "leader", initiator.getName()));
        return true;
    }


    public boolean invitePlayer(Player inviter, OfflinePlayer targetPlayer, Party party) {
        if (inviter == null || targetPlayer == null || party == null) return false;

        PartyMember inviterMember = party.getMember(inviter.getUniqueId()).orElse(null);
        if (inviterMember == null || !inviterMember.getRole().hasPermissionOf(PartyRole.ADMIN)) {
            messageManager.sendMessage(inviter, "party-invite-fail-no-permission"); // Inviter lacks permission within their own party
            return false;
        }

        if (getPartyByMember(targetPlayer.getUniqueId()) != null) {
            messageManager.sendMessage(inviter, "party-invite-fail-target-already-member", "player", targetPlayer.getName());
            return false;
        }
        // Check if target is already an applicant or member of THIS party
        if (party.getMember(targetPlayer.getUniqueId()).isPresent()) {
            messageManager.sendMessage(inviter, "party-invite-fail-target-already-related", "player", targetPlayer.getName(), "party_name", party.getName());
            return false;
        }

        // Directly add as a regular member
        if (party.addPlayerAsMember(targetPlayer.getUniqueId())) { // This uses the method we added to Party.java
            playerToPartyId.put(targetPlayer.getUniqueId(), party.getPartyId());
            saveParty(party);

            messageManager.sendMessage(inviter, "party-player-added-by-invite", "player", targetPlayer.getName(), "party_name", party.getName());
            if (targetPlayer.isOnline() && targetPlayer.getPlayer() != null) {
                messageManager.sendMessage(targetPlayer.getPlayer(), "party-added-notification-invited", "party_name", party.getName(), "inviter", inviter.getName());
            }
            return true;
        } else {
            // This case should ideally not be reached if above checks are thorough,
            // but Party.addPlayerAsMember might have its own internal reasons to fail.
            messageManager.sendMessage(inviter, "party-invite-fail-unknown", "player", targetPlayer.getName());
            return false;
        }
    }
    public boolean playerApplyToParty(Player applicant, Party party) {
        if (applicant == null || party == null) return false;

        if (getPartyByMember(applicant.getUniqueId()) != null) {
            messageManager.sendMessage(applicant, "party-apply-fail-already-in-party");
            return false;
        }
        if (party.getMember(applicant.getUniqueId()).isPresent()) {
            messageManager.sendMessage(applicant, "party-apply-fail-already-applied-or-member");
            return false;
        }

        if (party.addPlayerAsApplicant(applicant.getUniqueId())) {
            saveParty(party);
            messageManager.sendMessage(applicant, "party-join-request-sent", "party_name", party.getName());
            // Notify admins/leader
            party.getMembersByRole(PartyRole.LEADER).forEach(leader -> notifyApplication(leader, applicant, party));
            party.getAdmins().forEach(admin -> notifyApplication(admin, applicant, party));
            return true;
        }
        return false;
    }

    private void notifyApplication(PartyMember recipient, Player applicant, Party party) {
        if (recipient.getOfflinePlayer().isOnline() && recipient.getOfflinePlayer().getPlayer() != null) {
            messageManager.sendMessage(recipient.getOfflinePlayer().getPlayer(), "party-join-request-received", "player", applicant.getName(), "party_name", party.getName());
        }
    }

    public boolean acceptPartyApplication(Player adminReviewer, OfflinePlayer applicantPlayer, Party party) {
        if (adminReviewer == null || applicantPlayer == null || party == null) return false;

        PartyMember adminMember = party.getMember(adminReviewer.getUniqueId()).orElse(null);
        if (adminMember == null || !adminMember.getRole().hasPermissionOf(PartyRole.ADMIN)) {
            messageManager.sendMessage(adminReviewer, "party-accept-fail-no-permission");
            return false;
        }

        if (getPartyByMember(applicantPlayer.getUniqueId()) != null && !party.isOfficialMember(applicantPlayer.getUniqueId()) ) {
            // If they are in another party AND not already an official member of THIS party (edge case)
            messageManager.sendMessage(adminReviewer, "party-accept-fail-applicant-in-other-party", "player", applicantPlayer.getName());
            if(applicantPlayer.isOnline() && applicantPlayer.getPlayer() != null) {
                messageManager.sendMessage(applicantPlayer.getPlayer(), "party-application-rejected-in-other-party", "party_name", party.getName());
            }
            // Optionally remove their application from this party
            party.removePlayer(applicantPlayer.getUniqueId()); // remove applicant
            saveParty(party);
            return false;
        }


        if (party.promoteApplicantToMember(applicantPlayer.getUniqueId())) {
            playerToPartyId.put(applicantPlayer.getUniqueId(), party.getPartyId());
            saveParty(party);
            messageManager.sendMessage(adminReviewer, "party-applicant-accepted", "player", applicantPlayer.getName());
            if (applicantPlayer.isOnline() && applicantPlayer.getPlayer() != null) {
                messageManager.sendMessage(applicantPlayer.getPlayer(), "party-application-approved", "party_name", party.getName());
            }
            return true;
        } else {
            messageManager.sendMessage(adminReviewer, "party-accept-fail-not-applicant", "player", applicantPlayer.getName());
            return false;
        }
    }

    public boolean rejectPartyApplication(Player adminReviewer, OfflinePlayer applicantPlayer, Party party) {
        if (adminReviewer == null || applicantPlayer == null || party == null) return false;

        PartyMember adminMember = party.getMember(adminReviewer.getUniqueId()).orElse(null);
        if (adminMember == null || !adminMember.getRole().hasPermissionOf(PartyRole.ADMIN)) {
            messageManager.sendMessage(adminReviewer, "party-reject-fail-no-permission");
            return false;
        }

        if (party.getMember(applicantPlayer.getUniqueId()).map(PartyMember::getRole).orElse(null) == PartyRole.APPLICANT) {
            party.removePlayer(applicantPlayer.getUniqueId()); // This removes the applicant
            saveParty(party);
            messageManager.sendMessage(adminReviewer, "party-applicant-rejected", "player", applicantPlayer.getName());
            if (applicantPlayer.isOnline() && applicantPlayer.getPlayer() != null) {
                messageManager.sendMessage(applicantPlayer.getPlayer(), "party-application-rejected", "party_name", party.getName());
            }
            return true;
        } else {
            messageManager.sendMessage(adminReviewer, "party-reject-fail-not-applicant", "player", applicantPlayer.getName());
            return false;
        }
    }


    public boolean leaveParty(Player player) {
        if (player == null) return false;
        Party party = getPartyByMember(player.getUniqueId());
        if (party == null) {
            messageManager.sendMessage(player, "party-leave-fail-not-in-party");
            return false;
        }

        if (party.isLeader(player.getUniqueId())) {
            messageManager.sendMessage(player, "party-leave-fail-leader");
            return false;
        }

        party.removePlayer(player.getUniqueId());
        playerToPartyId.remove(player.getUniqueId());
        saveParty(party);
        messageManager.sendMessage(player, "party-leave-success", "party_name", party.getName());
        // Notify leader/admins?
        return true;
    }

    public boolean kickPlayer(Player kicker, OfflinePlayer targetPlayer, Party party) {
        if (kicker == null || targetPlayer == null || party == null) return false;

        PartyMember kickerMember = party.getMember(kicker.getUniqueId()).orElse(null);
        PartyMember targetMember = party.getMember(targetPlayer.getUniqueId()).orElse(null);

        if (kickerMember == null) { // Kicker not in this party? Should not happen if commands are structured well
            messageManager.sendMessage(kicker, "error-generic");
            return false;
        }
        if (targetMember == null || targetMember.getRole() == PartyRole.APPLICANT) { // Target not an official member or is only applicant
            messageManager.sendMessage(kicker, "party-kick-fail-not-member", "player", targetPlayer.getName());
            return false;
        }
        if (kicker.getUniqueId().equals(targetPlayer.getUniqueId())) {
            messageManager.sendMessage(kicker, "party-kick-fail-self");
            return false;
        }

        // Permission check: Kicker must have higher role than target, and at least ADMIN
        if (!kickerMember.getRole().hasPermissionOf(PartyRole.ADMIN) ||
                kickerMember.getRole().getPermissionLevel() <= targetMember.getRole().getPermissionLevel()) {
            messageManager.sendMessage(kicker, "party-kick-fail-cannot-kick-higher-role");
            return false;
        }
        if (targetMember.getRole() == PartyRole.LEADER) { // Cannot kick leader
            messageManager.sendMessage(kicker, "party-kick-fail-leader");
            return false;
        }


        party.removePlayer(targetPlayer.getUniqueId());
        playerToPartyId.remove(targetPlayer.getUniqueId());
        saveParty(party);

        messageManager.sendMessage(kicker, "party-kick-success", "player", targetPlayer.getName());
        if (targetPlayer.isOnline() && targetPlayer.getPlayer() != null) {
            messageManager.sendMessage(targetPlayer.getPlayer(), "party-kick-notification", "party_name", party.getName(), "kicker", kicker.getName());
        }
        return true;
    }

    public boolean promotePlayer(Player promoter, OfflinePlayer targetPlayer, Party party) {
        if (promoter == null || targetPlayer == null || party == null) return false;

        PartyMember promoterMember = party.getMember(promoter.getUniqueId()).orElse(null);
        PartyMember targetMember = party.getMember(targetPlayer.getUniqueId()).orElse(null);

        if (promoterMember == null || targetMember == null || targetMember.getRole() == PartyRole.APPLICANT) {
            messageManager.sendMessage(promoter, "party-promote-fail-not-member", "player", targetPlayer.getName());
            return false;
        }

        // Promoter must be LEADER to promote to ADMIN
        // Promoter must be at least ADMIN and have higher role than target for other promotions (if more roles existed)
        // Current roles: MEMBER -> ADMIN (by LEADER)
        if (!promoterMember.getRole().equals(PartyRole.LEADER)) {
            messageManager.sendMessage(promoter, "party-promote-fail-no-permission");
            return false;
        }
        if (targetMember.getRole().equals(PartyRole.MEMBER)) {
            if (party.promoteMemberToAdmin(targetPlayer.getUniqueId())) {
                saveParty(party);
                messageManager.sendMessage(promoter, "party-promote-success", "player", targetPlayer.getName(), "role", PartyRole.ADMIN.getDisplayName());
                if (targetPlayer.isOnline() && targetPlayer.getPlayer() != null) {
                    messageManager.sendMessage(targetPlayer.getPlayer(), "party-promote-notification", "role", PartyRole.ADMIN.getDisplayName());
                }
                return true;
            }
        } else {
            messageManager.sendMessage(promoter, "party-promote-fail-max-role", "player", targetPlayer.getName()); // Already admin or leader
        }
        return false;
    }

    public boolean demotePlayer(Player demoter, OfflinePlayer targetPlayer, Party party) {
        if (demoter == null || targetPlayer == null || party == null) return false;

        PartyMember demoterMember = party.getMember(demoter.getUniqueId()).orElse(null);
        PartyMember targetMember = party.getMember(targetPlayer.getUniqueId()).orElse(null);

        if (demoterMember == null || targetMember == null || targetMember.getRole() == PartyRole.APPLICANT) {
            messageManager.sendMessage(demoter, "party-demote-fail-not-member", "player", targetPlayer.getName());
            return false;
        }

        // Demoter must be LEADER to demote ADMIN
        if (!demoterMember.getRole().equals(PartyRole.LEADER)) {
            messageManager.sendMessage(demoter, "party-demote-fail-no-permission");
            return false;
        }
        if (targetMember.getRole().equals(PartyRole.ADMIN)) {
            if (party.demoteAdminToMember(targetPlayer.getUniqueId())) {
                saveParty(party);
                messageManager.sendMessage(demoter, "party-demote-success", "player", targetPlayer.getName(), "role", PartyRole.MEMBER.getDisplayName());
                if (targetPlayer.isOnline() && targetPlayer.getPlayer() != null) {
                    messageManager.sendMessage(targetPlayer.getPlayer(), "party-demote-notification", "role", PartyRole.MEMBER.getDisplayName());
                }
                return true;
            }
        } else {
            messageManager.sendMessage(demoter, "party-demote-fail-min-role", "player", targetPlayer.getName()); // Already member
        }
        return false;
    }


    // --- Party Info and Management ---
    public boolean renameParty(Party party, String newName, Player initiator) {
        if (party == null || newName == null || initiator == null) return false;
        newName = newName.trim();

        if (!party.isLeader(initiator.getUniqueId())) {
            messageManager.sendMessage(initiator, "party-rename-fail-not-leader");
            return false;
        }

        if (!isValidPartyName(newName)) {
            messageManager.sendMessage(initiator, "party-name-invalid", "name", newName, "min_length", plugin.getConfig().getInt("party.name.min_length", 3), "max_length", plugin.getConfig().getInt("party.name.max_length", 16));
            return false;
        }
        if (!party.getName().equalsIgnoreCase(newName) && isPartyNameTaken(newName)) {
            messageManager.sendMessage(initiator, "party-name-taken", "name", newName);
            return false;
        }

        double renameCost = plugin.getConfig().getDouble("party.rename_cost", 500.0);
        if (economyService.isEnabled() && renameCost > 0) {
            if (!economyService.hasEnough(initiator.getUniqueId(), renameCost)) {
                messageManager.sendMessage(initiator, "error-not-enough-money", "amount", economyService.format(renameCost), "currency", "");
                return false;
            }
            if (!economyService.withdraw(initiator.getUniqueId(), renameCost)) {
                messageManager.sendMessage(initiator, "error-economy-transaction-failed", "action", "政党改名");
                return false;
            }
        }

        String oldName = party.getName();
        partyNameToId.remove(oldName.toLowerCase());
        party.setName(newName);
        partyNameToId.put(newName.toLowerCase(), party.getPartyId());
        saveParty(party);

        messageManager.sendMessage(initiator, "party-name-changed", "old_name", oldName, "new_name", newName);
        if (renameCost > 0 && economyService.isEnabled()) {
            messageManager.sendMessage(initiator, "party-rename-cost-paid", "amount", economyService.format(renameCost));
        }
        return true;
    }

    public boolean transferLeadership(Party party, Player currentLeader, OfflinePlayer newLeaderPlayer) {
        if (party == null || currentLeader == null || newLeaderPlayer == null) return false;

        if (!party.isLeader(currentLeader.getUniqueId())) {
            messageManager.sendMessage(currentLeader, "party-transfer-fail-not-leader");
            return false;
        }
        if (currentLeader.getUniqueId().equals(newLeaderPlayer.getUniqueId())) {
            messageManager.sendMessage(currentLeader, "party-transfer-fail-self");
            return false;
        }

        PartyMember targetMember = party.getMember(newLeaderPlayer.getUniqueId()).orElse(null);
        if (targetMember == null || targetMember.getRole() == PartyRole.APPLICANT) {
            messageManager.sendMessage(currentLeader, "party-transfer-fail-target-not-member", "player", newLeaderPlayer.getName());
            return false;
        }

        // Perform transfer
        if (party.setLeader(newLeaderPlayer.getUniqueId())) {
            saveParty(party);
            messageManager.sendMessage(currentLeader, "party-transfer-leader-success-own", "new_leader", newLeaderPlayer.getName());
            if (newLeaderPlayer.isOnline() && newLeaderPlayer.getPlayer() != null) {
                messageManager.sendMessage(newLeaderPlayer.getPlayer(), "party-transfer-leader-notification", "party_name", party.getName(), "old_leader", currentLeader.getName());
            }
            // Notify other members?
            return true;
        } else {
            messageManager.sendMessage(currentLeader, "error-generic"); // Should be caught by Party.setLeader specific exceptions
            return false;
        }
    }


    // --- Getters and Utility ---
    public Party getParty(UUID partyId) {
        return partiesById.get(partyId);
    }

    public Party getParty(String name) {
        if (name == null) return null;
        UUID partyId = partyNameToId.get(name.toLowerCase());
        return partyId != null ? partiesById.get(partyId) : null;
    }

    public Party getPartyByMember(UUID playerId) {
        UUID partyId = playerToPartyId.get(playerId);
        return partyId != null ? partiesById.get(partyId) : null;
    }

    public Collection<Party> getAllParties() {
        return Collections.unmodifiableCollection(partiesById.values());
    }

    public boolean isPartyNameTaken(String name) {
        return partyNameToId.containsKey(name.toLowerCase());
    }

    public boolean isValidPartyName(String name) {
        if (name == null) return false;
        int minLength = plugin.getConfig().getInt("party.name.min_length", 3);
        int maxLength = plugin.getConfig().getInt("party.name.max_length", 16);
        if (name.length() < minLength || name.length() > maxLength) {
            return false;
        }
        return VALID_PARTY_NAME_PATTERN.matcher(name).matches();
    }

    public void onPlayerJoinServer(Player player) {
        // Potentially re-cache or update something if needed, for now, not much.
        // Player objects in PartyMember are transient, so they get re-fetched.
        // One thing: ensure playerToPartyId is correct if data was manually edited.
        // But this should be handled by loadParties primarily.
    }

    public void onPlayerQuitServer(Player player) {
        // Clean up any session-specific data if necessary
    }


    // --- Data Persistence (Simple YAML per party) ---

    public void loadParties() {
        partiesById.clear();
        partyNameToId.clear();
        playerToPartyId.clear();

        if (!partiesDataFolder.exists() || !partiesDataFolder.isDirectory()) {
            return;
        }

        File[] partyFiles = partiesDataFolder.listFiles((dir, name) -> name.toLowerCase().endsWith(PARTY_FILE_EXTENSION));
        if (partyFiles == null) return;

        for (File partyFile : partyFiles) {
            try {
                YamlConfiguration partyConfig = YamlConfiguration.loadConfiguration(partyFile);
                UUID partyId = UUID.fromString(partyConfig.getString("id"));
                String name = partyConfig.getString("name");
                long creationTimestamp = partyConfig.getLong("creationTimestamp"); // Not used by Party constructor yet, but good to store

                ConfigurationSection membersSection = partyConfig.getConfigurationSection("members");
                if (membersSection == null) {
                    plugin.getLogger().warning("Party file " + partyFile.getName() + " is missing members section. Skipping.");
                    continue;
                }

                UUID leaderId = null;
                Map<UUID, PartyRole> memberRoles = new HashMap<>();

                for (String uuidStr : membersSection.getKeys(false)) {
                    try {
                        UUID memberUuid = UUID.fromString(uuidStr);
                        PartyRole role = PartyRole.valueOf(membersSection.getString(uuidStr + ".role", "MEMBER"));
                        memberRoles.put(memberUuid, role);
                        if (role == PartyRole.LEADER) {
                            leaderId = memberUuid;
                        }
                    } catch (IllegalArgumentException e) {
                        plugin.getLogger().warning("Invalid UUID or Role in party file " + partyFile.getName() + " for member " + uuidStr + ". Skipping member.");
                    }
                }

                if (leaderId == null) {
                    plugin.getLogger().warning("Party file " + partyFile.getName() + " has no leader defined. Skipping party.");
                    continue;
                }
                if (name == null || name.isEmpty()) {
                    plugin.getLogger().warning("Party file " + partyFile.getName() + " has no name defined. Skipping party.");
                    continue;
                }


                Party party = new Party(partyId, name, leaderId); // Party constructor sets leader
                // Override creationTimestamp if needed, or add to Party constructor.
                // party.setCreationTimestamp(creationTimestamp); // If such a setter exists

                for (Map.Entry<UUID, PartyRole> entry : memberRoles.entrySet()) {
                    if (!entry.getKey().equals(leaderId)) { // Leader is already added
                        party.addPlayerWithRole(entry.getKey(), entry.getValue()); // Requires Party.addPlayerWithRole
                    }
                    if(entry.getValue() != PartyRole.APPLICANT) { // Only official members in playerToPartyId map
                        playerToPartyId.put(entry.getKey(), partyId);
                    }
                }
                // If Party.addPlayerWithRole is not available, you'd need to use promote/setRole after adding as applicant/member.
                // For simplicity, I'll assume Party constructor handles leader, and a method like `forceAddMember(uuid, role)` for others during load.
                // For now, let's adjust the Party class to have a constructor that can take existing members, or add a method in Party.

                partiesById.put(partyId, party);
                partyNameToId.put(name.toLowerCase(), partyId);
                // playerToPartyId is populated within the loop for official members.

            } catch (Exception e) {
                plugin.getLogger().log(Level.SEVERE, "Failed to load party from file: " + partyFile.getName(), e);
            }
        }
        plugin.getLogger().info("Loaded " + partiesById.size() + " parties.");
    }

    /**
     * Adds a player with a specific role. Used during party loading.
     * This method needs to be added to the Party class.
     * public void addPlayerWithRole(UUID playerId, PartyRole role) {
     *     if (members.containsKey(playerId)) {
     *         members.get(playerId).setRole(role);
     *     } else {
     *         members.put(playerId, new PartyMember(playerId, role));
     *     }
     * }
     *
     * For Party.java, we also need a method like:
     * public void addPlayerAsMember(UUID playerId) {
     *     if (!members.containsKey(playerId)) {
     *         members.put(playerId, new PartyMember(playerId, PartyRole.MEMBER));
     *     } else { // If applicant, promote. If already member/admin/leader, do nothing.
     *         PartyMember existing = members.get(playerId);
     *         if (existing.getRole() == PartyRole.APPLICANT) existing.setRole(PartyRole.MEMBER);
     *     }
     * }
     */

    public void saveParty(Party party) {
        party.setLastLeaderElectionTime("lastLeaderElectionTime", party.getLastLeaderElectionTime());
        if (party == null) return;
        File partyFile = new File(partiesDataFolder, party.getPartyId().toString() + PARTY_FILE_EXTENSION);
        YamlConfiguration partyConfig = new YamlConfiguration();

        partyConfig.set("id", party.getPartyId().toString());
        partyConfig.set("name", party.getName());
        partyConfig.set("creationTimestamp", party.getCreationTimestamp());

        ConfigurationSection membersSection = partyConfig.createSection("members");
        for (PartyMember member : party.getAllPartyPersonnel()) {
            membersSection.set(member.getPlayerId().toString() + ".role", member.getRole().name());
            // Could save last known name for easier file reading, but not essential for logic
            // membersSection.set(member.getPlayerId().toString() + ".lastKnownName", member.getName());
        }

        try {
            partyConfig.save(partyFile);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save party: " + party.getName(), e);
        }
        if (party == null) return;

        partyConfig.set("id", party.getPartyId().toString());
        partyConfig.set("name", party.getName());
        partyConfig.set("creationTimestamp", party.getCreationTimestamp());
        partyConfig.set("lastLeaderElectionTime", party.getLastLeaderElectionTime()); // 保存新增字段

        // ... (保存成员 membersSection) ...

        try {
            partyConfig.save(partyFile);
        } catch (IOException e) {
            // ... (log) ...
        }
    }

    public void saveAllParties() {
        plugin.getLogger().info("Saving all parties (" + partiesById.size() + ")...");
        for (Party party : partiesById.values()) {
            saveParty(party);
        }
        plugin.getLogger().info("All parties saved.");
    }

    private void deletePartyData(Party party) {
        if (party == null) return;
        File partyFile = new File(partiesDataFolder, party.getPartyId().toString() + PARTY_FILE_EXTENSION);
        if (partyFile.exists()) {
            if (!partyFile.delete()) {
                plugin.getLogger().warning("Could not delete party data file: " + partyFile.getName());
            }
        }
    }

    // Call this from onDisable in main plugin class
    public void shutdown() {
        saveAllParties();
    }

    // Helper to check Towny compatibility or player's nation status for future use
    public Resident getTownyResident(UUID playerUUID) {
        if (plugin.getServer().getPluginManager().getPlugin("Towny") != null) {
            return TownyAPI.getInstance().getResident(playerUUID);
        }
        return null;
    }
}