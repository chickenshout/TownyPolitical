// 文件名: BillCommandsHandler.java
// 结构位置: top/chickenshout/townypolitical/commands/handlers/BillCommandsHandler.java
/*
package top.chickenshout.townypolitical.commands.handlers;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.data.Party;
import top.chickenshout.townypolitical.managers.NationManager;
import top.chickenshout.townypolitical.managers.PartyManager;
import top.chickenshout.townypolitical.utils.MessageManager;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class BillCommandsHandler {
    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final NationManager nationManager;
    private final PartyManager partyManager;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

    public BillCommandsHandler(TownyPolitical plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.nationManager = plugin.getNationManager();
        this.partyManager = plugin.getPartyManager();
        this.dateFormat.setTimeZone(java.util.TimeZone.getDefault());
    }

    public boolean handle(CommandSender sender, String commandLabel, String[] args) {
        if (args.length == 0) {
            sendBillHelp(sender, commandLabel);
            return true;
        }
        String subCommand = args[0].toLowerCase();
        String[] subArgs = new String[args.length - 1];
        if (args.length > 1) {
            System.arraycopy(args, 1, subArgs, 0, args.length - 1);
        }

        switch (subCommand) {
            case "propose":
                return handleProposeCommand(sender, commandLabel, subArgs);
            case "list":
                return handleListCommand(sender, commandLabel, subArgs);
            case "info":
                return handleInfoCommand(sender, commandLabel, subArgs);
            case "vote":
                return handleVoteCommand(sender, commandLabel, subArgs);
            // Admin/Speaker commands
            case "startvote": // 议长或管理员启动投票
                return handleStartVoteCommand(sender, commandLabel, subArgs);
            // case "closevote": // 手动关闭投票 (通常自动)
            // case "repeal": // 废除已通过法案
            default:
                messageManager.sendMessage(sender, "command-bill-unknown", "subcommand", subCommand);
                sendBillHelp(sender, commandLabel);
                return true;
        }
    }

    private Nation parseNationFromArgs(CommandSender sender, String[] args, int nationNameArgIndex, int minTotalArgs) {
        if (args.length < minTotalArgs) return null; // Not enough args for nation name

        String nationName = args[nationNameArgIndex];
        // If nation name can have spaces, need more complex parsing for remaining args
        // For simplicity, assume nation name is one word or quoted for now.
        // Or, the nation name is all args up to a certain point.

        Nation targetNation = TownyAPI.getInstance().getNation(nationName);
        if (targetNation == null) {
            messageManager.sendMessage(sender, "error-nation-not-found", "nation", nationName);
        }
        return targetNation;
    }


    private boolean handleProposeCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!(sender instanceof Player)) {
            messageManager.sendMessage(sender, "error-player-only-command");
            return true;
        }
        Player proposer = (Player) sender;

        // Usage: /tp bill propose <Nation> "<Title>" "<Content>"
        // Or /tp bill propose "<Title>" "<Content>" (if nation is proposer's nation)
        if (!proposer.hasPermission("townypolitical.bill.propose")) {
            messageManager.sendMessage(proposer, "error-no-permission");
            return true;
        }

        if (subArgs.length < 2) { // At least title and content
            messageManager.sendMessage(proposer, "error-invalid-arguments", "usage", "/" + commandLabel + " propose [国家] \"<标题>\" \"<内容>\"");
            return true;
        }

        Nation targetNation;
        String title;
        String content;

        // A simple way to parse args with quotes, not robust for nested quotes.
        List<String> parsedArgs = ArgumentParser.parseArguments(String.join(" ", subArgs));
        // ArgumentParser would be a utility to split by space but respect "quoted strings"

        if (parsedArgs.size() == 2) { // Assume title and content, nation is self
            targetNation = TownyAPI.getInstance().getResidentNationOrNull((Resident) proposer);
            if (targetNation == null) {
                messageManager.sendMessage(proposer, "bill-propose-fail-no-nation");
                return true;
            }
            title = parsedArgs.get(0);
            content = parsedArgs.get(1);
        } else if (parsedArgs.size() == 3) { // Assume nation, title, content
            targetNation = TownyAPI.getInstance().getNation(parsedArgs.get(0));
            if (targetNation == null) {
                messageManager.sendMessage(proposer, "error-nation-not-found", "nation", parsedArgs.get(0));
                return true;
            }
            title = parsedArgs.get(1);
            content = parsedArgs.get(2);
        } else {
            messageManager.sendMessage(proposer, "error-invalid-arguments", "usage", "/" + commandLabel + " propose [国家] \"<标题>\" \"<内容>\"");
            return true;
        }

        // TODO: Check if proposer is an MP of targetNation, or if their party can propose bills
        // For now, allow any citizen to propose (can be refined by config/perms)
        if (TownyAPI.getInstance().getResidentNationOrNull((Resident) proposer) != targetNation){
            // Check if player is MP of the target nation, or has special permission
            // For simplicity, let's require proposer to be in the nation for now
            if(!proposer.hasPermission("townypolitical.bill.propose.othernation")){
                messageManager.sendMessage(proposer, "bill-propose-fail-not-your-nation");
                return true;
            }
        }


        Party proposingParty = partyManager.getPartyByMember(proposer.getUniqueId());
        nationManager.proposeBill(targetNation, proposer, proposingParty, title, content);
        return true;
    }

    private boolean handleListCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        // Usage: /tp bill list [Nation] [status:pending|voting|passed|failed]
        if (!sender.hasPermission("townypolitical.bill.list")) {
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }

        Nation targetNation = null;
        Bill.BillStatus filterStatus = null;
        String nationNameArg = null;

        if (subArgs.length > 0) {
            try { // Try to parse last arg as status
                filterStatus = Bill.BillStatus.valueOf(subArgs[subArgs.length - 1].toUpperCase());
                if (subArgs.length > 1) {
                    nationNameArg = String.join(" ", Arrays.copyOfRange(subArgs, 0, subArgs.length -1));
                }
            } catch (IllegalArgumentException e) { // Last arg is not a status, so all args are nation name
                nationNameArg = String.join(" ", subArgs);
            }
        }

        if (nationNameArg != null) {
            targetNation = TownyAPI.getInstance().getNation(nationNameArg);
            if (targetNation == null) {
                messageManager.sendMessage(sender, "error-nation-not-found", "nation", nationNameArg);
                return true;
            }
        } else if (sender instanceof Player) {
            targetNation = TownyAPI.getInstance().getResidentNationOrNull((Resident) sender);
            if (targetNation == null) {
                messageManager.sendMessage(sender, "bill-list-fail-no-nation-or-arg");
                return true;
            }
        } else {
            messageManager.sendMessage(sender, "bill-list-fail-console-needs-nation");
            return true;
        }

        List<Bill> bills = nationManager.getBillsForNation(targetNation.getUUID());
        final Bill.BillStatus finalFilterStatus = filterStatus; // For lambda
        List<Bill> filteredBills = bills.stream()
                .filter(b -> finalFilterStatus == null || b.getStatus() == finalFilterStatus)
                .sorted(Comparator.comparingLong(Bill::getProposalTimestamp).reversed()) // Newest first
                .collect(Collectors.toList());

        if (filteredBills.isEmpty()) {
            messageManager.sendMessage(sender, "bill-list-empty", "nation", targetNation.getName(), "status_filter", finalFilterStatus != null ? finalFilterStatus.name() : "任何");
            return true;
        }

        messageManager.sendRawMessage(sender, "bill-list-header", "nation", targetNation.getName(), "status_filter", finalFilterStatus != null ? finalFilterStatus.name() : "所有");
        for (Bill bill : filteredBills) {
            String proposerName = Bukkit.getOfflinePlayer(bill.getProposerUUID()).getName();
            messageManager.sendRawMessage(sender, "bill-list-entry",
                    "id", bill.getBillId().toString().substring(0, 8),
                    "title", bill.getTitle(),
                    "status", bill.getStatus().name(),
                    "proposer", proposerName != null ? proposerName : "N/A");
        }
        return true;
    }

    private boolean handleInfoCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        // Usage: /tp bill info [Nation] <BillID_or_PartialTitle>
        if (!sender.hasPermission("townypolitical.bill.info")) {  return true;}
        if (subArgs.length < 1) {  return true;}

        Nation targetNation = null;
        String identifier; // Bill ID or partial title

        if (subArgs.length == 1) { // Assume identifier, nation is self
            if (!(sender instanceof Player)) {  return true;}
            targetNation = TownyAPI.getInstance().getResidentNationOrNull((Resident) sender);
            if (targetNation == null) {  return true;}
            identifier = subArgs[0];
        } else { // Assume nation then identifier
            // More robust parsing needed if nation name has spaces
            targetNation = TownyAPI.getInstance().getNation(subArgs[0]);
            if (targetNation == null) {  return true;}
            identifier = String.join(" ", Arrays.copyOfRange(subArgs, 1, subArgs.length));
        }

        List<Bill> nationBills = nationManager.getBillsForNation(targetNation.getUUID());
        Optional<Bill> foundBill = nationBills.stream()
                .filter(b -> b.getBillId().toString().startsWith(identifier) || b.getTitle().toLowerCase().contains(identifier.toLowerCase()))
                .findFirst(); // Simple find, might need more sophisticated matching

        if (!foundBill.isPresent()) {
            messageManager.sendMessage(sender, "bill-info-not-found", "identifier", identifier, "nation", targetNation.getName());
            return true;
        }
        Bill bill = foundBill.get();
        displayBillDetails(sender, bill);
        return true;
    }

    private void displayBillDetails(CommandSender sender, Bill bill) {
        messageManager.sendRawMessage(sender, "bill-info-header", "title", bill.getTitle(), "id", bill.getBillId().toString().substring(0,8));
        messageManager.sendRawMessage(sender, "bill-info-nation", "nation", TownyAPI.getInstance().getNation(bill.getNationUUID()).getName());
        String proposerName = Bukkit.getOfflinePlayer(bill.getProposerUUID()).getName();
        messageManager.sendRawMessage(sender, "bill-info-proposer", "name", proposerName != null ? proposerName : "N/A");
        if (bill.getProposingPartyUUID().isPresent()) {
            Party p = partyManager.getParty(bill.getProposingPartyUUID().get());
            messageManager.sendRawMessage(sender, "bill-info-proposing-party", "name", p != null ? p.getName() : "未知政党");
        }
        messageManager.sendRawMessage(sender, "bill-info-status", "status", bill.getStatus().name());
        messageManager.sendRawMessage(sender, "bill-info-proposed-on", "date", dateFormat.format(new Date(bill.getProposalTimestamp())));
        messageManager.sendRawMessage(sender, "bill-info-content-header");
        // Split content into multiple lines if too long for chat
        Arrays.stream(bill.getContent().split("\n")).forEach(line -> sender.sendMessage(MessageManager.translateColors("  &7" + line)));

        if (bill.getStatus() == Bill.BillStatus.VOTING || bill.getStatus() == Bill.BillStatus.PASSED || bill.getStatus() == Bill.BillStatus.FAILED) {
            messageManager.sendRawMessage(sender, "bill-info-votes-header");
            messageManager.sendRawMessage(sender, "bill-info-votes-yes", "count", String.valueOf(bill.getYesVotes()));
            messageManager.sendRawMessage(sender, "bill-info-votes-no", "count", String.valueOf(bill.getNoVotes()));
            messageManager.sendRawMessage(sender, "bill-info-votes-abstain", "count", String.valueOf(bill.getAbstainVotes()));
            if (bill.getStatus() == Bill.BillStatus.VOTING) {
                messageManager.sendRawMessage(sender, "bill-info-voting-ends", "date", dateFormat.format(new Date(bill.getVotingEndTimestamp())));
            }
        }
    }


    private boolean handleVoteCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        // Usage: /tp bill vote [Nation] <BillID> <yes|no|abstain>
        if (!(sender instanceof Player)) {  return true; }
        Player voter = (Player) sender;
        if (!voter.hasPermission("townypolitical.bill.vote")) {  return true; }
        if (subArgs.length < 2) {  return true; } // At least BillID and vote_type

        Nation targetNation = null;
        String billIdStr;
        String voteTypeStr;

        if (subArgs.length == 2) { // billId, voteType (nation is self)
            targetNation = TownyAPI.getInstance().getResidentNationOrNull((Resident) voter);
            if (targetNation == null) {  return true;}
            billIdStr = subArgs[0];
            voteTypeStr = subArgs[1];
        } else if (subArgs.length == 3) { // nation, billId, voteType
            targetNation = TownyAPI.getInstance().getNation(subArgs[0]);
            if (targetNation == null) { / return true;}
            billIdStr = subArgs[1];
            voteTypeStr = subArgs[2];
        } else {
            / return true;
        }

        Optional<Bill> billOpt = nationManager.getBillsForNation(targetNation.getUUID()).stream()
                .filter(b -> b.getBillId().toString().startsWith(billIdStr) && b.getStatus() == Bill.BillStatus.VOTING)
                .findFirst();

        if (!billOpt.isPresent()) {
            messageManager.sendMessage(voter, "bill-vote-fail-not-found-or-not-voting", "bill_id", billIdStr, "nation", targetNation.getName());
            return true;
        }
        Bill bill = billOpt.get();

        // TODO: Check if voter is an MP of this nation and eligible to vote
        // For now, allow any citizen of the nation to vote (can be changed)
        if (TownyAPI.getInstance().getResidentNationOrNull((Resident) voter) != targetNation){
            messageManager.sendMessage(voter, "bill-vote-fail-not-citizen-of-nation", "nation", targetNation.getName());
            return true;
        }


        Bill.VoteType voteType;
        try {
            voteType = Bill.VoteType.valueOf(voteTypeStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            messageManager.sendMessage(voter, "bill-vote-fail-invalid-type", "type", voteTypeStr);
            return true;
        }

        if (bill.addVote(voter.getUniqueId(), voteType)) {
            nationManager.saveNationBills(targetNation.getUUID()); // Save after vote
            messageManager.sendMessage(voter, "bill-vote-success", "title", bill.getTitle(), "vote", voteType.name());
        } else {
            messageManager.sendMessage(voter, "bill-vote-fail-already-voted-or-closed");
        }
        return true;
    }

    private boolean handleStartVoteCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        // Usage: /tp bill startvote [Nation] <BillID> [duration_days]
        if (!sender.hasPermission("townypolitical.bill.manage")) {  return true; }
        if (subArgs.length < 1) {  return true; }

        Nation targetNation = null;
        String billIdStr;
        long durationDays = plugin.getConfig().getLong("parliament.bills.voting_duration_seconds", 86400) / (24*3600) ; // Default from config

        int nationNameEndIndex = -1;
        if (subArgs.length > 1) {
            try { // Check if last arg is duration
                durationDays = Long.parseLong(subArgs[subArgs.length - 1]);
                nationNameEndIndex = subArgs.length - 2; // Second to last is end of nation name or billID
            } catch (NumberFormatException e) { // Last arg is not duration, so it's part of billID or nation name
                nationNameEndIndex = subArgs.length - 1;
            }
        } else { // Only billID given
            nationNameEndIndex = -1; // No nation name explicitly given
        }


        if (nationNameEndIndex == -1) { // Only billID (and optionally duration)
            if (!(sender instanceof Player)) {  return true; }
            targetNation = TownyAPI.getInstance().getResidentNationOrNull((Resident) sender);
            if (targetNation == null) {  return true; }
            billIdStr = subArgs[0];
        } else if (nationNameEndIndex == 0) { // Nation Name and BillID (and optionally duration)
            targetNation = TownyAPI.getInstance().getNation(subArgs[0]);
            if (targetNation == null) {  return true; }
            billIdStr = subArgs[1];
        }
        else { // Nation Name (multi-word) and BillID (and optionally duration)
            String nationName = Arrays.stream(subArgs, 0, nationNameEndIndex +1).collect(Collectors.joining(" "));
            targetNation = TownyAPI.getInstance().getNation(nationName);
            if (targetNation == null) {  return true; }
            billIdStr = subArgs[nationNameEndIndex + 1];
        }


        Optional<Bill> billOpt = nationManager.getBillById(targetNation.getUUID(), UUID.fromString(billIdStr)); // Assuming full ID for admin cmd
        if(!billOpt.isPresent() || billOpt.get().getStatus() != Bill.BillStatus.PENDING) {
            messageManager.sendMessage(sender, "bill-startvote-fail-not-found-or-not-pending", "bill_id", billIdStr);
            return true;
        }

        if(nationManager.startBillVoting(billOpt.get(), durationDays * 24 * 3600)) {
            messageManager.sendMessage(sender, "bill-startvote-success", "title", billOpt.get().getTitle());
        } else {
            messageManager.sendMessage(sender, "bill-startvote-fail", "title", billOpt.get().getTitle());
        }
        return true;
    }


    private void sendBillHelp(CommandSender sender, String commandLabel) {
        String displayLabel = commandLabel.split(" ")[0];
        if (!displayLabel.equalsIgnoreCase("tbill")) { // Assuming alias
            displayLabel += " bill";
        }
        messageManager.sendRawMessage(sender, "help-bill-header", "label", displayLabel);
        // ...
        messageManager.sendRawMessage(sender, "help-footer");
    }

    // Helper for parsing arguments that might be quoted
    private static class ArgumentParser {
        public static List<String> parseArguments(String argumentString) {
            List<String> matchList = new ArrayList<>();
            java.util.regex.Matcher regexMatcher = java.util.regex.Pattern.compile("[^\\s\"']+|\"([^\"]*)\"|'([^']*)'").matcher(argumentString);
            while (regexMatcher.find()) {
                if (regexMatcher.group(1) != null) { // Quoted with "
                    matchList.add(regexMatcher.group(1));
                } else if (regexMatcher.group(2) != null) { // Quoted with '
                    matchList.add(regexMatcher.group(2));
                } else { // Unquoted
                    matchList.add(regexMatcher.group());
                }
            }
            return matchList;
        }
    }
}
*/