package top.chickenshout.townypolitical.enums;

import java.util.Arrays;
import java.util.Optional;

public enum ElectionType {
    PARLIAMENTARY("议会选举", "选出议会成员，多数党领袖通常成为政府首脑（总理）"),
    PRESIDENTIAL("总统选举", "直接选举国家元首（总统）"),
    PARTY_LEADER("政党领袖选举", "选举政党内部的领导人");

    private final String displayName;
    private final String description;

    ElectionType(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }

    /**
     * 根据名称（忽略大小写）查找选举类型。
     * @param name 枚举常量的名称 (例如 "PARLIAMENTARY", "presidential")
     * @return 对应的 ElectionType Optional，如果找不到则为空
     */
    public static Optional<ElectionType> fromString(String name) {
        if (name == null) return Optional.empty();
        return Arrays.stream(values())
                .filter(type -> type.name().equalsIgnoreCase(name))
                .findFirst();
    }
}