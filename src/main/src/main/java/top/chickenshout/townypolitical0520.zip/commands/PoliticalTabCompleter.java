// 文件名: PoliticalTabCompleter.java
// 结构位置: top/chickenshout/townypolitical/commands/PoliticalTabCompleter.java
package top.chickenshout.townypolitical.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.enums.ElectionType;
import com.palmergames.bukkit.towny.TownyAPI;
// import Manager classes for context-aware suggestions

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class PoliticalTabCompleter implements TabCompleter {

    private final TownyPolitical plugin;
    private static final List<String> MAIN_COMMANDS_ALL = Arrays.asList("party", "nation", "election", /*"parliament", "bill",*/ "help", "info", "reload");
    private static final List<String> MAIN_COMMANDS_USER = Arrays.asList("party", "nation", "election", /*"parliament", "bill",*/ "help", "info");

    // TODO: 为每个子命令组创建更详细的补全列表
    private static final List<String> PARTY_SUBCOMMANDS = Arrays.asList("create", "disband", "invite", "kick", "promote", "demote", "rename", "setleader", "join", "apply", "leave", "info", "list", "accept", "reject");
    private static final List<String> NATION_SUBCOMMANDS = Arrays.asList("setgov", "info", "listgov");
    private static final List<String> ELECTION_SUBCOMMANDS = Arrays.asList("vote", "register", "info", "results", "candidates", "start", "stop");


    public PoliticalTabCompleter(TownyPolitical plugin) {
        this.plugin = plugin;
    }

    @Nullable
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        final List<String> completions = new ArrayList<>();
        String commandName = command.getName().toLowerCase();

        if (commandName.equals("townypolitical")) {
            if (args.length == 1) { // /tp <HERE>
                List<String> commandsToShow = sender.hasPermission("townypolitical.command.reload") ? MAIN_COMMANDS_ALL : MAIN_COMMANDS_USER;
                StringUtil.copyPartialMatches(args[0], commandsToShow, completions);
            } else if (args.length > 1) { // /tp <main_group> <HERE...>
                String mainGroup = args[0].toLowerCase();
                String currentArgForSub = args[args.length - 1]; // 当前正在输入的参数
                String[] subArgsOnly = Arrays.copyOfRange(args, 1, args.length); // 传递给子补全器的参数 (不含main_group)

                switch (mainGroup) {
                    case "party": case "p":
                        completePartySubCommand(sender, currentArgForSub, subArgsOnly, completions);
                        break;
                    case "nation": case "n":
                        completeNationSubCommand(sender, currentArgForSub, subArgsOnly, completions);
                        break;
                    case "election": case "e":
                        completeElectionSubCommand(sender, currentArgForSub, subArgsOnly, completions);
                        break;
                }
            }
        } else if (commandName.equals("tparty")) {
            // args for /tparty is directly subcommands and their params
            // args[0] is party_subcommand, args[1] is first param for party_subcommand etc.
            String currentArgForSub = args[args.length - 1];
            completePartySubCommand(sender, currentArgForSub, args, completions); // 直接传递 args
        }

        Collections.sort(completions);
        return completions;
    }

    // 子命令补全方法需要调整其参数签名和内部逻辑
    // private void completePartySubCommand(CommandSender sender, String currentArg, String[] subCommandAndItsArgs, List<String> completions)
    // subCommandAndItsArgs[0] is the party subcommand itself if subCommandAndItsArgs.length >=1

    private void completePartySubCommand(CommandSender sender, String currentText, String[] fullArgsForPartyModule, List<String> completions) {
        // fullArgsForPartyModule 是 "party" 模块接收到的所有参数 (不包括 "party" 本身)
        // 例如，对于 /tp party create foo, fullArgsForPartyModule 是 ["create", "foo"]
        // 对于 /tparty create foo, fullArgsForPartyModule 也是 ["create", "foo"]
        // currentText 是当前正在输入的单词

        if (fullArgsForPartyModule.length == 0 || (fullArgsForPartyModule.length == 1 && fullArgsForPartyModule[0].isEmpty() && currentText.isEmpty())) {
            // 补全 party 的子命令: /tp party <HERE> OR /tparty <HERE> (当currentText是空且args只有一个元素，它就是这个元素)
            StringUtil.copyPartialMatches(currentText, PARTY_SUBCOMMANDS, completions);
            return;
        }
        if (fullArgsForPartyModule.length == 1 && !PARTY_SUBCOMMANDS.contains(fullArgsForPartyModule[0].toLowerCase())) {
            // 如果第一个参数不是一个已知的party子命令，仍然尝试补全party子命令
            StringUtil.copyPartialMatches(fullArgsForPartyModule[0], PARTY_SUBCOMMANDS, completions);
            return;
        }


        // fullArgsForPartyModule[0] is the party subcommand
        if (fullArgsForPartyModule.length >= 1) {
            String partySubCommand = fullArgsForPartyModule[0].toLowerCase();
            int paramsStartIndex = 1; // partySubCommand 的参数从 fullArgsForPartyModule[1] 开始

            // 示例: /tp party invite <player> OR /tparty invite <player>
            // fullArgsForPartyModule: ["invite", "currentTextIsPlayerName"] -> length = 2
            if (Arrays.asList("invite", "kick", "promote", "demote", "setleader", "transfer", "accept", "reject").contains(partySubCommand)) {
                if (fullArgsForPartyModule.length == paramsStartIndex + 1) { // 正在输入玩家名
                    StringUtil.copyPartialMatches(currentText,
                            plugin.getServer().getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()),
                            completions);
                }
            }
            // 示例: /tp party join <party_name> OR /tparty join <party_name>
            // fullArgsForPartyModule: ["join", "currentTextIsPartyName"]
            else if (Arrays.asList("join", "apply", "info").contains(partySubCommand) && !partySubCommand.equals("info") && !(partySubCommand.equals("apply") && fullArgsForPartyModule.length > paramsStartIndex +1)) { // info 可以不带参数，apply也可以
                if (fullArgsForPartyModule.length == paramsStartIndex + 1) { // 正在输入政党名
                    StringUtil.copyPartialMatches(currentText,
                            plugin.getPartyManager().getAllParties().stream().map(p -> p.getName().replace(" ", "_")).collect(Collectors.toList()),
                            completions);
                }
            }
            // /tp party info [party_name] (可选参数)
            else if (partySubCommand.equals("info")) {
                if (fullArgsForPartyModule.length == paramsStartIndex + 1) { //可以输入政党名，也可以不输
                    StringUtil.copyPartialMatches(currentText,
                            plugin.getPartyManager().getAllParties().stream().map(p -> p.getName().replace(" ", "_")).collect(Collectors.toList()),
                            completions);
                }
            }
        }
    }
    // completeNationSubCommand 和 completeElectionSubCommand 类似地调整
    private void completeNationSubCommand(CommandSender sender, String currentText, String[] fullArgsForNationModule, List<String> completions) {
        if (fullArgsForNationModule.length == 0 || (fullArgsForNationModule.length == 1 && fullArgsForNationModule[0].isEmpty() && currentText.isEmpty())) {
            StringUtil.copyPartialMatches(currentText, NATION_SUBCOMMANDS, completions);
            return;
        }
        if (fullArgsForNationModule.length == 1 && !NATION_SUBCOMMANDS.contains(fullArgsForNationModule[0].toLowerCase())) {
            StringUtil.copyPartialMatches(fullArgsForNationModule[0], NATION_SUBCOMMANDS, completions);
            return;
        }
        // ... (后续逻辑)
    }
    // 在 PoliticalTabCompleter.java 的 completeElectionSubCommand 方法中
    private void completeElectionSubCommand(CommandSender sender, String currentText, String[] fullArgsForElectionModule, List<String> completions) {
        if (fullArgsForElectionModule.length == 0 || (fullArgsForElectionModule.length == 1 && fullArgsForElectionModule[0].isEmpty() && currentText.isEmpty())) {
            StringUtil.copyPartialMatches(currentText, ELECTION_SUBCOMMANDS, completions); // ELECTION_SUBCOMMANDS = Arrays.asList("info", "candidates", "register", "vote", "list", "start", "stop", "help");
            return;
        }
        if (fullArgsForElectionModule.length == 1 && !ELECTION_SUBCOMMANDS.contains(fullArgsForElectionModule[0].toLowerCase())) {
            StringUtil.copyPartialMatches(fullArgsForElectionModule[0], ELECTION_SUBCOMMANDS, completions);
            return;
        }

        if (fullArgsForElectionModule.length >= 1) {
            String electionSubCommand = fullArgsForElectionModule[0].toLowerCase();
            int paramsStartIndex = 1; // 子命令的参数从 fullArgsForElectionModule[1] 开始

            // /tp election info [context] [type]
            // /tp election candidates [context] [type]
            // /tp election register [context] [type]
            if (Arrays.asList("info", "candidates", "register").contains(electionSubCommand)) {
                if (fullArgsForElectionModule.length == paramsStartIndex + 1) { // 正在输入上下文名称
                    // 补全国家名和政党名
                    if (TownyAPI.getInstance() != null) {
                        StringUtil.copyPartialMatches(currentText,
                                TownyAPI.getInstance().getNations().stream().map(n -> n.getName().replace(" ", "_")).collect(Collectors.toList()),
                                completions);
                    }
                    StringUtil.copyPartialMatches(currentText,
                            plugin.getPartyManager().getAllParties().stream().map(p -> p.getName().replace(" ", "_")).collect(Collectors.toList()),
                            completions);
                    // 也可以补全选举类型，因为上下文是可选的，类型可以是第一个参数
                    StringUtil.copyPartialMatches(currentText,
                            Arrays.stream(ElectionType.values()).map(Enum::name).map(String::toLowerCase).collect(Collectors.toList()),
                            completions);

                } else if (fullArgsForElectionModule.length == paramsStartIndex + 2) { // 正在输入选举类型 (如果第一个是上下文)
                    String contextName = fullArgsForElectionModule[paramsStartIndex];
                    // 只有当第一个参数不是选举类型时，第二个才可能是选举类型
                    if (ElectionType.valueOf(contextName.toUpperCase()) == null) {
                        StringUtil.copyPartialMatches(currentText,
                                Arrays.stream(ElectionType.values()).map(Enum::name).map(String::toLowerCase).collect(Collectors.toList()),
                                completions);
                    }
                }
            }
            // /tp election vote <candidate> [context] [type]
            else if (electionSubCommand.equals("vote")) {
                if (fullArgsForElectionModule.length == paramsStartIndex + 1) { // 正在输入候选人名称
                    // 这需要获取当前活跃选举的候选人列表，比较复杂，暂时留空或只补全在线玩家
                    // List<String> candidateNames = electionManager.getActiveCandidateNamesForContext(...);
                    // StringUtil.copyPartialMatches(currentText, candidateNames, completions);
                    StringUtil.copyPartialMatches(currentText, plugin.getServer().getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), completions);

                } else if (fullArgsForElectionModule.length == paramsStartIndex + 2) { // 正在输入上下文
                    if (TownyAPI.getInstance() != null) {
                        StringUtil.copyPartialMatches(currentText, TownyAPI.getInstance().getNations().stream().map(n -> n.getName().replace(" ", "_")).collect(Collectors.toList()), completions);
                    }
                    StringUtil.copyPartialMatches(currentText, plugin.getPartyManager().getAllParties().stream().map(p -> p.getName().replace(" ", "_")).collect(Collectors.toList()), completions);
                } else if (fullArgsForElectionModule.length == paramsStartIndex + 3) { // 正在输入选举类型
                    StringUtil.copyPartialMatches(currentText, Arrays.stream(ElectionType.values()).map(Enum::name).map(String::toLowerCase).collect(Collectors.toList()), completions);
                }
            }
            // /tp election list [active|finished|all]
            else if (electionSubCommand.equals("list")) {
                if (fullArgsForElectionModule.length == paramsStartIndex + 1) {
                    StringUtil.copyPartialMatches(currentText, Arrays.asList("active", "finished", "all"), completions);
                }
            }
            // Admin commands
            else if (Arrays.asList("start", "stop", "cancel").contains(electionSubCommand)) {
                if (fullArgsForElectionModule.length == paramsStartIndex + 1) { // 输入上下文
                    if (TownyAPI.getInstance() != null) {
                        StringUtil.copyPartialMatches(currentText, TownyAPI.getInstance().getNations().stream().map(n -> n.getName().replace(" ", "_")).collect(Collectors.toList()), completions);
                    }
                    StringUtil.copyPartialMatches(currentText, plugin.getPartyManager().getAllParties().stream().map(p -> p.getName().replace(" ", "_")).collect(Collectors.toList()), completions);
                } else if (fullArgsForElectionModule.length == paramsStartIndex + 2) { // 输入类型 (start 命令需要)
                    if(electionSubCommand.equals("start")) { // stop/cancel 的类型是可选的
                        StringUtil.copyPartialMatches(currentText, Arrays.stream(ElectionType.values()).map(Enum::name).map(String::toLowerCase).collect(Collectors.toList()), completions);
                    }
                }
            }
        }
    }

}