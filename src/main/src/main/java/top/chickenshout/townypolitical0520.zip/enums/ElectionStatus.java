package top.chickenshout.townypolitical.enums;

public enum ElectionStatus {
    NONE("无选举", "当前没有正在进行的选举"), // 国家或政党没有活跃选举
    REGISTRATION("候选人登记", "候选人可以报名参加选举"),
    VOTING("投票进行中", "合格选民可以投票"),
    COUNTING("计票中", "投票已结束，正在统计结果"), // 短暂状态，可能直接到FINISHED
    FINISHED("已结束", "选举结果已公布"),
    CANCELLED("已取消", "选举因故取消");

    private final String displayName;
    private final String description;

    ElectionStatus(String displayName, String description) {
        this.displayName = displayName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getDescription() {
        return description;
    }
}