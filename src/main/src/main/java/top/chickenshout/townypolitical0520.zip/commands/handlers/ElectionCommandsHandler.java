// 文件名: ElectionCommandsHandler.java
// 结构位置: top/chickenshout/townypolitical/commands/handlers/ElectionCommandsHandler.java
package top.chickenshout.townypolitical.commands.handlers;

import com.palmergames.bukkit.towny.TownyAPI;
import com.palmergames.bukkit.towny.object.Nation;
import com.palmergames.bukkit.towny.object.Resident;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import top.chickenshout.townypolitical.TownyPolitical;
import top.chickenshout.townypolitical.data.Party;
import top.chickenshout.townypolitical.elections.Candidate;
import top.chickenshout.townypolitical.elections.Election;
import top.chickenshout.townypolitical.enums.ElectionStatus;
import top.chickenshout.townypolitical.enums.ElectionType;
import top.chickenshout.townypolitical.managers.ElectionManager;
import top.chickenshout.townypolitical.managers.PartyManager;
import top.chickenshout.townypolitical.utils.MessageManager;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

public class ElectionCommandsHandler {
    private final TownyPolitical plugin;
    private final MessageManager messageManager;
    private final ElectionManager electionManager;
    private final PartyManager partyManager; // 需要用来获取政党信息
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss z");

    public ElectionCommandsHandler(TownyPolitical plugin) {
        this.plugin = plugin;
        this.messageManager = plugin.getMessageManager();
        this.electionManager = plugin.getElectionManager();
        this.partyManager = plugin.getPartyManager();
        this.dateFormat.setTimeZone(java.util.TimeZone.getDefault()); // 使用服务器默认时区
    }

    public boolean handleCommand(CommandSender sender, String commandLabel, String[] args) {
        if (args.length == 0) {
            sendElectionHelp(sender, commandLabel);
            return true;
        }
        String subCommand = args[0].toLowerCase();
        String[] subArgs = new String[args.length - 1];
        if (args.length > 1) {
            System.arraycopy(args, 1, subArgs, 0, args.length - 1);
        }

        switch (subCommand) {
            case "info":
                return handleInfoCommand(sender, commandLabel, subArgs);
            case "candidates":
            case "listcandidates":
                return handleCandidatesCommand(sender, commandLabel, subArgs);
            case "register":
            case "run":
                return handleRegisterCommand(sender, commandLabel, subArgs);
            case "vote":
                return handleVoteCommand(sender, commandLabel, subArgs);
            case "results":
                return handleResultsCommand(sender, commandLabel, subArgs);
            // Admin commands
            case "start":
                return handleAdminStartCommand(sender, commandLabel, subArgs);
            case "stop": // Could be cancel or force end
                return handleAdminStopCommand(sender, commandLabel, subArgs);
            default:
                messageManager.sendMessage(sender, "command-election-unknown", "subcommand", subCommand);
                sendElectionHelp(sender, commandLabel);
                return true;
        }
    }

    private Election getTargetElectionForInfo(CommandSender sender, String[] subArgs, ElectionType preferredType) {
        // Helper to find an election based on context name or player's context
        // Returns the most relevant active election or null
        if (subArgs.length == 0) { // No context specified, try sender's context
            if (!(sender instanceof Player)) {
                messageManager.sendMessage(sender, "error-election-context-required-console");
                return null;
            }
            Player player = (Player) sender;
            Nation nation = TownyAPI.getInstance().getResidentNationOrNull((Resident) player);
            if (nation != null) {
                // Prioritize preferredType if specified (e.g., for /tp election info parliament)
                Election election = electionManager.getActiveElection(nation.getUUID(), preferredType);
                if (election == null) { // If preferred not found, try any active for that nation
                    List<Election> active = electionManager.getAllActiveElectionsForContext(nation.getUUID());
                    if (!active.isEmpty()) election = active.get(0); // Get the first active one for simplicity
                }
                return election;
            }
            Party party = partyManager.getPartyByMember(player.getUniqueId());
            if (party != null) {
                return electionManager.getActiveElection(party.getPartyId(), ElectionType.PARTY_LEADER);
            }
            messageManager.sendMessage(player, "election-info-fail-no-context");
            return null;
        } else {
            String contextName = String.join(" ", subArgs);
            // Try to find nation first
            Nation nation = TownyAPI.getInstance().getNation(contextName);
            if (nation != null) {
                Election election = electionManager.getActiveElection(nation.getUUID(), preferredType);
                if (election == null) {
                    List<Election> active = electionManager.getAllActiveElectionsForContext(nation.getUUID());
                    if (!active.isEmpty()) election = active.get(0);
                }
                if (election == null) messageManager.sendMessage(sender, "election-info-none-active-for", "context", contextName);
                return election;
            }
            // Try to find party
            Party party = partyManager.getParty(contextName);
            if (party != null) {
                Election election = electionManager.getActiveElection(party.getPartyId(), ElectionType.PARTY_LEADER);
                if (election == null) messageManager.sendMessage(sender, "election-info-none-active-for", "context", contextName);
                return election;
            }
            messageManager.sendMessage(sender, "error-context-not-found", "context", contextName); // Context is neither nation nor party
            return null;
        }
    }


    private boolean handleInfoCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!sender.hasPermission("townypolitical.election.info")) {
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }

        // Determine preferred type if "parliament" or "president" is the first arg
        ElectionType preferredType = null;
        String[] contextNameArgs = subArgs;
        if (subArgs.length > 0) {
            if (subArgs[0].equalsIgnoreCase("parliament") || subArgs[0].equalsIgnoreCase("parl")) {
                preferredType = ElectionType.PARLIAMENTARY;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            } else if (subArgs[0].equalsIgnoreCase("president") || subArgs[0].equalsIgnoreCase("pres")) {
                preferredType = ElectionType.PRESIDENTIAL;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            } else if (subArgs[0].equalsIgnoreCase("leader")) {
                preferredType = ElectionType.PARTY_LEADER;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            }
        }


        Election election = getTargetElectionForInfo(sender, contextNameArgs, preferredType);
        if (election == null) {
            // getTargetElectionForInfo should have sent a message if no election found for specific context
            // If no context was given and player is in no relevant context, it also messages.
            return true;
        }

        displayElectionInfo(sender, election);
        return true;
    }

    private void displayElectionInfo(CommandSender sender, Election election) {
        String contextName = electionManager.getContextName(election.getContextId(), election.getType());
        messageManager.sendRawMessage(sender, "election-info-header",
                "type", election.getType().getDisplayName(),
                "context", contextName);
        messageManager.sendRawMessage(sender, "election-info-status", "status", election.getStatus().getDisplayName());

        if (election.getStatus() == ElectionStatus.REGISTRATION) {
            messageManager.sendRawMessage(sender, "election-info-registration-ends", "time", dateFormat.format(new Date(election.getRegistrationEndTime())));
        }
        if (election.getStatus() == ElectionStatus.REGISTRATION || election.getStatus() == ElectionStatus.VOTING) {
            messageManager.sendRawMessage(sender, "election-info-voting-starts", "time", dateFormat.format(new Date(election.getRegistrationEndTime()))); // Assuming voting starts when reg ends
        }
        if (election.getStatus() == ElectionStatus.VOTING) {
            messageManager.sendRawMessage(sender, "election-info-voting-ends", "time", dateFormat.format(new Date(election.getEndTime())));
        }

        messageManager.sendRawMessage(sender, "election-info-candidates-count", "count", String.valueOf(election.getCandidates().size()));
        if (election.getStatus() != ElectionStatus.NONE && election.getStatus() != ElectionStatus.CANCELLED) {
            messageManager.sendRawMessage(sender, "election-info-votes-cast", "count", String.valueOf(election.getVoters().size()));
        }


        if (election.getStatus() == ElectionStatus.FINISHED) {
            // Display results summary here
            if (election.getType() == ElectionType.PRESIDENTIAL || election.getType() == ElectionType.PARTY_LEADER) {
                if (election.getWinnerPlayerUUID() != null) {
                    OfflinePlayer winner = Bukkit.getOfflinePlayer(election.getWinnerPlayerUUID());
                    messageManager.sendRawMessage(sender, "election-info-winner-player", "player_name", winner.getName() != null ? winner.getName() : "N/A");
                } else {
                    messageManager.sendRawMessage(sender, "election-info-no-winner");
                }
            } else if (election.getType() == ElectionType.PARLIAMENTARY) {
                if (election.getWinnerPartyUUID() != null) {
                    Party winningParty = partyManager.getParty(election.getWinnerPartyUUID());
                    messageManager.sendRawMessage(sender, "election-info-winner-party", "party_name", winningParty != null ? winningParty.getName() : "N/A");
                } else {
                    messageManager.sendRawMessage(sender, "election-info-no-winner-party");
                }
                // Could also list top N parties from seat distribution
            }
        }
        messageManager.sendRawMessage(sender, "election-info-footer", "label", "/tp election"); // Adjust label as needed
    }

    private boolean handleCandidatesCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!sender.hasPermission("townypolitical.election.info")) { // Same perm as info
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }
        ElectionType preferredType = null;
        String[] contextNameArgs = subArgs;
        if (subArgs.length > 0) { // Similar type parsing as in info
            if (subArgs[0].equalsIgnoreCase("parliament") || subArgs[0].equalsIgnoreCase("parl")) {
                preferredType = ElectionType.PARLIAMENTARY;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            } else if (subArgs[0].equalsIgnoreCase("president") || subArgs[0].equalsIgnoreCase("pres")) {
                preferredType = ElectionType.PRESIDENTIAL;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            }
        }

        Election election = getTargetElectionForInfo(sender, contextNameArgs, preferredType);
        if (election == null) {
            return true;
        }

        Collection<Candidate> candidates = election.getCandidates();
        String contextName = electionManager.getContextName(election.getContextId(), election.getType());

        if (candidates.isEmpty()) {
            messageManager.sendMessage(sender, "election-candidates-none", "context", contextName, "type", election.getType().getDisplayName());
            return true;
        }

        messageManager.sendRawMessage(sender, "election-candidates-header", "type", election.getType().getDisplayName(), "context", contextName);
        for (Candidate candidate : candidates) {
            String playerName = candidate.getPlayerNameCache() != null ? candidate.getPlayerNameCache() : Bukkit.getOfflinePlayer(candidate.getPlayerUUID()).getName();
            String partyNameStr = "";
            if (candidate.getPartyUUID() != null) {
                Party party = partyManager.getParty(candidate.getPartyUUID());
                if (party != null) {
                    partyNameStr = " (" + party.getName() + ")";
                }
            }
            // In voting/finished stage, show votes
            String votesStr = (election.getStatus() == ElectionStatus.VOTING || election.getStatus() == ElectionStatus.FINISHED) ?
                    " - " + messageManager.getRawMessage("election-candidates-votes" , String.valueOf(candidate.getVotes()))
                    : "";
            messageManager.sendRawMessage(sender, "election-candidates-entry", "player_name", playerName, "party_info", partyNameStr, "votes_info", votesStr);
        }
        return true;
    }

    private boolean handleRegisterCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!(sender instanceof Player)) {
            messageManager.sendMessage(sender, "error-player-only-command");
            return true;
        }
        Player player = (Player) sender;

        if (!player.hasPermission("townypolitical.election.registercandidate")) {
            messageManager.sendMessage(player, "error-no-permission");
            return true;
        }

        ElectionType preferredType = null;
        String[] contextNameArgs = subArgs;
        if (subArgs.length > 0) { // User might type /tp e register parliament [nation_name]
            if (subArgs[0].equalsIgnoreCase("parliament") || subArgs[0].equalsIgnoreCase("parl")) {
                preferredType = ElectionType.PARLIAMENTARY;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            } else if (subArgs[0].equalsIgnoreCase("president") || subArgs[0].equalsIgnoreCase("pres")) {
                preferredType = ElectionType.PRESIDENTIAL;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            }
        }

        Election election = getTargetElectionForInfo(player, contextNameArgs, preferredType);
        if (election == null) {
            messageManager.sendMessage(player, "election-register-fail-no-election");
            return true;
        }

        if (election.getStatus() != ElectionStatus.REGISTRATION) {
            messageManager.sendMessage(player, "election-candidate-register-fail-closed");
            return true;
        }

        electionManager.registerCandidate(player, election);
        return true;
    }

    private boolean handleVoteCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!(sender instanceof Player)) {
            messageManager.sendMessage(sender, "error-player-only-command");
            return true;
        }
        Player voter = (Player) sender;

        if (!voter.hasPermission("townypolitical.election.vote")) {
            messageManager.sendMessage(voter, "error-no-permission");
            return true;
        }

        // Usage: /tp election vote [context_name_if_needed] <candidate_name>
        // Or /tp election vote <candidate_name> (if context is self)
        // Or /tp election vote <type> [context_name_if_needed] <candidate_name>

        if (subArgs.length < 1) {
            messageManager.sendMessage(voter, "error-invalid-arguments", "usage", "/" + commandLabel + " vote [election_context] <candidate_name>");
            return true;
        }

        ElectionType preferredType = null;
        String[] remainingArgs = subArgs;
        // Check if first arg is an election type
        if (ElectionType.PARLIAMENTARY.name().equalsIgnoreCase(subArgs[0]) || "parl".equalsIgnoreCase(subArgs[0])) {
            preferredType = ElectionType.PARLIAMENTARY;
            remainingArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
        } else if (ElectionType.PRESIDENTIAL.name().equalsIgnoreCase(subArgs[0]) || "pres".equalsIgnoreCase(subArgs[0])) {
            preferredType = ElectionType.PRESIDENTIAL;
            remainingArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
        } // Not supporting party leader vote via this specific syntax for now

        if (remainingArgs.length < 1) { // After stripping type, must have at least candidate name
            messageManager.sendMessage(voter, "error-invalid-arguments", "usage", "/" + commandLabel + " vote [type] [election_context] <candidate_name>");
            return true;
        }

        String candidateNameArg = remainingArgs[remainingArgs.length - 1]; // Last arg is candidate name
        String[] contextNameArgs = Arrays.copyOfRange(remainingArgs, 0, remainingArgs.length - 1); // Args before candidate name form the context

        Election election = getTargetElectionForInfo(voter, contextNameArgs, preferredType);
        if (election == null) {
            messageManager.sendMessage(voter, "election-vote-fail-no-election");
            return true;
        }

        if (election.getStatus() != ElectionStatus.VOTING) {
            messageManager.sendMessage(voter, "election-vote-fail-closed");
            return true;
        }

        Optional<Candidate> targetCandidateOpt = election.getCandidates().stream()
                .filter(c -> (c.getPlayerNameCache() != null && c.getPlayerNameCache().equalsIgnoreCase(candidateNameArg)) ||
                        Bukkit.getOfflinePlayer(c.getPlayerUUID()).getName().equalsIgnoreCase(candidateNameArg))
                .findFirst();

        if (!targetCandidateOpt.isPresent()) {
            messageManager.sendMessage(voter, "election-vote-fail-candidate-not-found", "candidate_name", candidateNameArg);
            return true;
        }

        electionManager.castVote(voter, election, targetCandidateOpt.get());
        return true;
    }

    private boolean handleResultsCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!sender.hasPermission("townypolitical.election.info")) { // Same perm as info
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }
        ElectionType preferredType = null;
        String[] contextNameArgs = subArgs;
        if (subArgs.length > 0) { // Similar type parsing
            if (subArgs[0].equalsIgnoreCase("parliament") || subArgs[0].equalsIgnoreCase("parl")) {
                preferredType = ElectionType.PARLIAMENTARY;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            } else if (subArgs[0].equalsIgnoreCase("president") || subArgs[0].equalsIgnoreCase("pres")) {
                preferredType = ElectionType.PRESIDENTIAL;
                contextNameArgs = Arrays.copyOfRange(subArgs, 1, subArgs.length);
            }
        }

        // TODO: Need a way to get a FINISHED election, not just active one.
        // ElectionManager might need getLatestFinishedElection(context, type)
        Election election = getTargetElectionForInfo(sender, contextNameArgs, preferredType); // This gets active, need modification
        if (election == null) {
            // Try to find last finished one in data store if ElectionManager supports it.
            // For now, if no active, assume no info.
            messageManager.sendMessage(sender, "election-results-none-found", "context", String.join(" ", contextNameArgs));
            return true;
        }

        if (election.getStatus() != ElectionStatus.FINISHED) {
            messageManager.sendMessage(sender, "election-results-not-finished", "status", election.getStatus().getDisplayName());
            return true;
        }

        electionManager.announceElectionResults(election); // This broadcasts, maybe we want a direct message to sender
        displayElectionInfo(sender, election); // Also show the info which includes winner summary
        // For detailed parliamentary results:
        if(election.getType() == ElectionType.PARLIAMENTARY && !election.getPartySeatDistribution().isEmpty()){
            messageManager.sendRawMessage(sender, "election-results-parliament-seats-header");
            election.getPartySeatDistribution().forEach((partyUUID, seats) -> {
                Party party = partyManager.getParty(partyUUID);
                String partyName = (party != null) ? party.getName() : "未知政党 (" + partyUUID.toString().substring(0,6) + ")";
                messageManager.sendRawMessage(sender, "election-results-parliament-seat-entry", "party_name", partyName, "seats", String.valueOf(seats));
            });
        }
        return true;
    }

    // --- Admin Commands ---
    private boolean handleAdminStartCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!sender.hasPermission("townypolitical.election.manage")) {
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }
        // Usage: /tp election start <nation_name> <type:parliament|president>
        if (subArgs.length < 2) {
            messageManager.sendMessage(sender, "error-invalid-arguments", "usage", "/" + commandLabel + " start <国家名称> <parliament|president>");
            return true;
        }

        String nationName = Arrays.stream(subArgs, 0, subArgs.length - 1).collect(Collectors.joining(" "));
        String typeStr = subArgs[subArgs.length - 1].toLowerCase();

        Nation nation = TownyAPI.getInstance().getNation(nationName);
        if (nation == null) {
            messageManager.sendMessage(sender, "error-nation-not-found", "nation", nationName);
            return true;
        }

        ElectionType electionType;
        if (typeStr.equals("parliament") || typeStr.equals("parl")) {
            electionType = ElectionType.PARLIAMENTARY;
        } else if (typeStr.equals("president") || typeStr.equals("pres")) {
            electionType = ElectionType.PRESIDENTIAL;
        } else {
            messageManager.sendMessage(sender, "election-admin-start-invalid-type", "type", typeStr);
            return true;
        }

        Election startedElection = electionManager.startNationElection(nation.getUUID(), electionType);
        if (startedElection != null) {
            messageManager.sendMessage(sender, "election-admin-start-success", "type", electionType.getDisplayName(), "nation", nation.getName());
        } else {
            // Manager should send more specific failure message (e.g., already active, or gov type doesn't support)
            messageManager.sendMessage(sender, "election-admin-start-fail", "type", electionType.getDisplayName(), "nation", nation.getName());
        }
        return true;
    }

    private boolean handleAdminStopCommand(CommandSender sender, String commandLabel, String[] subArgs) {
        if (!sender.hasPermission("townypolitical.election.manage")) {
            messageManager.sendMessage(sender, "error-no-permission");
            return true;
        }
        // Usage: /tp election stop <nation_name> <type:parliament|president> [reason_for_cancel]
        if (subArgs.length < 2) {
            messageManager.sendMessage(sender, "error-invalid-arguments", "usage", "/" + commandLabel + " stop <国家名称> <parliament|president> [原因]");
            return true;
        }
        String typeStr = subArgs[subArgs.length -1];
        String nationName;
        String reason = "管理员手动停止";

        if(subArgs.length > 2 && !(subArgs[subArgs.length-2].equalsIgnoreCase("parliament") || subArgs[subArgs.length-2].equalsIgnoreCase("president"))) {
            // Assume last arg is type, second to last is part of reason, rest is nation name
            typeStr = subArgs[subArgs.length -1];
            nationName = Arrays.stream(subArgs, 0, subArgs.length - 2).collect(Collectors.joining(" "));
            reason = subArgs[subArgs.length - 2]; // This parsing is a bit naive for multi-word reasons
        } else {
            nationName = Arrays.stream(subArgs, 0, subArgs.length - 1).collect(Collectors.joining(" "));
        }


        Nation nation = TownyAPI.getInstance().getNation(nationName);
        if (nation == null) {
            messageManager.sendMessage(sender, "error-nation-not-found", "nation", nationName);
            return true;
        }

        ElectionType electionType;
        if (typeStr.equalsIgnoreCase("parliament") || typeStr.equalsIgnoreCase("parl")) {
            electionType = ElectionType.PARLIAMENTARY;
        } else if (typeStr.equalsIgnoreCase("president") || typeStr.equalsIgnoreCase("pres")) {
            electionType = ElectionType.PRESIDENTIAL;
        } else {
            // If last arg wasn't type, assume it was part of nation name, and no type was given
            // This means we try to cancel ANY active election for the nation
            nationName = String.join(" ", subArgs); // Re-join all as nation name
            nation = TownyAPI.getInstance().getNation(nationName);
            if (nation == null) { /* already handled */ return true; }

            List<Election> activeElections = electionManager.getAllActiveElectionsForContext(nation.getUUID());
            if (activeElections.isEmpty()) {
                messageManager.sendMessage(sender, "election-admin-stop-none-active", "nation", nation.getName());
                return true;
            }
            for (Election election : activeElections) {
                electionManager.cancelElection(election, reason + " (by " + sender.getName() + ")");
            }
            messageManager.sendMessage(sender, "election-admin-stop-all-success", "nation", nation.getName());
            return true;
        }

        Election electionToStop = electionManager.getActiveElection(nation.getUUID(), electionType);
        if (electionToStop == null) {
            messageManager.sendMessage(sender, "election-admin-stop-specific-none-active", "type", electionType.getDisplayName(), "nation", nation.getName());
            return true;
        }

        electionManager.cancelElection(electionToStop, reason + " (by " + sender.getName() + ")");
        messageManager.sendMessage(sender, "election-admin-stop-specific-success", "type", electionType.getDisplayName(), "nation", nation.getName());
        return true;
    }


    private void sendElectionHelp(CommandSender sender, String commandLabel) {
        String displayLabel = commandLabel.split(" ")[0];
        if (!displayLabel.equalsIgnoreCase("telection") && !displayLabel.equalsIgnoreCase("tel")) { // Assuming aliases
            displayLabel += " election";
        }

        messageManager.sendRawMessage(sender, "help-election-header", "label", displayLabel);
        if (sender.hasPermission("townypolitical.election.info")) {
            messageManager.sendRawMessage(sender, "help-election-info", "label", displayLabel);
            messageManager.sendRawMessage(sender, "help-election-candidates", "label", displayLabel);
            messageManager.sendRawMessage(sender, "help-election-results", "label", displayLabel);
        }
        if (sender.hasPermission("townypolitical.election.registercandidate"))
            messageManager.sendRawMessage(sender, "help-election-register", "label", displayLabel);
        if (sender.hasPermission("townypolitical.election.vote"))
            messageManager.sendRawMessage(sender, "help-election-vote", "label", displayLabel);

        if (sender.hasPermission("townypolitical.election.manage")) {
            messageManager.sendRawMessage(sender, "help-election-admin-start", "label", displayLabel);
            messageManager.sendRawMessage(sender, "help-election-admin-stop", "label", displayLabel);
        }
        messageManager.sendRawMessage(sender, "help-footer");
    }
}