// 文件名: MessageManager.java
// 结构位置: top/chickenshout/townypolitical/utils/MessageManager.java
package top.chickenshout.townypolitical.utils;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageManager {

    private final JavaPlugin plugin;
    private final Map<String, String> messages = new HashMap<>();
    private String prefix; // 插件消息前缀
    private FileConfiguration messagesConfig; // 移除 final
    private final File messagesFile;
    private final String defaultMessagesFileName = "messages_zh_CN.yml";

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");

    public MessageManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        loadMessages(); // prefix 会在 loadMessages 内部最后被加载
    }

    private void loadMessages() {
        if (!messagesFile.exists()) {
            plugin.saveResource(defaultMessagesFileName, false);
            File defaultFile = new File(plugin.getDataFolder(), defaultMessagesFileName);
            if (defaultFile.exists()) {
                if (!defaultFile.renameTo(messagesFile)) {
                    plugin.getLogger().warning("Could not rename " + defaultMessagesFileName + " to messages.yml. Using " + defaultMessagesFileName + " directly for now.");
                    // 如果重命名失败，尝试直接加载 messages_zh_CN.yml 以避免 messagesConfig 为 null
                    File actualMessagesFileToLoad = new File(plugin.getDataFolder(), defaultMessagesFileName);
                    if (actualMessagesFileToLoad.exists()) {
                        this.messagesConfig = YamlConfiguration.loadConfiguration(actualMessagesFileToLoad);
                    } else {
                        plugin.getLogger().severe("Default messages file " + defaultMessagesFileName + " also not found after failing to rename. Messages might not load.");
                        this.messagesConfig = new YamlConfiguration(); // 创建一个空的，避免NPE
                    }
                } else {
                    this.messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
                }
            } else {
                plugin.getLogger().severe("Default messages file (" + defaultMessagesFileName + ") could not be saved or found. Messages might not load.");
                this.messagesConfig = new YamlConfiguration(); // 创建一个空的，避免NPE
            }
        } else {
            this.messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
        }


        // 从插件内部加载默认值以确保所有键都存在
        try (InputStream defaultConfigStream = plugin.getResource(defaultMessagesFileName)) {
            if (defaultConfigStream != null) {
                YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defaultConfigStream, StandardCharsets.UTF_8));
                messagesConfig.addDefaults(defaultConfig);
                messagesConfig.options().copyDefaults(true);
                // 保存合并后的配置到 messages.yml
                if (messagesFile.exists() && messagesFile.getName().equals("messages.yml")) { // 确保我们写回的是 messages.yml
                    messagesConfig.save(messagesFile);
                } else { // 如果我们因为重命名失败而加载的是 messages_zh_CN.yml，则不应该写回去覆盖原始的 jar 内文件（虽然这里是 plugin.getDataFolder() 内的）
                    File intendedMessagesFile = new File(plugin.getDataFolder(), "messages.yml");
                    messagesConfig.save(intendedMessagesFile); // 尝试保存到正确的文件名
                    if(!messagesFile.getName().equals("messages.yml")) {
                        plugin.getLogger().info("Corrected messages file to messages.yml and saved defaults.");
                    }
                }

            } else {
                plugin.getLogger().severe("Default messages file (" + defaultMessagesFileName + ") not found in JAR.");
            }
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save or load messages.yml", e);
        }

        // 将所有消息加载到内存中
        messages.clear(); // 清空旧消息，如果重载
        for (String key : messagesConfig.getKeys(true)) {
            if (messagesConfig.isString(key)) {
                messages.put(key, messagesConfig.getString(key));
            }
        }
        // Prefix 应该在 messages map 填充完毕后加载
        this.prefix = getRawMessage("plugin-prefix", "&8[&6TownyPolitical&8] &r");
        plugin.getLogger().info("Messages loaded. Total messages: " + messages.size() + ". Prefix: '" + this.prefix + "'");
    }

    /**
     * 获取原始消息字符串，不进行颜色转换或占位符替换。
     * @param key 消息的键
     * @param defaultValue 如果找不到键，则返回的默认值
     * @return 消息字符串
     */
    public String getRawMessage(String key, String defaultValue) {
        return messages.getOrDefault(key, defaultValue);
    }

    /**
     * 获取格式化后的消息 (颜色代码转换)。
     * @param key 消息的键
     * @return 格式化后的消息，如果找不到则返回键本身
     */
    public String getMessage(String key) {
        String message = messages.get(key);
        if (message == null) {
            plugin.getLogger().warning("Missing message key: " + key + " in messages.yml");
            return translateColors("&cMissing message: " + key); // 返回一个提示，而不是key本身
        }
        return translateColors(message);
    }

    /**
     * 获取格式化后的消息，并替换占位符。
     * @param key 消息的键
     * @param placeholders 占位符及其替换值，例如 "player", playerName, "amount", amountValue
     * @return 格式化并替换占位符后的消息
     */
    public String getMessage(String key, Object... placeholders) {
        String message = messages.get(key);
        if (message == null) {
            plugin.getLogger().warning("Missing message key: " + key + " in messages.yml (with placeholders)");
            return translateColors("&cMissing message: " + key);
        }
        if (placeholders.length % 2 != 0) {
            plugin.getLogger().warning("Invalid placeholders for message key: " + key + ". Must be key-value pairs.");
            return translateColors(message);
        }
        for (int i = 0; i < placeholders.length; i += 2) {
            if (placeholders[i] == null || placeholders[i+1] == null) continue;
            message = message.replace("%" + placeholders[i].toString() + "%", placeholders[i+1].toString());
        }
        return translateColors(message);
    }


    /**
     * 发送带前缀的消息给玩家或控制台，并替换占位符。
     * @param recipient 接收者
     * @param key 消息键
     * @param placeholders 占位符
     */
    public void sendMessage(CommandSender recipient, String key, Object... placeholders) {
        if (recipient == null) return;
        recipient.sendMessage(prefix + getMessage(key, placeholders));
    }

    /**
     * 发送不带前缀的原始消息给玩家或控制台。
     * @param recipient 接收者
     * @param key 消息键
     */
    public void sendRawMessage(CommandSender recipient, String key) {
        if (recipient == null) return;
        recipient.sendMessage(getMessage(key));
    }

    /**
     * 发送不带前缀的原始消息给玩家或控制台，并替换占位符。
     * @param recipient 接收者
     * @param key 消息键
     * @param placeholders 占位符
     */
    public void sendRawMessage(CommandSender recipient, String key, Object... placeholders) {
        if (recipient == null) return;
        recipient.sendMessage(getMessage(key, placeholders));
    }

    /**
     * 发送ActionBar消息给玩家 (如果支持)。
     * @param player 玩家
     * @param key 消息键
     * @param placeholders 占位符
     */
    public void sendActionBar(Player player, String key, Object... placeholders) {
        if (player == null || !player.isOnline()) return;
        try {
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacyText(getMessage(key, placeholders)));
        } catch (Throwable t) {
            sendMessage(player, key, placeholders); // Fallback to chat message
            plugin.getLogger().finer("ActionBar not supported or failed to send: " + t.getMessage()); // Use finer for less console spam
        }
    }

    public static String translateColors(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        Matcher matcher = HEX_PATTERN.matcher(text);
        StringBuffer buffer = new StringBuffer(text.length() + 4 * 8);
        while (matcher.find()) {
            String group = matcher.group(1);
            matcher.appendReplacement(buffer, ChatColor.COLOR_CHAR + "x"
                    + ChatColor.COLOR_CHAR + group.charAt(0) + ChatColor.COLOR_CHAR + group.charAt(1)
                    + ChatColor.COLOR_CHAR + group.charAt(2) + ChatColor.COLOR_CHAR + group.charAt(3)
                    + ChatColor.COLOR_CHAR + group.charAt(4) + ChatColor.COLOR_CHAR + group.charAt(5)
            );
        }
        matcher.appendTail(buffer);
        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    /**
     * 重新加载消息文件。
     */
    public void reloadMessages() {
        // 清空内存中的旧消息
        messages.clear();

        // 确保插件数据文件夹存在
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdirs();
        }

        // 检查 messages.yml 文件，如果不存在则从 resources 复制
        if (!messagesFile.exists()) {
            plugin.getLogger().info(messagesFile.getPath() + " not found. Attempting to restore from defaults...");
            plugin.saveResource(defaultMessagesFileName, false); // 保存 messages_zh_CN.yml
            File defaultSavedFile = new File(plugin.getDataFolder(), defaultMessagesFileName);
            if (defaultSavedFile.exists()) {
                if (!defaultSavedFile.renameTo(messagesFile)) { // 重命名为 messages.yml
                    plugin.getLogger().warning("Could not rename " + defaultMessagesFileName + " to " + messagesFile.getName() + " during reload.");
                }
            }
        }

        // 重新加载 messages.yml
        this.messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);

        // 从插件内部加载默认值
        try (InputStream defaultConfigStream = plugin.getResource(defaultMessagesFileName)) {
            if (defaultConfigStream != null) {
                YamlConfiguration defaultConfig = YamlConfiguration.loadConfiguration(new InputStreamReader(defaultConfigStream, StandardCharsets.UTF_8));
                messagesConfig.addDefaults(defaultConfig);
                messagesConfig.options().copyDefaults(true);
                messagesConfig.save(messagesFile); // 保存更新，包含新增的默认消息
            } else {
                plugin.getLogger().severe("Default messages file (" + defaultMessagesFileName + ") not found in JAR during reload.");
            }
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save or load messages.yml during reload", e);
        }

        // 将所有消息重新加载到内存
        for (String key : messagesConfig.getKeys(true)) {
            if (messagesConfig.isString(key)) {
                messages.put(key, messagesConfig.getString(key));
            }
        }

        // 重新加载前缀
        this.prefix = getRawMessage("plugin-prefix", "&8[&6TownyPolitical&8] &r");
        plugin.getLogger().info("Messages reloaded. Total messages: " + messages.size() + ". Prefix: '" + this.prefix + "'");
    }

    /**
     * 获取插件消息的原始前缀。
     * 注意：这个前缀可能包含未处理的颜色代码。
     * 如果需要带颜色的前缀，请使用 translateColors(getRawPrefix())
     * 或者直接使用 sendMessage 方法，它会自动处理。
     * @return 原始前缀字符串
     */
    public String getRawPrefix() { // 我改名为 getRawPrefix 以明确其原始性
        return this.prefix;
    }

    /**
     * 获取经过颜色转换的插件消息前缀。
     * @return 带颜色的前缀字符串
     */
    public String getPrefix() {
        return translateColors(this.prefix);
    }
}